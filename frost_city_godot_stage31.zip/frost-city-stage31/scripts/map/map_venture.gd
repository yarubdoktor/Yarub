extends "res://scripts/map/map_scene.gd"
## الطبقة 3/5 — نافذة الحملة: اختيار الجنود والتشكيل وإرسال الحملة أو الاستطلاع.


# ================================================================ المرحلة 3: نافذة الفرقة العسكرية
func _open_vent_window() -> void:
	_open_venture_window({})


func _open_venture_window(target: Dictionary) -> void:
	## نافذة إرسال الفرقة العسكرية — تصلح للمنفث وللمعاقل والقلاع، والتشكيل يُختار هنا
	venture_target = target
	venture_formation = "balanced"
	_close_vent_window()
	vent_win = _panel(Control.PRESET_CENTER)
	vent_win.custom_minimum_size = Vector2(440, 0)
	var v := VBoxContainer.new()
	vent_win.add_child(v)
	var title := Label.new()
	var tname := "المنفث الحراري"
	if not target.is_empty() and str(target.get("kind", "vent")) == "hold":
		tname = str(target.get("n", "الهدف"))
	title.text = "الفرقة العسكرية نحو " + tname
	title.add_theme_color_override("font_color", Color("ffd36b"))
	v.add_child(title)
	var hint := Label.new()
	hint.text = "الجنود المرسلون يغادرون المدينة: لن يشاركوا في الدفاع حتى يعودوا. اختر تشكيل القتال — يُثبّت مع ظروف المعركة عند الإرسال."
	hint.add_theme_font_size_override("font_size", 15)
	hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	v.add_child(hint)
	# صفوف الجنود داخل حاوية تمرير محدودة الارتفاع — حتى لا تتجاوز النافذة شاشة الهاتف
	var scroll := ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(0, 240)
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.add_child(scroll)
	var list := VBoxContainer.new()
	list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(list)
	vent_spins = {}
	var any_troops := false
	for k in Game.troops:
		var n := int(Game.troops[k])
		if n <= 0:
			continue
		any_troops = true
		var row := HBoxContainer.new()
		list.add_child(row)
		var parts: PackedStringArray = String(k).split("_")
		var nm := "%s • %s" % [Defs.TROOPS[parts[0]]["name"], Defs.TIER_NAMES[int(parts[1])]]
		var l := Label.new()
		l.text = "%s (متاح %d)" % [nm, n]
		l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(l)
		var sp := SpinBox.new()
		sp.max_value = n
		sp.min_value = 0
		sp.step = 1
		sp.value = mini(n, 10)
		sp.value_changed.connect(func(_v): _update_vent_summary())
		row.add_child(sp)
		vent_spins[k] = sp
	if not any_troops:
		var empty := Label.new()
		empty.text = "لا يوجد جنود — درّب جيشًا من المعسكر أولًا"
		empty.add_theme_color_override("font_color", Color("ff9a8a"))
		v.add_child(empty)
	vent_summary = Label.new()
	vent_summary.add_theme_font_size_override("font_size", 15)
	vent_summary.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	v.add_child(vent_summary)
	# التشكيلات القتالية: ثلاثة أزرار تِبادل
	var ftitle := Label.new()
	ftitle.text = "تشكيل القتال"
	ftitle.add_theme_color_override("font_color", Color("ffd36b"))
	v.add_child(ftitle)
	var fh := HBoxContainer.new()
	fh.add_theme_constant_override("separation", 8)
	v.add_child(fh)
	_formation_btns = {}
	for fid in Defs.FORMATION_ORDER:
		var fd: Dictionary = Defs.FORMATIONS[fid]
		var fb := _button(fd["name"], func(): _pick_formation(String(fid)))
		fb.toggle_mode = true
		fb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		fb.tooltip_text = str(fd["desc"])
		fh.add_child(fb)
		_formation_btns[fid] = fb
	_pick_formation("balanced")
	var fdesc := Label.new()
	fdesc.add_theme_font_size_override("font_size", 14)
	fdesc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	fdesc.add_theme_color_override("font_color", Color("b9cbe0"))
	v.add_child(fdesc)
	_formation_desc = fdesc
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 10)
	v.add_child(hb)
	var send := _button("إرسال الفرقة", func(): _send_venture(), true)
	send.disabled = not any_troops
	vent_send_btn = send
	hb.add_child(send)
	hb.add_child(_button("إلغاء", _close_vent_window))
	ui_blockers.append(vent_win)
	_update_vent_summary()
	_center_vent_win_soon()


func _center_vent_win_soon() -> void:
	## ينتظر استقرار التخطيط أولًا — القياس قبل التخطيط يعطي ارتفاعًا مؤقتًا ضخمًا للنص الملتف
	await get_tree().process_frame
	_center_vent_win()


func _center_vent_win() -> void:
	## توسيط فعلي بعد اكتمال المحتوى — النافذة تنمو للأسفل من نقطة الوسط فتغطي أزرار التنقل السفلية
	if vent_win == null or ui == null:
		return
	var h := minf(vent_win.size.y, ui.size.y - 96.0)
	vent_win.size = Vector2(maxf(vent_win.size.x, 440.0), h)
	vent_win.position = (ui.size - vent_win.size) * 0.5


func _update_vent_summary() -> void:
	## حجم المسيرة المسموح والمؤن المطلوبة — يتحدث مع كل تغيير في الأعداد
	if vent_summary == null or not is_instance_valid(vent_summary):
		return
	var units := {}
	for k in vent_spins:
		var n := int(vent_spins[k].value)
		if n > 0:
			units[k] = n
	var chk := Game.venture_check(units)
	var line := "حجم المسيرة: %d / %d   •   المؤن: %s طعام" % [chk["total"], chk["cap"], Defs.fmt(float(chk["cost"]))]
	if chk["reason"] != "" and chk["total"] > 0:
		line += "\n" + String(chk["reason"])
	vent_summary.text = line
	vent_summary.add_theme_color_override("font_color", Color("ff9a8a") if (chk["total"] > 0 and not chk["ok"]) else Color("b9cbe0"))
	if vent_send_btn != null and is_instance_valid(vent_send_btn):
		vent_send_btn.disabled = not chk["ok"]


func _pick_formation(fid: String) -> void:
	venture_formation = fid
	for k in _formation_btns:
		(_formation_btns[k] as Button).button_pressed = String(k) == fid
	if _formation_desc != null:
		_formation_desc.text = str(Defs.FORMATIONS[fid]["desc"])


func _close_vent_window() -> void:
	if vent_win != null:
		ui_blockers.erase(vent_win)
		vent_win.queue_free()
		vent_win = null
	vent_spins = {}
	vent_summary = null
	vent_send_btn = null
	_formation_desc = null


func _send_venture() -> void:
	var units := {}
	for k in vent_spins:
		var n := int(vent_spins[k].value)
		if n > 0:
			units[k] = n
	var tgt := venture_target
	if Game.start_venture(units, venture_formation, tgt):
		Sound.play("march")
		_toast("انطلقت الفرقة العسكرية بتشكيل «%s»" % Defs.FORMATIONS[venture_formation]["name"])
		_close_vent_window()
		_close_panel()


func _send_scout(info: Dictionary) -> void:
	## فرقة استطلاع نحو منطقة مجهولة: تشغل خانة فرق، وتكشف عند الوصول ثم تعود
	if Game.marches.size() >= Game.MAX_MARCHES:
		_toast("كل الفرق في مهمة — انتظر عودة إحداها")
		return
	if Game.start_march({"kind": "scout", "x": int(info["x"]), "y": int(info["y"])}):
		Sound.play("march")
		var m: Dictionary = Game.marches.back()
		_toast("انطلقت فرقة الاستطلاع — الوصول خلال %s" % Defs.fmt_time(float(m["arrive"]) - Game.now()))
		_close_panel()
