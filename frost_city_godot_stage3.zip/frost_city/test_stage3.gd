extends SceneTree
## اختبار آلي للمرحلة 3 — جبهة الصقيع (منطق اللعبة)
## التشغيل: godot --headless -s test_stage3.gd  (يستخدم مسار حفظ اختباري معزول)

const GS := preload("res://scripts/game_state.gd")
const TEST_SAVE := "user://frost_save_test_stage3.json"

func _init() -> void:
	var ok := true
	var g = GS.new()
	g.save_path_override = TEST_SAVE

	# 1) لعبة جديدة: المنفث مهيأ، والجبهة الأولى بعد دورة كاملة (إنذار مسبق)
	g.new_game()
	if g.vent.is_empty() or g.vent["captured"] or g.venture.size() > 0:
		print("FAIL: init"); ok = false
	elif g.front_active() or g.front_active(g.now() + 100.0):
		print("FAIL: first front should come after a full period"); ok = false
	elif not g.front_active(g.front_origin + 10.0):
		print("FAIL: front inactive at origin+10"); ok = false
	elif g.front_active(g.front_origin + 200.0):
		print("FAIL: front active at origin+200"); ok = false
	elif not g.front_active(g.front_origin + 910.0):
		print("FAIL: second cycle"); ok = false
	else:
		print("PASS: init + front schedule (15 min warning)")

	# 2) إرسال فرقة عسكرية: حجز الجنود فورًا
	g.troops["shield_1"] = 40
	g.troops["bow_1"] = 20
	var sent: bool = g.start_venture({"shield_1": 30, "bow_1": 15})
	if not sent or int(g.troops["shield_1"]) != 10 or int(g.troops["bow_1"]) != 5:
		print("FAIL: venture start"); ok = false
	else:
		print("PASS: venture start (troops reserved)")

	# 3) رفض إرسال فرقة ثانية
	if g.start_venture({"shield_1": 5}):
		print("FAIL: double venture"); ok = false
	else:
		print("PASS: double venture rejected")

	# 4) المعركة عند الوصول لا عند العودة: تُحسم والناجون لم يعودوا بعد
	g.venture["arrive"] = g.now() - 1.0
	g.venture["back"] = g.now() + 60.0
	g._simulate(0.5, g.now())
	if not bool(g.venture.get("resolved", false)):
		print("FAIL: battle not resolved at arrival"); ok = false
	elif not g.vent["captured"]:
		print("FAIL: vent not captured"); ok = false
	elif int(g.troops["shield_1"]) != 10 or int(g.troops["bow_1"]) != 5:
		print("FAIL: survivors returned before back time"); ok = false
	else:
		print("PASS: battle resolved at arrival, survivors still returning")

	# 5) حفظ وإعادة تحميل أثناء العودة: المعركة لا تتكرر والناجون يعودون مرة واحدة
	g.save_game()
	var g2 = GS.new()
	g2.save_path_override = TEST_SAVE
	if not g2.load_game():
		print("FAIL: mid-return load"); ok = false
	elif not bool(g2.venture.get("resolved", false)):
		print("FAIL: resolved flag not persisted"); ok = false
	else:
		var home_before := int(g2.troops["shield_1"]) + int(g2.troops["bow_1"])
		var wounded_before := int(g2.wounded["shield_1"]) + int(g2.wounded["bow_1"])
		var dead_seen: Array = []
		g2.venture_done.connect(func(r: Dictionary): dead_seen.append(int(r.get("dead", -1))))
		g2.venture["back"] = g2.now() - 1.0
		g2._simulate(0.5, g2.now())
		if not g2.venture.is_empty():
			print("FAIL: venture not returned"); ok = false
		elif dead_seen.is_empty():
			print("FAIL: dead count not reported on return"); ok = false
		else:
			var home_after := int(g2.troops["shield_1"]) + int(g2.troops["bow_1"])
			var wounded_after := int(g2.wounded["shield_1"]) + int(g2.wounded["bow_1"])
			var new_wounded := wounded_after - wounded_before
			var dead: int = int(dead_seen[0])
			# المحاسبة الدقيقة: المرسلون (45) = (العائدون للثكنات) + جرحى جدد + قتلى
			if home_after - home_before + new_wounded + dead != 45:
				print("FAIL: conservation (%d - %d + %d + %d != 45)" % [home_after, home_before, new_wounded, dead]); ok = false
			else:
				print("PASS: exactly-once return + conservation (home=%d, wounded=%d, dead=%d)" % [home_after, new_wounded, dead])

	# 5ب) امتلاء المستوصف قبل العودة (كأن غارة ذئاب سبقتها): الفائض يصبح قتلى والمحاسبة تصح
	var g5 = GS.new()
	g5.save_path_override = TEST_SAVE
	g5.new_game()
	g5.troops["shield_1"] = 60
	if not g5.start_venture({"shield_1": 50}):
		print("FAIL: 5b venture start"); ok = false
	else:
		g5.venture["arrive"] = g5.now() - 1.0
		g5.venture["back"] = g5.now() + 60.0
		g5._simulate(0.5, g5.now())
		if not bool(g5.venture.get("resolved", false)):
			print("FAIL: 5b battle not resolved"); ok = false
		else:
			# املأ المستوصف تمامًا قبل العودة
			g5.wounded["shield_1"] = g5.wounded_cap()
			var home_before5 := int(g5.troops["shield_1"])
			var dead_seen5: Array = []
			g5.venture_done.connect(func(r: Dictionary): dead_seen5.append(int(r.get("dead", -1))))
			g5.venture["back"] = g5.now() - 1.0
			g5._simulate(0.5, g5.now())
			if not g5.venture.is_empty() or dead_seen5.is_empty():
				print("FAIL: 5b return"); ok = false
			else:
				var home_after5 := int(g5.troops["shield_1"])
				var dead5: int = int(dead_seen5[0])
				# لا جرحى جدد (المستوصف ممتلئ) — والخسائر كلها قتلى
				if home_after5 - home_before5 + dead5 != 50:
					print("FAIL: 5b conservation (%d - %d + %d != 50)" % [home_after5, home_before5, dead5]); ok = false
				elif int(g5.wounded["shield_1"]) != g5.wounded_cap():
					print("FAIL: 5b wounded overflow"); ok = false
				else:
					print("PASS: infirmary-full overflow becomes dead (home=%d, dead=%d)" % [home_after5, dead5])

	# 6) رفض مهمة جديدة بعد الاحتلال
	var g3 = GS.new()
	g3.save_path_override = TEST_SAVE
	g3.load_game()
	if g3.start_venture({"shield_1": 5}):
		print("FAIL: venture allowed after capture"); ok = false
	else:
		print("PASS: venture rejected after capture")

	# 7) دفء المنفث في حساب المدينة
	g3.recompute()
	var heat_before: float = g3.inside_temp
	g3.vent["captured"] = false
	g3.recompute()
	if g3.inside_temp > heat_before - 3.9:
		print("FAIL: vent heat effect"); ok = false
	else:
		print("PASS: vent heat effect (+%.0f)" % (heat_before - g3.inside_temp))

	# 8) الجبهة تخفض الحرارة الخارجية 6 درجات
	var tt_active: float = g3.front_origin + 100.0
	var tt_calm: float = g3.front_origin + 200.0
	var expect_active: float = -16.0 + 3.0 * sin(tt_active * TAU / 600.0) - 6.0
	var expect_calm: float = -16.0 + 3.0 * sin(tt_calm * TAU / 600.0)
	if absf(g3._outside(tt_active) - expect_active) > 0.01 or absf(g3._outside(tt_calm) - expect_calm) > 0.01:
		print("FAIL: front drop"); ok = false
	else:
		print("PASS: front drop (-6 during front, 0 otherwise)")

	# 9) توافق حفظ المرحلة الثانية القديم (بدون حقول المرحلة 3)
	var old_save := {"v": 2, "time": g3.now() - 7200.0, "res": {"food": 100.0, "wood": 100.0, "coal": 50.0, "iron": 0.0}, "gems": 10, "plots": {}, "stored": {}, "queue": [], "pop": 5, "sick": 0.0, "furnace_mode": 1, "stats": {}, "task_index": 1, "last_daily": "", "home": [790, 842], "marches": [], "storm": [0.0, 0.0], "aurora": 0, "trust": 60.0, "troops": {}, "wounded": {}, "train": {}, "heroes": {}, "defender": "", "governor": "", "techs": {}, "research": {}, "crystals": [], "raid_next": 0.0, "raid_count": 0, "raid_wins": 0, "last_raid": {}, "decision_next": 0.0, "pending_decision": -1, "task2_index": 0}
	var fw := FileAccess.open(TEST_SAVE, FileAccess.WRITE)
	fw.store_string(JSON.stringify(old_save))
	fw.flush()
	fw = null
	var g4 = GS.new()
	g4.save_path_override = TEST_SAVE
	# غياب ساعتين قبل الحفظ القديم: لا جبهة على الزمن التاريخي، وأول جبهة بعد دورة
	if not g4.load_game():
		print("FAIL: old save load"); ok = false
	elif g4.vent.is_empty() or g4.front_origin <= g4.now():
		print("FAIL: old save migration"); ok = false
	elif g4.front_active(g4.now() - 3600.0):
		print("FAIL: historical front applied"); ok = false
	else:
		print("PASS: old stage-2 save migration (2h absence, no historical front)")

	# تنظيف مسار الحفظ الاختباري
	DirAccess.remove_absolute(ProjectSettings.globalize_path(TEST_SAVE))

	print("ALL LOGIC TESTS PASSED" if ok else "SOME LOGIC TESTS FAILED")
	quit(0 if ok else 1)
