extends Node3D
## خريطة الصقيع 1200×1200 — المشهد الرئيسي
## يحمّل الخريطة GLB، ويوزّع المدن والموارد والوحوش من ملف JSON،
## ويبني الواجهة العربية ونظام إرسال القوات.

const StrategyCamera := preload("res://scripts/strategy_camera.gd")
const Defs := preload("res://scripts/defs.gd")
const MAP_PATH := "res://assets/frost_map.glb"
const DATA_PATH := "res://data/map_data.json"
const FONT_PATH := "res://fonts/NotoKufiArabic.ttf"

const RES_NAMES := {"coal": "منجم فحم", "wood": "معسكر خشب", "iron": "منجم حديد", "food": "أرض صيد"}
const RES_GAIN := {"coal": 1800, "wood": 3200, "iron": 600, "food": 4500}
const BEAST_NAMES := {"wolf": "ذئب الثلج", "bear": "دب قطبي"}
const TEAM_NAMES := {"me": "مدينتك", "ally": "تحالف حليف", "enemy": "تحالف عدو", "neutral": "محايد"}
const LM_TYPES := {"sun_city": "المركز — معركة السيادة", "stronghold": "معقل", "fortress": "قلعة",
		"gate": "بوابة", "pass": "ممر جبلي"}

var data: Dictionary
var rig: Node3D
var font: Font
var lookup := {}
var env: Environment
var sky_mat: ProceduralSkyMaterial
var sun: DirectionalLight3D
var night := false
var snow: CPUParticles3D

var ui: Control
var ui_blockers: Array[Control] = []
var coord_label: Label
var res_label: Label
var march_label: Label
var panel: PanelContainer
var p_title: Label
var p_sub: Label
var p_info: Label
var p_action: Button
var toast: Label
var toast_time := 0.0

var selected: Dictionary = {}
var sel_ring: MeshInstance3D
var sel_rr := 1.0
var home_node: MeshInstance3D
var home_label: Label3D
var home_pos: Vector3
var home_info: Dictionary
var troop_mesh: Mesh
var march_mat: StandardMaterial3D

# المرحلة 3: جبهة الصقيع (نموذج أولي)
var vent_node: MeshInstance3D
var vent_label: Label3D
var front_label: Label
var vent_win: PanelContainer = null
var vent_spins := {}
var _front_on := false
var _scan_best := 0.0
var _scan_found := false

# تعميق الخريطة: ضباب الحرب + المعاقل والقلاع + التشكيلات
var fog_labels: Array = []          # [{"label": Label3D, "x": int, "y": int}] — تُخفى حتى الكشف
var fog_tex: ImageTexture
var fog_img: Image
var holds_label: Label
var venture_target := {}            # هدف نافذة الإرسال — مستقل عن «selected»
var venture_formation := "balanced"
var _formation_btns := {}

const FOG_SHADER := """
shader_type spatial;
render_mode blend_mix, depth_draw_opaque;
uniform sampler2D fog_tex;
uniform vec4 fog_color : source_color = vec4(0.03, 0.06, 0.12, 0.92);
varying vec2 wxz;
void vertex() {
	wxz = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xz;
}
void fragment() {
	float e = texture(fog_tex, wxz / 1200.0).r;
	ALBEDO = fog_color.rgb;
	ALPHA = fog_color.a * (1.0 - e);
}
"""


func _terrain_height_at(x: float, z: float) -> float:
	## أعلى قمة تضاريس قريبة من النقطة (وقوف المنفث فوق الثلج لا داخله)
	_scan_best = 0.0
	_scan_found = false
	_scan_node(self, x, z)
	return _scan_best if _scan_found else 0.6

func _scan_node(n: Node, x: float, z: float) -> void:
	if n is MeshInstance3D:
		var mi: MeshInstance3D = n
		if mi.mesh != null:
			for i in mi.mesh.get_surface_count():
				var arrays := mi.mesh.surface_get_arrays(i)
				if arrays.size() > ArrayMesh.ARRAY_VERTEX:
					var pos: PackedVector3Array = arrays[ArrayMesh.ARRAY_VERTEX]
					for p in pos:
						if absf(p.x - x) <= 1.25 and absf(p.z - z) <= 1.25:
							if not _scan_found or p.y > _scan_best:
								_scan_best = p.y
								_scan_found = true
	for c in n.get_children():
		_scan_node(c, x, z)


func _ready() -> void:
	font = load(FONT_PATH)
	data = JSON.parse_string(FileAccess.get_file_as_string(DATA_PATH))
	_setup_env()
	var map: Node = load(MAP_PATH).instantiate()
	_fix_materials(map)
	add_child(map)
	_spawn_all()
	_setup_fog()
	_setup_camera()
	_setup_ui()
	_toast("اسحب للتحرك • إصبعان للتكبير • اضغط على أي خانة")
	Game.changed.connect(_refresh_stock)
	Game.toast.connect(_toast)
	Game.fog_changed.connect(_update_fog)
	_update_fog()


# ================================================================ البيئة
func _setup_env() -> void:
	env = Environment.new()
	sky_mat = ProceduralSkyMaterial.new()
	var sky := Sky.new()
	sky.sky_material = sky_mat
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.tonemap_white = 1.6
	env.fog_enabled = true
	env.glow_enabled = true
	env.glow_intensity = 0.35
	env.glow_hdr_threshold = 1.6
	env.glow_bloom = 0.0
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)
	sun = DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-52, -35, 0)
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 260.0
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
	add_child(sun)
	_apply_daytime()


func _apply_daytime() -> void:
	if night:
		sky_mat.sky_top_color = Color("101826")
		sky_mat.sky_horizon_color = Color("2a3346")
		sky_mat.ground_horizon_color = Color("2a3346")
		sky_mat.ground_bottom_color = Color("101826")
		env.ambient_light_energy = 0.3
		env.fog_light_color = Color("222b3c")
		env.fog_density = 0.0022
		sun.light_color = Color("c4d0f0")
		sun.light_energy = 0.35
	else:
		sky_mat.sky_top_color = Color("8fb4d4")
		sky_mat.sky_horizon_color = Color("e2ebf2")
		sky_mat.ground_horizon_color = Color("e2ebf2")
		sky_mat.ground_bottom_color = Color("c9d6e0")
		env.ambient_light_energy = 0.4
		env.fog_light_color = Color("dde7ef")
		env.fog_density = 0.0012
		sun.light_color = Color("fff1dc")
		sun.light_energy = 0.95


# ================================================================ ضباب الحرب
func _setup_fog() -> void:
	## طائرة معتمة فوق الخريطة تُختفي حيث كُشف — والكشف نفسه منطق في Game
	fog_img = _fog_image()
	fog_tex = ImageTexture.create_from_image(fog_img)
	var sh := Shader.new()
	sh.code = FOG_SHADER
	var mat := ShaderMaterial.new()
	mat.shader = sh
	mat.set_shader_parameter("fog_tex", fog_tex)
	var mi := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(1200, 1200)
	mi.mesh = pm
	mi.material_override = mat
	mi.position = Vector3(600, 4.5, 600)
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mi)

func _update_fog() -> void:
	## تُستدعى عند كشف مناطق جديدة: تحديث النسيج وإظهار لوحات المناطق المكشوفة
	if fog_img == null:
		return
	for fl in fog_labels:
		(fl["label"] as Label3D).visible = Game.is_explored(int(fl["x"]), int(fl["y"]))
	if vent_node != null:
		vent_node.visible = Game.is_explored(int(Game.vent["x"]), int(Game.vent["y"]))
	fog_img = _fog_image()
	fog_tex.update(fog_img)

func _fog_image() -> Image:
	## بايتات الحالة 0/1 تتحول إلى 0/255 في النسيج — وإلا بقيت الخريطة كلها مغطاة
	var bytes := PackedByteArray()
	bytes.resize(Game.explored.size())
	for i in range(Game.explored.size()):
		bytes[i] = 255 if Game.explored[i] > 0 else 0
	return Image.create_from_data(Defs.FOG_GRID, Defs.FOG_GRID, false, Image.FORMAT_R8, bytes)

# ================================================================ توزيع العناصر
func _find_mesh(n: Node) -> MeshInstance3D:
	if n is MeshInstance3D:
		return n
	for c in n.get_children():
		var r := _find_mesh(c)
		if r:
			return r
	return null


## نضمن أن ألوان الرؤوس (Vertex Colors) تُستخدم كلون أساسي للمواد
func _fix_mesh(m: Mesh) -> void:
	for s in m.get_surface_count():
		var mat := m.surface_get_material(s) as BaseMaterial3D
		if mat:
			mat.vertex_color_use_as_albedo = true
			if mat.resource_name == "Snow" or mat.resource_name == "Matte":
				mat.metallic_specular = 0.25


func _fix_materials(n: Node) -> void:
	if n is MeshInstance3D and n.mesh:
		_fix_mesh(n.mesh)
	for c in n.get_children():
		_fix_materials(c)


func _mesh_from(path: String) -> Mesh:
	var inst: Node = load(path).instantiate()
	var mi := _find_mesh(inst)
	var m: Mesh = mi.mesh
	_fix_mesh(m)
	inst.free()
	return m


func _spawn_group(mesh: Mesh, items: Array) -> void:
	var regions := {}
	for it in items:
		var key := Vector2i(int(it["x"]) / 300, int(it["y"]) / 300)
		if not regions.has(key):
			regions[key] = []
		regions[key].append(it)
	for key in regions:
		var arr: Array = regions[key]
		var mm := MultiMesh.new()
		mm.transform_format = MultiMesh.TRANSFORM_3D
		mm.mesh = mesh
		mm.instance_count = arr.size()
		for i in arr.size():
			var it: Dictionary = arr[i]
			var ry: float = it.get("ry", fmod(it["x"] * 12.9898 + it["y"] * 78.233, TAU))
			var b := Basis(Vector3.UP, ry)
			mm.set_instance_transform(i, Transform3D(b, Vector3(it["x"], it["h"], it["y"])))
		var mmi := MultiMeshInstance3D.new()
		mmi.multimesh = mm
		add_child(mmi)


func _reg(x0: int, y0: int, w: int, info: Dictionary) -> void:
	for dx in w:
		for dy in w:
			lookup[Vector2i(x0 + dx, y0 + dy)] = info


func _label3d(text: String, pos: Vector3, size: int, color: Color, range_end: float) -> Label3D:
	var l := Label3D.new()
	l.text = text
	l.font = font
	l.font_size = size
	l.outline_size = int(size * 0.22)
	l.modulate = color
	l.outline_modulate = Color(0.04, 0.08, 0.14, 0.9)
	l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	l.fixed_size = true
	l.pixel_size = 0.0009
	l.no_depth_test = true
	l.position = pos
	if range_end > 0:
		l.visibility_range_end = range_end
	add_child(l)
	return l


func _spawn_all() -> void:
	# الموارد
	for t in RES_NAMES:
		var items: Array = data["resources"].filter(func(r): return r["t"] == t)
		_spawn_group(_mesh_from("res://assets/res_%s.glb" % t), items)
		for r in items:
			_reg(int(r["x"]), int(r["y"]), 1, {"kind": "res", "t": t, "l": r["l"],
					"x": int(r["x"]), "y": int(r["y"]), "pos": Vector3(r["x"], r["h"], r["y"])})
	# الوحوش
	for t in BEAST_NAMES:
		var items: Array = data["beasts"].filter(func(b): return b["t"] == t)
		_spawn_group(_mesh_from("res://assets/beast_%s.glb" % t), items)
		for b in items:
			_reg(int(b["x"]), int(b["y"]), 1, {"kind": "beast", "t": t, "l": b["l"],
					"x": int(b["x"]), "y": int(b["y"]), "pos": Vector3(b["x"], b["h"], b["y"])})
	# المدن
	for team in ["ally", "enemy", "neutral"]:
		var items: Array = data["cities"].filter(func(c): return c["team"] == team)
		_spawn_group(_mesh_from("res://assets/city_%s.glb" % team), items)
		var col: Color = {"ally": Color("8fd0ff"), "enemy": Color("ff9a8a"), "neutral": Color("f2f2f2")}[team]
		for c in items:
			var p := Vector3(c["x"], c["h"], c["y"])
			_reg(int(c["x"]) - 1, int(c["y"]) - 1, 2, {"kind": "city", "n": c["n"], "team": team,
					"l": c["l"], "x": int(c["x"]), "y": int(c["y"]), "pos": p})
			var cl := _label3d("%s  %d" % [c["n"], c["l"]], p + Vector3(0, 3.2, 0), 26, col, 75.0)
			fog_labels.append({"label": cl, "x": int(c["x"]), "y": int(c["y"])})
	# مدينتك
	var h: Dictionary = data["home"]
	h["x"] = Game.home.x + 0.5
	h["y"] = Game.home.y + 0.5
	h["l"] = Game.furnace_level()
	h["n"] = "مدينتي"
	home_pos = Vector3(h["x"], h["h"], h["y"])
	home_node = MeshInstance3D.new()
	home_node.mesh = _mesh_from("res://assets/city_me.glb")
	home_node.position = home_pos
	add_child(home_node)
	home_label = _label3d("%s  %d" % [h["n"], h["l"]], home_pos + Vector3(0, 3.4, 0), 32, Color("ffd36b"), 0)
	home_info = {"kind": "city", "n": h["n"], "team": "me", "l": h["l"], "x": Game.home.x, "y": Game.home.y, "pos": home_pos}
	_reg(Game.home.x - 1, Game.home.y - 1, 2, home_info)
	# المعالم (مبنية داخل frost_map.glb) — نضيف الأسماء ومناطق الضغط
	for L in data["landmarks"]:
		var p := Vector3(L["x"], L["h"], L["y"])
		var r: int = L["r"]
		var info := {"kind": "lm", "n": L["name"], "type": L["type"], "id": L["id"],
			"x": int(L["x"]), "y": int(L["y"]), "pos": p, "r": r}
		_reg(int(L["x"]) - r, int(L["y"]) - r, r * 2 + 1, info)
		var big: bool = L["type"] == "sun_city"
		var lh: float = {"sun_city": 26.0, "stronghold": 14.0, "fortress": 12.0}.get(L["type"], 8.0)
		var ll := _label3d(L["name"], p + Vector3(0, lh, 0), 44 if big else 34,
				Color("ffd36b") if big else Color("ffffff"), 0.0 if big else 420.0)
		fog_labels.append({"label": ll, "x": int(L["x"]), "y": int(L["y"])})
	# المرحلة 3: المنفث الحراري الجوفي — ارتفاعه من التضاريس نفسها
	var vx := float(Game.vent["x"]) + 0.5
	var vz := float(Game.vent["y"]) + 0.5
	var vy := _terrain_height_at(vx, vz)
	var vp := Vector3(vx, vy + 0.3, vz)
	vent_node = MeshInstance3D.new()
	vent_node.mesh = _mesh_from("res://assets/city/crystal.glb")
	vent_node.position = vp
	vent_node.scale = Vector3.ONE * 1.8
	add_child(vent_node)
	vent_label = _label3d("المنفث الحراري", vp + Vector3(0, 4.4, 0), 30, Color("ffb066"), 0.0)
	fog_labels.append({"label": vent_label, "x": int(Game.vent["x"]), "y": int(Game.vent["y"])})
	_reg(int(Game.vent["x"]), int(Game.vent["y"]), 1, {"kind": "vent",
			"x": int(Game.vent["x"]), "y": int(Game.vent["y"]), "pos": vp})
	# حلقة التحديد
	sel_ring = MeshInstance3D.new()
	var torus := TorusMesh.new()
	torus.inner_radius = 0.94
	torus.outer_radius = 1.0
	torus.rings = 48
	sel_ring.mesh = torus
	var rm := StandardMaterial3D.new()
	rm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	rm.albedo_color = Color("ffd36b")
	rm.no_depth_test = true
	sel_ring.material_override = rm
	sel_ring.visible = false
	add_child(sel_ring)
	# القوات
	troop_mesh = _mesh_from("res://assets/troop.glb")
	march_mat = StandardMaterial3D.new()
	march_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	march_mat.albedo_color = Color("7fd3ff")
	march_mat.no_depth_test = true
	march_mat.cull_mode = BaseMaterial3D.CULL_DISABLED


# ================================================================ الكاميرا والثلج
func _setup_camera() -> void:
	rig = StrategyCamera.new()
	rig.map_size = float(data["size"])
	add_child(rig)
	rig.ui_hit_test = _over_ui
	rig.tapped.connect(_on_tap)
	rig.view_changed.connect(_on_view)
	rig.set_view(home_pos, 34.0)

	snow = CPUParticles3D.new()
	snow.amount = 900
	snow.lifetime = 6.0
	snow.preprocess = 6.0
	snow.local_coords = true
	snow.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	snow.emission_box_extents = Vector3(60, 1, 60)
	snow.direction = Vector3(0.3, -1, 0.1)
	snow.spread = 12.0
	snow.gravity = Vector3(0, -2.0, 0)
	snow.initial_velocity_min = 3.0
	snow.initial_velocity_max = 6.0
	var q := SphereMesh.new()
	q.radius = 0.07
	q.height = 0.14
	q.radial_segments = 6
	q.rings = 3
	var sm := StandardMaterial3D.new()
	sm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	sm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	sm.albedo_color = Color(1, 1, 1, 0.85)
	q.material = sm
	snow.mesh = q
	rig.add_child(snow)


func _on_view(f: Vector3, d: float) -> void:
	if coord_label:
		coord_label.text = "X: %d   Y: %d" % [int(f.x), int(f.z)]
	if env:
		env.fog_density = (0.0022 if night else 0.0012) * clampf(60.0 / d, 0.25, 1.5)
	if snow:
		var s := clampf(d * 0.9, 40.0, 200.0)
		snow.emission_box_extents = Vector3(s, 1, s)
		snow.position = Vector3(0, clampf(d * 0.45, 18.0, 90.0), 0)
		snow.scale = Vector3.ONE * clampf(d / 60.0, 1.0, 3.0)


# ================================================================ الواجهة
func _style(bg: Color, radius: int = 14) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.set_corner_radius_all(radius)
	s.content_margin_left = 16
	s.content_margin_right = 16
	s.content_margin_top = 8
	s.content_margin_bottom = 8
	s.border_color = Color(1, 1, 1, 0.12)
	s.set_border_width_all(1)
	return s


func _button(text: String, cb: Callable, accent := false) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(0, 56)
	b.add_theme_stylebox_override("normal", _style(Color("e0a33a") if accent else Color(0.07, 0.12, 0.2, 0.86)))
	b.add_theme_stylebox_override("hover", _style(Color("f0b54a") if accent else Color(0.12, 0.2, 0.32, 0.92)))
	b.add_theme_stylebox_override("pressed", _style(Color("c78a25") if accent else Color(0.04, 0.08, 0.14, 0.95)))
	b.add_theme_color_override("font_color", Color("1a1206") if accent else Color.WHITE)
	b.add_theme_color_override("font_hover_color", Color("1a1206") if accent else Color.WHITE)
	b.add_theme_color_override("font_pressed_color", Color("1a1206") if accent else Color.WHITE)
	b.pressed.connect(cb)
	b.pressed.connect(func() -> void: Sound.ui_click())
	return b


func _panel(anchor_preset: int) -> PanelContainer:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", _style(Color(0.05, 0.1, 0.17, 0.82)))
	ui.add_child(p)
	p.set_anchors_and_offsets_preset(anchor_preset, Control.PRESET_MODE_MINSIZE, 14)
	ui_blockers.append(p)
	return p


func _setup_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	ui = Control.new()
	ui.set_anchors_preset(Control.PRESET_FULL_RECT)
	ui.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var th := Theme.new()
	th.default_font = font
	th.default_font_size = 20
	ui.theme = th
	layer.add_child(ui)

	# أعلى اليمين: اسم الخريطة + الإحداثيات
	var tr := _panel(Control.PRESET_TOP_RIGHT)
	tr.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	var v := VBoxContainer.new()
	tr.add_child(v)
	var title := Label.new()
	title.text = "خريطة الصقيع • 1200×1200"
	title.add_theme_color_override("font_color", Color("ffd36b"))
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	v.add_child(title)
	coord_label = Label.new()
	coord_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	v.add_child(coord_label)

	# أعلى اليسار: الموارد
	var tl := _panel(Control.PRESET_TOP_LEFT)
	var rv := VBoxContainer.new()
	tl.add_child(rv)
	res_label = Label.new()
	res_label.add_theme_font_size_override("font_size", 17)
	rv.add_child(res_label)
	march_label = Label.new()
	march_label.add_theme_font_size_override("font_size", 15)
	march_label.add_theme_color_override("font_color", Color("7fd3ff"))
	rv.add_child(march_label)
	holds_label = Label.new()
	holds_label.add_theme_font_size_override("font_size", 15)
	holds_label.add_theme_color_override("font_color", Color("a9f0a0"))
	rv.add_child(holds_label)
	front_label = Label.new()
	front_label.add_theme_font_size_override("font_size", 15)
	front_label.add_theme_color_override("font_color", Color("9fb8d0"))
	rv.add_child(front_label)
	_refresh_stock()

	# أسفل اليمين: أزرار التنقل
	var br := HBoxContainer.new()
	br.add_theme_constant_override("separation", 10)
	ui.add_child(br)
	br.add_child(_button("الليل/النهار", _toggle_night))
	br.add_child(_button("الخريطة كاملة", func(): rig.fly_to(Vector3(600, 0, 600), 300.0, 1.0)))
	br.add_child(_button("مدينة الشمس", func(): rig.fly_to(Vector3(600, 0, 600), 95.0)))
	br.add_child(_button("مدينتي", func(): rig.fly_to(home_pos, 34.0)))
	br.add_child(_button("دخول المدينة", _go_city, true))
	br.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT, Control.PRESET_MODE_MINSIZE, 14)
	br.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	br.grow_vertical = Control.GROW_DIRECTION_BEGIN
	ui_blockers.append(br)

	# لوحة المعلومات (أسفل اليسار)
	panel = PanelContainer.new()
	panel.add_theme_stylebox_override("panel", _style(Color(0.05, 0.1, 0.17, 0.9), 18))
	panel.custom_minimum_size = Vector2(360, 0)
	ui.add_child(panel)
	ui_blockers.append(panel)
	var pv := VBoxContainer.new()
	pv.add_theme_constant_override("separation", 6)
	panel.add_child(pv)
	p_title = Label.new()
	p_title.add_theme_font_size_override("font_size", 24)
	p_title.add_theme_color_override("font_color", Color("ffd36b"))
	p_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	pv.add_child(p_title)
	p_sub = Label.new()
	p_sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	p_sub.add_theme_color_override("font_color", Color("b9cbe0"))
	pv.add_child(p_sub)
	p_info = Label.new()
	p_info.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	p_info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	p_info.add_theme_font_size_override("font_size", 17)
	pv.add_child(p_info)
	var ph := HBoxContainer.new()
	ph.add_theme_constant_override("separation", 10)
	pv.add_child(ph)
	var close := _button("إغلاق", _close_panel)
	close.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	ph.add_child(close)
	p_action = _button("إرسال قوات", _on_action, true)
	p_action.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	ph.add_child(p_action)
	panel.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_LEFT, Control.PRESET_MODE_MINSIZE, 14)
	panel.grow_vertical = Control.GROW_DIRECTION_BEGIN
	panel.visible = false

	# رسالة عائمة
	toast = Label.new()
	toast.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	toast.add_theme_stylebox_override("normal", _style(Color(0.04, 0.08, 0.14, 0.85), 20))
	ui.add_child(toast)
	toast.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP, Control.PRESET_MODE_MINSIZE, 92)
	toast.grow_horizontal = Control.GROW_DIRECTION_BOTH
	toast.mouse_filter = Control.MOUSE_FILTER_IGNORE

	_on_view(rig.focus, rig.dist)


func _over_ui(p: Vector2) -> bool:
	for c in ui_blockers:
		if c.is_visible_in_tree() and c.get_global_rect().has_point(p):
			return true
	return false


func _refresh_stock() -> void:
	res_label.text = "طعام %s   خشب %s\nفحم %s   حديد %s" % [Defs.fmt(Game.res["food"]), Defs.fmt(Game.res["wood"]),
			Defs.fmt(Game.res["coal"]), Defs.fmt(Game.res["iron"])]
	march_label.text = "الفرق في مهمة: %d / %d" % [Game.marches.size(), Game.MAX_MARCHES]
	if holds_label != null:
		holds_label.text = "معاقل: %d/4 • قلاع: %d/8" % [Game.holds_count("stronghold"), Game.holds_count("fortress")]


func _fmt(n: int) -> String:
	if n >= 1000000:
		return "%.1fM" % (n / 1000000.0)
	if n >= 1000:
		return "%.1fK" % (n / 1000.0)
	return str(n)


func _toast(t: String) -> void:
	toast.text = t
	toast.modulate.a = 1.0
	toast.visible = true
	toast_time = 3.0


func _go_city() -> void:
	Game.save_game()
	get_tree().change_scene_to_file("res://city.tscn")


func _toggle_night() -> void:
	night = not night
	_apply_daytime()
	_on_view(rig.focus, rig.dist)


# ================================================================ الاختيار
func _on_tap(world: Vector3, _sp: Vector2) -> void:
	var tile := Vector2i(floori(world.x), floori(world.z))
	if tile.x < 0 or tile.y < 0 or tile.x >= 1200 or tile.y >= 1200:
		return
	var info: Dictionary = lookup.get(tile, {})
	if not Game.is_explored(tile.x, tile.y):
		# منطقة مجهولة: لا تسرّب أي تفاصيل عن الكيانات فوقها
		info = {"kind": "unknown", "x": tile.x, "y": tile.y, "pos": Vector3(tile.x + 0.5, world.y, tile.y + 0.5)}
	elif info.is_empty():
		info = {"kind": "empty", "x": tile.x, "y": tile.y, "pos": Vector3(tile.x + 0.5, world.y, tile.y + 0.5)}
	_select(info)


func _select(info: Dictionary) -> void:
	selected = info
	var pos: Vector3 = info["pos"]
	var rr := 1.0
	match info["kind"]:
		"res":
			p_title.text = "%s  Lv.%d" % [RES_NAMES[info["t"]], info["l"]]
			p_sub.text = "مورد قابل للجمع"
			p_info.text = "الكمية المتوقعة: %s" % _fmt(RES_GAIN[info["t"]] * info["l"])
			p_action.text = "جمع"
			rr = 0.9
		"beast":
			p_title.text = "%s  Lv.%d" % [BEAST_NAMES[info["t"]], info["l"]]
			p_sub.text = "وحش بري"
			p_info.text = "القوة المقدّرة: %s" % _fmt(info["l"] * 3500)
			p_action.text = "هجوم"
			rr = 1.0
		"city":
			p_title.text = "%s  Lv.%d" % [info["n"], info["l"]]
			p_sub.text = TEAM_NAMES[info["team"]]
			p_info.text = "مدينة لاعب"
			p_action.text = {"me": "دخول المدينة", "ally": "تعزيز", "enemy": "هجوم", "neutral": "استطلاع"}[info["team"]]
			rr = 1.6
		"lm":
			p_title.text = info["n"]
			if info["type"] == "stronghold" or info["type"] == "fortress":
				var hd: Dictionary = Defs.HOLD_DEFS[info["type"]]
				if Game.holds.has(String(info["id"])):
					p_sub.text = "تحت سيطرتك"
					p_info.text = "المكافأة الدائمة سارية: %s" % hd["eff"]
					p_action.text = "تفاصيل"
				else:
					p_sub.text = "%s — يحرسه حرّاس" % hd["name"]
					p_info.text = "احتلاله يمنح مكافأة دائمة: %s" % hd["eff"]
					p_action.text = "أرسل فرقة عسكرية"
			else:
				p_sub.text = LM_TYPES[info["type"]]
				p_info.text = "منطقة قابلة للاحتلال في حرب التحالفات"
				p_action.text = "احتلال"
			rr = float(info["r"]) + 0.5
		"vent":
			if Game.vent.get("captured", false):
				p_title.text = "المنفث الحراري — تحت سيطرتك"
				p_sub.text = "منفث جوفي دافئ"
				p_info.text = "يمنح المدينة +%d° دفئًا دائمًا ويخفف أثر جبهات الصقيع" % int(Defs.VENT_HEAT)
				p_action.text = "تفاصيل"
			else:
				p_title.text = "المنفث الحراري"
				p_sub.text = "منفث جوفي دافئ — يحرسه وحوش"
				p_info.text = "احتلاله يمنح المدينة +%d° دفئًا دائمًا — أرسل فرقة عسكرية" % int(Defs.VENT_HEAT)
				p_action.text = "أرسل فرقة عسكرية"
			rr = 1.2
		"unknown":
			p_title.text = "منطقة غير مستكشفة"
			p_sub.text = "ضباب الحرب"
			p_info.text = "أرسل فرقة استطلاع لتكشف ما حول هذه المنطقة"
			p_action.text = "إرسال استطلاع"
			rr = 1.2
		_:
			p_title.text = "أرض ثلجية"
			p_sub.text = "خانة فارغة"
			p_info.text = "يمكنك نقل مدينتك إلى هنا"
			p_action.text = "نقل المدينة"
			rr = 1.2
	p_sub.text += "   •   X: %d  Y: %d" % [info["x"], info["y"]]
	panel.visible = true
	sel_ring.visible = true
	sel_ring.position = pos + Vector3(0, 0.15, 0)
	sel_rr = rr


func _close_panel() -> void:
	panel.visible = false
	sel_ring.visible = false
	selected = {}


func _on_action() -> void:
	if selected.is_empty():
		return
	var info := selected
	if info["kind"] == "unknown":
		_send_scout(info)
	elif info["kind"] == "empty":
		_move_home(info)
	elif info["kind"] == "city" and info["team"] == "me":
		_go_city()
	elif info["kind"] == "city" and info["team"] != "neutral" and info["team"] != "enemy":
		_toast("ميزة التعزيز ستتوفر مع نظام الجيش في المرحلة القادمة")
	elif info["kind"] == "lm" and (info["type"] == "stronghold" or info["type"] == "fortress"):
		if Game.holds.has(String(info["id"])):
			_toast("هذا الموقع تحت سيطرتك — المكافأة الدائمة سارية")
		elif not Game.venture.is_empty():
			_toast("الفرقة العسكرية في مهمة بالفعل")
		else:
			_open_venture_window({"kind": "hold", "id": String(info["id"]), "n": String(info["n"])})
	elif info["kind"] == "vent":
		if Game.vent.get("captured", false):
			_toast("المنفث يحرسه جيشك — الدفء مستمر ما دام بيدك")
		elif not Game.venture.is_empty():
			_toast("الفرقة العسكرية في طريقها إلى المنفث")
		else:
			_open_vent_window()
	elif Game.start_march(info):
		Sound.play("march")
		var m: Dictionary = Game.marches.back()
		_toast("انطلقت الفرقة — الوصول خلال %s" % Defs.fmt_time(float(m["arrive"]) - Game.now()))
	_close_panel()


func _move_home(info: Dictionary) -> void:
	if not Game.is_explored(int(info["x"]), int(info["y"])):
		# النقل المجاني لا يتجاوز الاستطلاع: لا كشف بلا حدود ولا مدينة في المجهول
		_toast("لا يمكن نقل المدينة إلى منطقة غير مستكشفة")
		return
	for dx in 2:
		for dy in 2:
			lookup.erase(Vector2i(home_info["x"] - 1 + dx, home_info["y"] - 1 + dy))
	var p: Vector3 = info["pos"]
	home_pos = Vector3(info["x"] + 0.5, p.y, info["y"] + 0.5)
	home_info["x"] = info["x"]
	home_info["y"] = info["y"]
	home_info["pos"] = home_pos
	_reg(info["x"] - 1, info["y"] - 1, 2, home_info)
	home_node.position = home_pos
	home_label.position = home_pos + Vector3(0, 3.4, 0)
	Game.home = Vector2i(info["x"], info["y"])
	Game.save_game()
	_toast("تم نقل مدينتك إلى X: %d  Y: %d" % [info["x"], info["y"]])


# ================================================================ المرحلة 3: نافذة الفرقة العسكرية
func _open_vent_window() -> void:
	_open_venture_window({})

func _open_venture_window(target: Dictionary) -> void:
	## نافذة إرسال الفرقة العسكرية — تصلح للمنفث وللمعاقل والقلاع، والتشكيل يُختار هنا
	venture_target = target
	venture_formation = "balanced"
	_close_vent_window()
	vent_win = _panel(Control.PRESET_CENTER)
	vent_win.custom_minimum_size = Vector2(440, 0)
	var v := VBoxContainer.new()
	vent_win.add_child(v)
	var title := Label.new()
	var tname := "المنفث الحراري"
	if not target.is_empty() and str(target.get("kind", "vent")) == "hold":
		tname = str(target.get("n", "الهدف"))
	title.text = "الفرقة العسكرية نحو " + tname
	title.add_theme_color_override("font_color", Color("ffd36b"))
	v.add_child(title)
	var hint := Label.new()
	hint.text = "الجنود المرسلون يغادرون المدينة: لن يشاركوا في الدفاع حتى يعودوا. اختر تشكيل القتال — يُثبّت مع ظروف المعركة عند الإرسال."
	hint.add_theme_font_size_override("font_size", 15)
	hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	v.add_child(hint)
	# صفوف الجنود داخل حاوية تمرير محدودة الارتفاع — حتى لا تتجاوز النافذة شاشة الهاتف
	var scroll := ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(0, 240)
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.add_child(scroll)
	var list := VBoxContainer.new()
	list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(list)
	vent_spins = {}
	var any_troops := false
	for k in Game.troops:
		var n := int(Game.troops[k])
		if n <= 0:
			continue
		any_troops = true
		var row := HBoxContainer.new()
		list.add_child(row)
		var parts: PackedStringArray = String(k).split("_")
		var nm := "%s • %s" % [Defs.TROOPS[parts[0]]["name"], Defs.TIER_NAMES[int(parts[1])]]
		var l := Label.new()
		l.text = "%s (متاح %d)" % [nm, n]
		l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(l)
		var sp := SpinBox.new()
		sp.max_value = n
		sp.min_value = 0
		sp.step = 1
		sp.value = mini(n, 10)
		row.add_child(sp)
		vent_spins[k] = sp
	if not any_troops:
		var empty := Label.new()
		empty.text = "لا يوجد جنود — درّب جيشًا من المعسكر أولًا"
		empty.add_theme_color_override("font_color", Color("ff9a8a"))
		v.add_child(empty)
	# التشكيلات القتالية: ثلاثة أزرار تِبادل
	var ftitle := Label.new()
	ftitle.text = "تشكيل القتال"
	ftitle.add_theme_color_override("font_color", Color("ffd36b"))
	v.add_child(ftitle)
	var fh := HBoxContainer.new()
	fh.add_theme_constant_override("separation", 8)
	v.add_child(fh)
	_formation_btns = {}
	for fid in Defs.FORMATION_ORDER:
		var fd: Dictionary = Defs.FORMATIONS[fid]
		var fb := _button(fd["name"], func(): _pick_formation(String(fid)))
		fb.toggle_mode = true
		fb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		fb.tooltip_text = str(fd["desc"])
		fh.add_child(fb)
		_formation_btns[fid] = fb
	_pick_formation("balanced")
	var fdesc := Label.new()
	fdesc.add_theme_font_size_override("font_size", 14)
	fdesc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	fdesc.add_theme_color_override("font_color", Color("b9cbe0"))
	v.add_child(fdesc)
	_formation_desc = fdesc
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 10)
	v.add_child(hb)
	var send := _button("إرسال الفرقة", func(): _send_venture(), true)
	send.disabled = not any_troops
	hb.add_child(send)
	hb.add_child(_button("إلغاء", _close_vent_window))
	ui_blockers.append(vent_win)
	_center_vent_win_soon()

func _center_vent_win_soon() -> void:
	## ينتظر استقرار التخطيط أولًا — القياس قبل التخطيط يعطي ارتفاعًا مؤقتًا ضخمًا للنص الملتف
	await get_tree().process_frame
	_center_vent_win()

func _center_vent_win() -> void:
	## توسيط فعلي بعد اكتمال المحتوى — النافذة تنمو للأسفل من نقطة الوسط فتغطي أزرار التنقل السفلية
	if vent_win == null or ui == null:
		return
	var h := minf(vent_win.size.y, ui.size.y - 96.0)
	vent_win.size = Vector2(maxf(vent_win.size.x, 440.0), h)
	vent_win.position = (ui.size - vent_win.size) * 0.5

var _formation_desc: Label = null

func _pick_formation(fid: String) -> void:
	venture_formation = fid
	for k in _formation_btns:
		(_formation_btns[k] as Button).button_pressed = String(k) == fid
	if _formation_desc != null:
		_formation_desc.text = str(Defs.FORMATIONS[fid]["desc"])

func _close_vent_window() -> void:
	if vent_win != null:
		ui_blockers.erase(vent_win)
		vent_win.queue_free()
		vent_win = null
	vent_spins = {}
	_formation_desc = null

func _send_venture() -> void:
	var units := {}
	for k in vent_spins:
		var n := int(vent_spins[k].value)
		if n > 0:
			units[k] = n
	var tgt := venture_target
	if Game.start_venture(units, venture_formation, tgt):
		Sound.play("march")
		_toast("انطلقت الفرقة العسكرية بتشكيل «%s»" % Defs.FORMATIONS[venture_formation]["name"])
		_close_vent_window()
		_close_panel()

func _send_scout(info: Dictionary) -> void:
	## فرقة استطلاع نحو منطقة مجهولة: تشغل خانة فرق، وتكشف عند الوصول ثم تعود
	if Game.marches.size() >= Game.MAX_MARCHES:
		_toast("كل الفرق في مهمة — انتظر عودة إحداها")
		return
	if Game.start_march({"kind": "scout", "x": int(info["x"]), "y": int(info["y"])}):
		Sound.play("march")
		var m: Dictionary = Game.marches.back()
		_toast("انطلقت فرقة الاستطلاع — الوصول خلال %s" % Defs.fmt_time(float(m["arrive"]) - Game.now()))
		_close_panel()


# ================================================================ المسيرات (مصدرها Game.marches)
var march_vis := {}   # start time -> {troop, line, im}


func _march_pos(m: Dictionary, t: float) -> Array:
	## [الموقع، الوجهة الحالية للرسم]
	var a := Vector3(m["fx"], 0, m["fy"])
	var b := Vector3(m["tx"], 0, m["ty"])
	if t < float(m["arrive"]):
		var k := inverse_lerp(float(m["start"]), float(m["arrive"]), t)
		return [a.lerp(b, k), b]
	if t < float(m["leave"]):
		return [b, b]
	var k2 := inverse_lerp(float(m["leave"]), float(m["back"]), t)
	return [b.lerp(a, clampf(k2, 0.0, 1.0)), a]


func _sync_marches() -> void:
	var alive := {}
	for m in Game.marches:
		var key := str(m["start"])
		alive[key] = true
		if not march_vis.has(key):
			var troop := MeshInstance3D.new()
			troop.mesh = troop_mesh
			add_child(troop)
			var line := MeshInstance3D.new()
			var im := ImmediateMesh.new()
			line.mesh = im
			line.material_override = march_mat
			line.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			add_child(line)
			march_vis[key] = {"troop": troop, "line": line, "im": im}
	# المرحلة 3: الفرقة العسكرية نحو المنفث (مفتاح ثابت ولون مميز)
	# يُسجل قبل حلقة التنظيف حتى لا يُهدم ويُعاد بناؤه كل إطار
	if not Game.venture.is_empty():
		alive["venture"] = true
		if not march_vis.has("venture"):
			var troop := MeshInstance3D.new()
			troop.mesh = troop_mesh
			add_child(troop)
			var line := MeshInstance3D.new()
			var im := ImmediateMesh.new()
			line.mesh = im
			var vm: StandardMaterial3D = march_mat.duplicate() as StandardMaterial3D
			vm.albedo_color = Color("ff9a4a")
			line.material_override = vm
			line.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			add_child(line)
			march_vis["venture"] = {"troop": troop, "line": line, "im": im}
	for key in march_vis.keys():
		if not alive.has(key):
			(march_vis[key]["troop"] as Node).queue_free()
			(march_vis[key]["line"] as Node).queue_free()
			march_vis.erase(key)


func _draw_dashes(im: ImmediateMesh, a: Vector3, b: Vector3, phase: float) -> void:
	im.clear_surfaces()
	var d := b - a
	d.y = 0
	var length := d.length()
	if length < 0.6:
		return
	var dir := d / length
	var side := Vector3(-dir.z, 0, dir.x) * 0.22
	var y := 0.6
	im.surface_begin(Mesh.PRIMITIVE_TRIANGLES)
	var s := fmod(phase, 1.6)
	if s < 0:
		s += 1.6
	while s < length:
		var e := minf(s + 0.9, length)
		var p0 := Vector3(a.x, y, a.z) + dir * s
		var p1 := Vector3(a.x, y, a.z) + dir * e
		im.surface_add_vertex(p0 - side)
		im.surface_add_vertex(p0 + side)
		im.surface_add_vertex(p1 + side)
		im.surface_add_vertex(p0 - side)
		im.surface_add_vertex(p1 + side)
		im.surface_add_vertex(p1 - side)
		s += 1.6
	im.surface_end()


func _process(delta: float) -> void:
	if toast_time > 0:
		toast_time -= delta
		toast.modulate.a = clampf(toast_time / 0.6, 0.0, 1.0)
		if toast_time <= 0:
			toast.visible = false
	if sel_ring.visible:
		var k := (1.0 + sin(Time.get_ticks_msec() / 180.0) * 0.06) * sel_rr
		sel_ring.scale = Vector3(k, 1, k)
	# المرحلة 3: مؤشر جبهة الصقيع وأثرها البصري
	if Game.front_active() != _front_on:
		_front_on = Game.front_active()
		_apply_daytime()
		if _front_on:
			env.fog_density += 0.0016
			sun.light_energy *= 0.7
	if front_label != null:
		if _front_on:
			front_label.text = "جبهة صقيع نشطة: الحرارة الخارجية ناقص %d° إضافية" % int(Defs.FRONT_DROP)
			front_label.add_theme_color_override("font_color", Color("ff9a8a"))
		else:
			front_label.text = "الجبهة القادمة بعد %s" % Defs.fmt_time(Game.front_eta())
			front_label.add_theme_color_override("font_color", Color("9fb8d0"))
	if vent_label != null:
		vent_label.modulate = Color("a9f0a0") if Game.vent.get("captured", false) else Color("ffb066")
	_sync_marches()
	var t := Game.now()
	var t_now := Time.get_ticks_msec() / 1000.0
	for m in Game.marches:
		var key := str(m["start"])
		if not march_vis.has(key):
			continue
		var v: Dictionary = march_vis[key]
		var pr := _march_pos(m, t)
		var p: Vector3 = pr[0]
		var to: Vector3 = pr[1]
		var troop: MeshInstance3D = v["troop"]
		troop.position = Vector3(p.x, 0.35, p.z)
		var dir := to - p
		if dir.length() > 0.05:
			troop.rotation.y = atan2(-dir.z, dir.x)
		_draw_dashes(v["im"], p, to, -t_now * 2.0)
	# المرحلة 3: رسم الفرقة العسكرية نحو المنفث
	if not Game.venture.is_empty() and march_vis.has("venture"):
		var vv: Dictionary = march_vis["venture"]
		var pr2 := _march_pos(Game.venture, t)
		var p2: Vector3 = pr2[0]
		var to2: Vector3 = pr2[1]
		var troop2: MeshInstance3D = vv["troop"]
		troop2.position = Vector3(p2.x, 0.35, p2.z)
		var dir2 := to2 - p2
		if dir2.length() > 0.05:
			troop2.rotation.y = atan2(-dir2.z, dir2.x)
		_draw_dashes(vv["im"], p2, to2, -t_now * 2.0)
