extends Node
## حالة اللعبة الكاملة (Autoload باسم Game)
## الاقتصاد، والحرارة، والسكان، وطابور البناء، والمسيرات، والمهام، والحفظ، والتقدم أثناء الغياب.

const Defs := preload("res://scripts/defs.gd")
const Combat := preload("res://scripts/combat.gd")
const SAVE_PATH := "user://frost_save.json"
var save_path_override := ""   # مسار بديل للاختبارات الآلية حتى لا تُمس حفظة اللاعب
const SAVE_VERSION := 4
const BUILDERS := 2
const MAX_MARCHES := 2
const OFFLINE_CAP := 8.0 * 3600.0
const FREE_SPEEDUP := 180.0

# نظام المطور (خاص بصاحب اللعبة): كل التكاليف مجانية والتسريع فوري — لا يتأثر به اللاعب العادي
const DEV_PASSWORD := "19983010"
var dev_mode := false

signal changed
signal toast(text: String)
signal building_done(plot_id: String)
signal march_done(m: Dictionary)
signal storm_changed(active: bool)
signal raid_happened(report: Dictionary)
signal decision_ready
signal crystals_changed
signal venture_done(report: Dictionary)
signal fog_changed   # تعميق الخريطة: كُشف مناطق جديدة في ضباب الحرب

var res := {}
var gems := 0
var plots := {}          # plot_id -> level
var stored := {}         # plot_id -> float (موارد جاهزة للجمع داخل المبنى)
var queue: Array = []    # [{plot, level, start, end}]
var pop := 0
var sick := 0.0
var furnace_mode := 1    # 0 مطفأ • 1 عادي • 2 مضاعف
var stats := {}
var task_index := 0
var last_daily := ""
var home := Vector2i(790, 842)
var marches: Array = []
var storm_start := 0.0
var storm_end := 0.0
var quality_high := true
var offline_report: Dictionary = {}
var daily_ready := false

# المرحلة الثانية: الجيش والأبطال والأبحاث واللمسات الخاصة
var aurora := 0
var trust := 60.0
var troops := {}         # "shield_1" -> عدد
var wounded := {}        # "shield_1" -> عدد الجرحى
var train := {}          # {key, n, start, end}
var heroes := {}         # id -> {lv, stars, shards, owned}
var defender := ""
var governor := ""
var techs := {}          # id -> مستوى
var research := {}       # {id, lv, start, end}
var crystals: Array = [] # [{x, z, v}]
var raid_next := 0.0
var raid_count := 0
var raid_wins := 0
var last_raid: Dictionary = {}
var raid_unseen := false
var decision_next := 0.0
var pending_decision := -1
var task2_index := 0

# المرحلة 3: جبهة الصقيع (نموذج أولي)
var vent := {}            # {"x": int, "y": int, "captured": bool}
var venture := {}         # المسيرة العسكرية نحو المنفث أو معلم قابل للاحتلال
var front_origin := 0.0   # بدء دورة الجبهات

# تعميق الخريطة: المعاقل والقلاع المحتلة + ضباب الحرب
var holds := {}           # معرف المعلم ← نوعه (stronghold/fortress)
var explored := PackedByteArray()   # شبكة الكشف FOG_GRID×FOG_GRID (0 مجهول، 1 مكشوف)
var _map_data_cache := {}
var _offline := false
var _crystal_acc := 0.0
var _leave_acc := 0.0

# قيم محسوبة لكل لحظة (للواجهة)
var inside_temp := 0.0
var outside_temp := 0.0
var hungry := false
var cold_level := 0      # 0 دافئ • 1 بارد • 2 متجمد
var workers := {}        # plot_id -> عدد العمال
var _grow_acc := 0.0
var _tick_acc := 0.0
var _save_acc := 0.0
var _rng := RandomNumberGenerator.new()


func now() -> float:
	return Time.get_unix_time_from_system()


func _ready() -> void:
	_rng.randomize()
	if not load_game():
		new_game()
	_check_daily()
	recompute()


# ================================================================ لعبة جديدة / حفظ / تحميل
func new_game() -> void:
	res = {"food": 2500, "wood": 1800, "coal": 600, "iron": 0}
	gems = 200
	plots = {}
	for id in Defs.PLOTS:
		plots[id] = 0
	plots["furnace"] = 1
	stored = {}
	queue = []
	pop = 4
	sick = 0.0
	furnace_mode = 1
	stats = {"collected": {"food": 0, "wood": 0, "coal": 0, "iron": 0}, "marches": 0, "built": 0}
	task_index = 0
	last_daily = ""
	home = Vector2i(790, 842)
	marches = []
	_init_stage2({})
	vent = {"x": int(Defs.VENT["x"]), "y": int(Defs.VENT["y"]), "captured": false}
	venture = {}
	holds = {}
	explored = PackedByteArray()
	explored.resize(Defs.FOG_GRID * Defs.FOG_GRID)
	reveal_at(home.x + 0.5, home.y + 0.5, Defs.FOG_REVEAL_HOME)
	# أول جبهة بعد دورة كاملة (15 دقيقة إنذار مسبق) لا فورًا
	front_origin = now() + Defs.FRONT_PERIOD
	_schedule_storm(now() + 420.0)
	save_game()


func _init_stage2(d: Dictionary) -> void:
	aurora = int(d.get("aurora", 0))
	trust = float(d.get("trust", 60.0))
	troops = {}
	wounded = {}
	for tp in Defs.TROOP_ORDER:
		for t in range(1, 5):
			var k := "%s_%d" % [tp, t]
			troops[k] = int(d.get("troops", {}).get(k, 0))
			wounded[k] = int(d.get("wounded", {}).get(k, 0))
	train = d.get("train", {})
	heroes = {}
	for id in Defs.HERO_ORDER:
		var h: Dictionary = d.get("heroes", {}).get(id, {})
		heroes[id] = {"lv": int(h.get("lv", 1)), "stars": int(h.get("stars", 0)), "shards": int(h.get("shards", 0)),
				"owned": bool(h.get("owned", false))}
	defender = str(d.get("defender", ""))
	governor = str(d.get("governor", ""))
	techs = {}
	for id in Defs.TECHS:
		techs[id] = int(d.get("techs", {}).get(id, 0))
	research = d.get("research", {})
	crystals = d.get("crystals", [])
	raid_next = float(d.get("raid_next", 0.0))
	raid_count = int(d.get("raid_count", 0))
	raid_wins = int(d.get("raid_wins", 0))
	last_raid = d.get("last_raid", {})
	raid_unseen = false
	decision_next = float(d.get("decision_next", now() + 240.0))
	pending_decision = int(d.get("pending_decision", -1))
	task2_index = int(d.get("task2_index", 0))
	for k in ["trained", "aurora", "decisions", "research"]:
		if not stats.has(k):
			stats[k] = 0
	# المرحلة 3: المنفث والجبهة (توافق مع الحفظ القديم)
	vent = d.get("vent", {})
	if vent.is_empty():
		vent = {"x": int(Defs.VENT["x"]), "y": int(Defs.VENT["y"]), "captured": false}
	venture = d.get("venture", {})
	if not venture.is_empty():
		# توافق الحفظ القديم: غياب الهدف يعني المنفث، وغياب التشكيل يعني «متوازنة»
		if not venture.has("target"):
			venture["target"] = {"kind": "vent"}
		if not venture.has("formation"):
			venture["formation"] = "balanced"
	front_origin = float(d.get("front_origin", 0.0))
	if front_origin <= 0.0:
		# حفظ قديم: أول جبهة بعد دورة كاملة، ولا تُطبق الجبهة على زمن الغياب السابق
		front_origin = now() + Defs.FRONT_PERIOD
	dev_mode = bool(d.get("dev_mode", false))
	# تعميق الخريطة: المعاقل المحتلة وشبكة الكشف (توافق مع الحفظ القديم)
	holds = d.get("holds", {})
	var eb := str(d.get("explored", ""))
	explored = PackedByteArray()
	if eb != "":
		explored = Marshalls.base64_to_raw(eb)
	if explored.size() != Defs.FOG_GRID * Defs.FOG_GRID:
		# حفظ قديم بلا ضباب: تُكشف منطقة المدينة فقط ويبقى الباقي مجهولًا
		explored = PackedByteArray()
		explored.resize(Defs.FOG_GRID * Defs.FOG_GRID)
		reveal_at(home.x + 0.5, home.y + 0.5, Defs.FOG_REVEAL_HOME)


func _schedule_storm(after: float) -> void:
	storm_start = after + _rng.randf_range(0.0, 360.0)
	storm_end = storm_start + _rng.randf_range(100.0, 160.0)


func _save_path() -> String:
	return save_path_override if save_path_override != "" else SAVE_PATH


func save_game() -> void:
	var d := {
		"v": SAVE_VERSION, "time": now(), "res": res, "gems": gems, "plots": plots, "stored": stored,
		"queue": queue, "pop": pop, "sick": sick, "furnace_mode": furnace_mode, "stats": stats,
		"task_index": task_index, "last_daily": last_daily, "home": [home.x, home.y],
		"marches": marches, "storm": [storm_start, storm_end], "quality_high": quality_high,
		"aurora": aurora, "trust": trust, "troops": troops, "wounded": wounded, "train": train, "heroes": heroes,
		"defender": defender, "governor": governor, "techs": techs, "research": research, "crystals": crystals,
		"raid_next": raid_next, "raid_count": raid_count, "raid_wins": raid_wins, "last_raid": last_raid,
		"decision_next": decision_next, "pending_decision": pending_decision, "task2_index": task2_index,
		"vent": vent, "venture": venture, "front_origin": front_origin, "dev_mode": dev_mode,
		"holds": holds, "explored": Marshalls.raw_to_base64(explored) if not explored.is_empty() else "",
	}
	var f := FileAccess.open(_save_path(), FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(d))


func load_game() -> bool:
	if not FileAccess.file_exists(_save_path()):
		return false
	var d = JSON.parse_string(FileAccess.get_file_as_string(_save_path()))
	if typeof(d) != TYPE_DICTIONARY or int(d.get("v", 0)) < 1 or int(d.get("v", 0)) > SAVE_VERSION:
		return false
	res = d["res"]
	for r in Defs.RES:
		res[r] = float(res.get(r, 0))
	gems = int(d["gems"])
	plots = {}
	for id in Defs.PLOTS:
		plots[id] = int(d["plots"].get(id, 0))
	stored = d["stored"]
	queue = d["queue"]
	for q in queue:
		q["level"] = int(q["level"])
	pop = int(d["pop"])
	sick = float(d["sick"])
	furnace_mode = int(d["furnace_mode"])
	stats = d["stats"]
	task_index = int(d["task_index"])
	last_daily = str(d["last_daily"])
	home = Vector2i(int(d["home"][0]), int(d["home"][1]))
	marches = d["marches"]
	storm_start = float(d["storm"][0])
	storm_end = float(d["storm"][1])
	quality_high = bool(d.get("quality_high", true))
	_init_stage2(d)
	# التقدم أثناء الغياب
	var t0 := float(d["time"])
	var elapsed := clampf(now() - t0, 0.0, OFFLINE_CAP)
	if elapsed > 60.0:
		var before := {}
		for id in stored:
			before[id] = float(stored[id])
		var built_before := queue.size()
		var pop_before := pop
		var t := t0
		var step := 30.0
		_offline = true
		while t < t0 + elapsed:
			var dt := minf(step, t0 + elapsed - t)
			t += dt
			_simulate(dt, t)
		_offline = false
		var gained := {"food": 0.0, "wood": 0.0, "coal": 0.0, "iron": 0.0}
		for id in stored:
			var tp: String = Defs.PLOTS[id]["type"]
			if Defs.BUILDINGS[tp].has("prod"):
				gained[Defs.BUILDINGS[tp]["prod"]] += float(stored[id]) - float(before.get(id, 0.0))
		offline_report = {"elapsed": elapsed, "gained": gained, "built": built_before - queue.size(),
				"pop": pop - pop_before}
	# الذئاب لا تهاجم وأنت غائب: تتأجل الغارة إلى ما بعد عودتك
	if raid_next > 0.0 and raid_next < now() + 180.0:
		raid_next = now() + 240.0
	return true


func reset_game() -> void:
	DirAccess.remove_absolute(ProjectSettings.globalize_path(_save_path()))
	new_game()
	recompute()
	changed.emit()


func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_CLOSE_REQUEST \
			or what == NOTIFICATION_APPLICATION_FOCUS_OUT:
		save_game()


# ================================================================ الحساب
func level(id: String) -> int:
	return int(plots.get(id, 0))


func furnace_level() -> int:
	return level("furnace")


func max_level_of(type: String) -> int:
	var m := 0
	for id in Defs.PLOTS:
		if Defs.PLOTS[id]["type"] == type:
			m = maxi(m, level(id))
	return m


func count_of(type: String) -> int:
	var c := 0
	for id in Defs.PLOTS:
		if Defs.PLOTS[id]["type"] == type and level(id) > 0:
			c += 1
	return c


func pop_capacity() -> int:
	var c := 4
	for id in Defs.PLOTS:
		if Defs.PLOTS[id]["type"] == "shelter":
			c += Defs.shelter_capacity(level(id))
	return c


func healthy() -> int:
	return maxi(pop - int(floor(sick)), 0)


func storage_hours() -> float:
	return 2.0 + 0.5 * max_level_of("storehouse") + bonus("storage")


func storage_cap(id: String) -> float:
	var tp: String = Defs.PLOTS[id]["type"]
	return Defs.prod_rate(tp, level(id)) * storage_hours()


func efficiency(id: String) -> float:
	var tp: String = Defs.PLOTS[id]["type"]
	var need := Defs.workers_needed(tp, level(id))
	if need <= 0:
		return 1.0
	return float(workers.get(id, 0)) / need


func current_rate(id: String) -> float:
	## الإنتاج الفعلي في الساعة
	var tp: String = Defs.PLOTS[id]["type"]
	var r := Defs.prod_rate(tp, level(id)) * efficiency(id)
	if Defs.BUILDINGS[tp].has("prod"):
		r *= (1.0 + bonus("prod_" + str(Defs.BUILDINGS[tp]["prod"]))) * trust_mult()
		r *= 1.0 + Defs.STRONGHOLD_PROD * holds_count("stronghold")
	if cold_level == 2:
		r *= 0.5
	if _under_construction(id):
		r = 0.0
	return r


func coal_use() -> float:
	if furnace_mode == 0:
		return 0.0
	return Defs.furnace_coal(furnace_level()) * (2.0 if furnace_mode == 2 else 1.0)


func food_use() -> float:
	return pop * 6.0 + troop_total() * 1.0


func net_rate(r: String) -> float:
	var n := 0.0
	for id in Defs.PLOTS:
		var tp: String = Defs.PLOTS[id]["type"]
		if Defs.BUILDINGS[tp].get("prod", "") == r:
			n += current_rate(id)
	if r == "coal":
		n -= coal_use()
	if r == "food":
		n -= food_use()
	return n


func storm_active(t: float = -1.0) -> bool:
	if t < 0:
		t = now()
	return t >= storm_start and t < storm_end


func storm_soon() -> float:
	## ثوانٍ حتى العاصفة إن كانت قريبة (أقل من 90 ثانية)، وإلا -1
	var s := storm_start - now()
	return s if s > 0 and s < 90 else -1.0


func _outside(t: float) -> float:
	var o := -16.0 + 3.0 * sin(t * TAU / 600.0)
	if storm_active(t):
		o -= 22.0
	if front_active(t):
		o -= Defs.FRONT_DROP
	return o


func recompute(t: float = -1.0) -> void:
	if t < 0:
		t = now()
	outside_temp = _outside(t)
	var heat := 0.0
	if furnace_mode > 0 and res["coal"] > 0.0:
		heat = Defs.furnace_heat(furnace_level()) + (10.0 if furnace_mode == 2 else 0.0) + bonus("heat")
	if vent.get("captured", false):
		heat += Defs.VENT_HEAT
	inside_temp = outside_temp + heat
	cold_level = 0 if inside_temp >= -5.0 else (1 if inside_temp >= -15.0 else 2)
	hungry = res["food"] <= 0.0
	# توزيع العمال: الأولوية للطعام ثم الفحم ثم الخشب ثم الحديد ثم المستوصف
	workers = {}
	var avail := healthy()
	for tp in ["hunter", "coal_mine", "sawmill", "iron_mine", "infirmary"]:
		for id in Defs.PLOTS:
			if Defs.PLOTS[id]["type"] != tp or level(id) <= 0:
				continue
			var need := Defs.workers_needed(tp, level(id))
			var w := mini(need, avail)
			workers[id] = w
			avail -= w


func _under_construction(id: String) -> bool:
	for q in queue:
		if q["plot"] == id:
			return true
	return false


func _simulate(dt: float, t: float) -> void:
	recompute(t)
	var h := dt / 3600.0
	# إنتاج المباني (يُخزّن داخلها حتى تجمعه)
	for id in Defs.PLOTS:
		var tp: String = Defs.PLOTS[id]["type"]
		if not Defs.BUILDINGS[tp].has("prod") or level(id) <= 0:
			continue
		var s := float(stored.get(id, 0.0)) + current_rate(id) * h
		stored[id] = minf(s, storage_cap(id))
	# الاستهلاك
	res["food"] = maxf(res["food"] - food_use() * h, 0.0)
	res["coal"] = maxf(res["coal"] - coal_use() * h, 0.0)
	# المرض والشفاء
	var mins := dt / 60.0
	var rate: float = ([0.0, 0.02, 0.06][cold_level] + (0.03 if hungry else 0.0)) * (1.0 - bonus("sick_res"))
	sick = minf(sick + healthy() * rate * mins, float(pop))
	if cold_level < 2:
		var heal := 0.25
		for id in Defs.PLOTS:
			if Defs.PLOTS[id]["type"] == "infirmary" and level(id) > 0:
				heal += 0.6 * level(id) * efficiency(id)
		sick = maxf(sick - heal * (1.0 + bonus("heal")) * mins, 0.0)
	_simulate_stage2(dt, t)
	# وصول ناجين جدد
	if pop < pop_capacity() and cold_level < 2 and not hungry:
		_grow_acc += dt
		while _grow_acc >= 15.0 and pop < pop_capacity():
			_grow_acc -= 15.0
			pop += 1
	else:
		_grow_acc = 0.0
	# طابور البناء
	for i in range(queue.size() - 1, -1, -1):
		var q: Dictionary = queue[i]
		if float(q["end"]) <= t:
			_finish(i)
	# العاصفة
	if t >= storm_end:
		_schedule_storm(t + 480.0)
	# ضباب الحرب: الفرق تكشف ممرها أثناء الحركة، والاستطلاع يكشف عند الوصول
	for m in marches:
		_reveal_march_path(m, t - dt, t, Defs.FOG_REVEAL_MARCH)
		if str(m.get("kind", "")) == "scout" and not bool(m.get("revealed", false)) and t >= float(m["arrive"]):
			reveal_at(float(m["tx"]), float(m["ty"]), Defs.FOG_REVEAL_SCOUT)
			m["revealed"] = true
	if not venture.is_empty():
		_reveal_march_path(venture, t - dt, t, Defs.FOG_REVEAL_MARCH)
		if t >= float(venture["arrive"]):
			reveal_at(float(venture["tx"]), float(venture["ty"]), Defs.FOG_REVEAL_MARCH + 6.0)
	# المسيرات
	for i in range(marches.size() - 1, -1, -1):
		var m: Dictionary = marches[i]
		if float(m["back"]) <= t:
			_march_reward(m)
			marches.remove_at(i)
	# المرحلة 3: المسيرة العسكرية — المعركة بتوقيت الوصول المجدول والعودة بعدها
	if not venture.is_empty():
		if not bool(venture.get("resolved", false)) and t >= float(venture["arrive"]):
			_resolve_venture_battle(float(venture["arrive"]))
		if float(venture["back"]) <= t:
			_return_venture()


func _finish(i: int) -> void:
	var q: Dictionary = queue[i]
	var id: String = q["plot"]
	plots[id] = int(q["level"])
	queue.remove_at(i)
	stats["built"] = int(stats.get("built", 0)) + 1
	building_done.emit(id)
	var tp: String = Defs.PLOTS[id]["type"]
	toast.emit("اكتمل: %s — المستوى %d" % [Defs.BUILDINGS[tp]["name"], plots[id]])


func _process(delta: float) -> void:
	_tick_acc += delta
	_save_acc += delta
	if _tick_acc >= 0.5:
		var was_storm := storm_active(now() - _tick_acc)
		_simulate(_tick_acc, now())
		_tick_acc = 0.0
		if storm_active() != was_storm:
			storm_changed.emit(storm_active())
			toast.emit("عاصفة ثلجية تضرب المدينة — شغّل الفرن بالوضع المضاعف" if storm_active() else "انتهت العاصفة الثلجية")
		changed.emit()
	if _save_acc >= 15.0:
		_save_acc = 0.0
		save_game()


# ================================================================ الأفعال
const DevTools := preload("res://scripts/game/dev_tools.gd")

func try_dev_mode(pw: String) -> bool:
	return DevTools.try_dev_mode(self, pw)


func dev_give_resources() -> void:
	DevTools.dev_give_resources(self)


func dev_give_premium() -> void:
	DevTools.dev_give_premium(self)


func dev_add_pop(n: int) -> void:
	DevTools.dev_add_pop(self, n)


func dev_finish_all() -> void:
	DevTools.dev_finish_all(self)


func dev_heal_all() -> void:
	DevTools.dev_heal_all(self)


func dev_reveal_map() -> void:
	DevTools.dev_reveal_map(self)


func collect(id: String) -> float:
	var v := floorf(float(stored.get(id, 0.0)))
	if v < 1.0:
		return 0.0
	var tp: String = Defs.PLOTS[id]["type"]
	var r: String = Defs.BUILDINGS[tp]["prod"]
	res[r] += v
	stored[id] = float(stored[id]) - v
	stats["collected"][r] = float(stats["collected"].get(r, 0)) + v
	changed.emit()
	return v


func collect_all() -> Dictionary:
	var out := {}
	for id in stored:
		var tp: String = Defs.PLOTS[id]["type"]
		var r: String = Defs.BUILDINGS[tp]["prod"]
		var v := collect(id)
		if v > 0:
			out[r] = float(out.get(r, 0.0)) + v
	return out


func queue_entry(id: String) -> Dictionary:
	for q in queue:
		if q["plot"] == id:
			return q
	return {}


func check_upgrade(id: String) -> Dictionary:
	## {ok, reasons[], cost, time, next}
	var tp: String = Defs.PLOTS[id]["type"]
	var nxt := level(id) + 1
	var reasons: Array[String] = []
	var c := Defs.cost(tp, nxt)
	if nxt > int(Defs.BUILDINGS[tp]["max"]):
		reasons.append("وصل المبنى لأعلى مستوى")
	if not dev_mode:   # المطور: تُتجاوز اشتراطات الفتح والتسلسل، تبقى السقوف والتعارضات
		if furnace_level() < int(Defs.PLOTS[id]["unlock"]):
			reasons.append("يتطلب الفرن المستوى %d" % Defs.PLOTS[id]["unlock"])
		if tp != "furnace" and nxt > furnace_level():
			reasons.append("لا يتجاوز مستوى الفرن (%d)" % furnace_level())
		if tp == "furnace":
			if nxt >= 3 and max_level_of("shelter") < nxt - 1:
				reasons.append("يتطلب مأوى بالمستوى %d" % (nxt - 1))
			if nxt >= 4 and max_level_of("coal_mine") < nxt - 2:
				reasons.append("يتطلب منجم فحم بالمستوى %d" % (nxt - 2))
			if nxt >= 6 and max_level_of("storehouse") < nxt - 2:
				reasons.append("يتطلب مخزنًا بالمستوى %d" % (nxt - 2))
	if not queue_entry(id).is_empty():
		reasons.append("قيد البناء")
	var missing := {}
	for r in c:
		if res[r] < c[r]:
			missing[r] = c[r] - res[r]
	if dev_mode:
		missing = {}   # المطور: لا تُطلب الموارد
	var builders_free := queue.size() < BUILDERS or dev_mode
	return {"ok": reasons.is_empty() and missing.is_empty() and builders_free, "reasons": reasons,
			"missing": missing, "cost": c, "time": Defs.build_time(tp, nxt) / (1.0 + bonus("build_speed")), "next": nxt,
			"builders_free": builders_free}


func start_upgrade(id: String, instant: bool = false) -> bool:
	var chk := check_upgrade(id)
	if not chk["reasons"].is_empty() or not chk["missing"].is_empty():
		return false
	if not instant and not chk["builders_free"]:
		toast.emit("كل البنائين مشغولون")
		return false
	if instant:
		var g := gems_for_time(chk["time"])
		if not dev_mode:
			if gems < g:
				toast.emit("الجواهر غير كافية")
				return false
			gems -= g
	if not dev_mode:
		for r in chk["cost"]:
			res[r] -= chk["cost"][r]
	var t := now()
	queue.append({"plot": id, "level": chk["next"], "start": t, "end": t + (0.0 if instant else chk["time"])})
	if instant:
		_finish(queue.size() - 1)
	recompute()
	changed.emit()
	save_game()
	return true


func gems_for_time(sec: float) -> int:
	if sec <= FREE_SPEEDUP:
		return 0
	return int(ceil(sec / 60.0))


func speedup(id: String) -> bool:
	var q := queue_entry(id)
	if q.is_empty():
		return false
	var remain := float(q["end"]) - now()
	var g := gems_for_time(remain)
	if not dev_mode:
		if gems < g:
			toast.emit("الجواهر غير كافية")
			return false
		gems -= g
	q["end"] = now()
	_simulate(0.0, now())
	changed.emit()
	save_game()
	return true


func cancel(id: String) -> void:
	for i in queue.size():
		if queue[i]["plot"] == id:
			var tp: String = Defs.PLOTS[id]["type"]
			var c := Defs.cost(tp, int(queue[i]["level"]))
			for r in c:
				res[r] += c[r]
			queue.remove_at(i)
			toast.emit("تم إلغاء البناء واسترجاع الموارد")
			changed.emit()
			return


func set_furnace_mode(m: int) -> void:
	furnace_mode = m
	recompute()
	changed.emit()


# ================================================================ المهام والمكافآت
func current_task() -> Dictionary:
	if task_index >= Defs.TASKS.size():
		return {}
	return Defs.TASKS[task_index]


func task_progress(tk: Dictionary) -> Vector2:
	match tk["type"]:
		"count":
			return Vector2(count_of(tk["b"]), tk["n"])
		"level":
			return Vector2(max_level_of(tk["b"]), tk["n"])
		"collect":
			return Vector2(float(stats["collected"].get(tk["r"], 0)), tk["n"])
		"pop":
			return Vector2(pop, tk["n"])
		"temp":
			return Vector2(1 if inside_temp >= float(tk["n"]) else 0, 1)
		"march":
			return Vector2(int(stats.get("marches", 0)), tk["n"])
		"train":
			return Vector2(int(stats.get("trained", 0)), tk["n"])
		"hero":
			return Vector2(heroes_owned(), tk["n"])
		"defender":
			return Vector2(1 if defender != "" else 0, 1)
		"governor":
			return Vector2(1 if governor != "" else 0, 1)
		"aurora":
			return Vector2(int(stats.get("aurora", 0)), tk["n"])
		"decision":
			return Vector2(int(stats.get("decisions", 0)), tk["n"])
		"raid_win":
			return Vector2(raid_wins, tk["n"])
		"research":
			return Vector2(int(stats.get("research", 0)), tk["n"])
		"hero_lv":
			var m := 0
			for id in heroes:
				if heroes[id]["owned"]:
					m = maxi(m, int(heroes[id]["lv"]))
			return Vector2(m, tk["n"])
		"power":
			return Vector2(int(power()), tk["n"])
	return Vector2(0, 1)


func task_done(tk: Dictionary) -> bool:
	var p := task_progress(tk)
	return p.x >= p.y


func claim_task() -> bool:
	var tk := current_task()
	if tk.is_empty() or not task_done(tk):
		return false
	give(tk["reward"])
	task_index += 1
	toast.emit("تم استلام مكافأة المهمة")
	save_game()
	return true


func chapter2_open() -> bool:
	return furnace_level() >= 3


func current_task2() -> Dictionary:
	if not chapter2_open() or task2_index >= Defs.TASKS2.size():
		return {}
	return Defs.TASKS2[task2_index]


func claim_task2() -> bool:
	var tk := current_task2()
	if tk.is_empty() or not task_done(tk):
		return false
	give(tk["reward"])
	task2_index += 1
	toast.emit("تم استلام مكافأة مهمة الفصل الثاني")
	save_game()
	return true


func tracked_task() -> Dictionary:
	## المهمة الظاهرة في الشريط: الجاهزة للاستلام أولًا
	var t1 := current_task()
	var t2 := current_task2()
	if not t1.is_empty() and task_done(t1):
		return {"ch": 1, "tk": t1}
	if not t2.is_empty() and task_done(t2):
		return {"ch": 2, "tk": t2}
	if not t2.is_empty() and (t1.is_empty() or max_level_of("barracks") > 0 or furnace_level() >= 5):
		return {"ch": 2, "tk": t2}
	if not t1.is_empty():
		return {"ch": 1, "tk": t1}
	return {}


func give(reward: Dictionary) -> void:
	for k in reward:
		if k == "gems":
			gems += int(reward[k])
		elif k == "aurora":
			aurora += int(reward[k])
		elif String(k).begins_with("shards_"):
			var hid := String(k).substr(7)
			heroes[hid]["shards"] = int(heroes[hid]["shards"]) + int(reward[k])
		else:
			res[k] = float(res.get(k, 0.0)) + float(reward[k])
	changed.emit()


func _today() -> String:
	var d := Time.get_date_dict_from_system()
	return "%04d-%02d-%02d" % [d["year"], d["month"], d["day"]]


func _check_daily() -> void:
	daily_ready = last_daily != _today()


func daily_reward() -> Dictionary:
	var f := maxi(furnace_level(), 1)
	return {"food": 1500 * f, "wood": 1200 * f, "coal": 500 * f, "aurora": 10, "gems": 50}


func claim_daily() -> void:
	if not daily_ready:
		return
	give(daily_reward())
	last_daily = _today()
	daily_ready = false
	save_game()


# ================================================================ المسيرات (الخريطة الكبرى)
func march_speed() -> float:
	return 7.0 * (1.0 + bonus("march_speed"))   # خانة في الثانية


func start_march(target: Dictionary) -> bool:
	if marches.size() >= MAX_MARCHES:
		toast.emit("كل الفرق في مهمة — انتظر عودة إحداها")
		return false
	var from := Vector2(home.x + 0.5, home.y + 0.5)
	var to := Vector2(float(target["x"]) + 0.5, float(target["y"]) + 0.5)
	var travel := clampf(from.distance_to(to) / march_speed(), 4.0, 180.0)
	var work := 0.0
	match target["kind"]:
		"res":
			work = 12.0 + 2.0 * float(target["l"])
		"beast":
			work = 3.0
		"lm", "city":
			work = 5.0
		"scout":
			work = 0.0   # فرقة استطلاع: تكشف عند الوصول ثم تعود مباشرة
	var t := now()
	var m := {"kind": target["kind"], "t": target.get("t", ""), "l": int(target.get("l", 1)),
			"name": str(target.get("n", "")), "fx": from.x, "fy": from.y, "tx": to.x, "ty": to.y,
			"start": t, "arrive": t + travel, "leave": t + travel + work, "back": t + travel * 2 + work}
	marches.append(m)
	stats["marches"] = int(stats.get("marches", 0)) + 1
	changed.emit()
	save_game()
	return true


func _march_reward(m: Dictionary) -> void:
	var reward := {}
	var lv := int(m["l"])
	match m["kind"]:
		"res":
			var amount := {"food": 4500, "wood": 3200, "coal": 1800, "iron": 600}
			reward[m["t"]] = amount[m["t"]] * lv
		"beast":
			reward = {"food": 2000 * lv, "wood": 800 * lv, "gems": 2 + lv / 3}
		"scout":
			toast.emit("اكتمل استطلاع المنطقة — كُشف ما حول الهدف")
			march_done.emit(m)
			return
		_:
			reward = {"wood": 500}
	give(reward)
	var parts: Array[String] = []
	for k in reward:
		parts.append("%s %s" % [Defs.fmt(reward[k]), Defs.RES_NAMES[k]])
	toast.emit("عادت الفرقة: " + "، ".join(parts))
	march_done.emit(m)


# ---------------------------------------------------------------- جبهة الصقيع (المرحلة 3 — نموذج أولي)
func front_active(t: float = -1.0) -> bool:
	if front_origin <= 0.0:
		return false
	if t < 0.0:
		t = now()
	if t < front_origin:
		return false
	return fmod(t - front_origin, Defs.FRONT_PERIOD) < Defs.FRONT_LEN

func front_eta() -> float:
	## ثوانٍ حتى بداية الجبهة القادمة
	if front_origin <= 0.0:
		return -1.0
	var t := now()
	if t < front_origin:
		return front_origin - t
	var phase := fmod(t - front_origin, Defs.FRONT_PERIOD)
	return Defs.FRONT_PERIOD - phase

# ---------------------------------------------------------------- ضباب الحرب (كشف دائم للمناطق)
const MapFog := preload("res://scripts/game/map_fog.gd")

func is_explored(x: int, y: int) -> bool:
	return MapFog.is_explored(self, x, y)


func reveal_at(x: float, y: float, radius: float) -> void:
	MapFog.reveal_at(self, x, y, radius)


func reveal_segment(x0: float, y0: float, x1: float, y1: float, radius: float) -> void:
	MapFog.reveal_segment(self, x0, y0, x1, y1, radius)


func _march_fog_pos(m: Dictionary, t: float) -> Vector2:
	return MapFog.march_fog_pos(self, m, t)


func _reveal_march_path(m: Dictionary, t_from: float, t_to: float, radius: float) -> void:
	MapFog.reveal_march_path(self, m, t_from, t_to, radius)


func holds_count(type: String) -> int:
	var n := 0
	for id in holds:
		if str(holds[id]) == type:
			n += 1
	return n

func _map_data() -> Dictionary:
	if _map_data_cache.is_empty():
		_map_data_cache = JSON.parse_string(FileAccess.get_file_as_string("res://data/map_data.json"))
	return _map_data_cache

func _find_landmark(id: String) -> Dictionary:
	## يُستخرج الهدف من بيانات الخريطة نفسها لا من واجهة الإرسال
	for L in _map_data().get("landmarks", []):
		if str(L["id"]) == id:
			return L
	return {}

func start_venture(units: Dictionary, formation := "balanced", target := {}) -> bool:
	## إرسال فرقة عسكرية لاحتلال المنفث أو معلم قابل للاحتلال — الجنود تُحجز فورًا والمعركة عند الوصول
	## الهدف يُستخرج من بيانات الخريطة، وغيابه يعني المنفث (توافق مع النداءات والحفظ القديم)
	var tgt: Dictionary = target.duplicate() if not target.is_empty() else {"kind": "vent"}
	var lm := {}
	if str(tgt.get("kind", "vent")) == "hold":
		lm = _find_landmark(str(tgt.get("id", "")))
		if lm.is_empty():
			toast.emit("هدف غير معروف")
			return false
		if holds.has(str(tgt["id"])):
			toast.emit("هذا الموقع تحت سيطرتك أصلًا")
			return false
	elif vent.get("captured", false):
		toast.emit("المنفث تحت سيطرتك أصلًا")
		return false
	if not venture.is_empty():
		toast.emit("الفرقة العسكرية في مهمة بالفعل")
		return false
	var take := {}
	for k in units:
		var n := int(units[k])
		if n > 0:
			take[k] = n
	if take.is_empty():
		toast.emit("اختر جنودًا لإرسالهم أولًا")
		return false
	for k in take:
		if int(troops.get(k, 0)) < int(take[k]):
			toast.emit("عدد الجنود المتاح أقل من المطلوب")
			return false
	var from := Vector2(home.x + 0.5, home.y + 0.5)
	var to := Vector2(float(vent["x"]) + 0.5, float(vent["y"]) + 0.5)
	var fight_work := float(Defs.VENT_FIGHT_WORK)
	if not lm.is_empty():
		to = Vector2(float(lm["x"]), float(lm["y"]))
		tgt["type"] = str(lm["type"])
	var travel := clampf(from.distance_to(to) / march_speed(), 8.0, 300.0)
	var t := now()
	var fdef: Dictionary = Defs.FORMATIONS.get(formation, Defs.FORMATIONS["balanced"])
	# ظروف المعركة تُثبّت عند الإرسال (التعديلات، القائد، قوة الحرّاس، التشكيل) — لا تتغير أثناء السفر
	venture = {"units": take, "fx": from.x, "fy": from.y, "tx": to.x, "ty": to.y,
		"start": t, "arrive": t + travel, "leave": t + travel + fight_work,
		"back": t + travel * 2.0 + fight_work,
		"resolved": false, "survivors": {}, "losses": {},
		"dead_factor": float(fdef["dead"]) * (0.5 if defender == "layla" else 1.0),
		"mods": army_mods(defender), "guards_f": maxi(furnace_level(), 1),
		"target": tgt, "formation": String(formation),
		"won": false, "report": {}}
	for k in take:
		troops[k] = int(troops[k]) - int(take[k])
	changed.emit()
	save_game()
	return true

func _resolve_venture_battle(t: float) -> void:
	## المعركة تُحسم بتوقيت الوصول المجدول (لا بتوقيت المعالجة)، وبظروف مثبتة عند الإرسال
	var army: Dictionary = venture["units"]
	## التشكيل يُطبّق مرة واحدة هنا — نسخة عميقة لا تمس تعديلات الجيش المخزنة
	var mods: Dictionary = Combat.with_formation(venture["mods"], str(venture.get("formation", "balanced")))
	var f := int(venture["guards_f"])
	var tgt: Dictionary = venture.get("target", {"kind": "vent"})
	var guards := {}
	var guards_n := 0
	var target_name := "المنفث الحراري"
	if str(tgt.get("kind", "vent")) == "hold":
		var lm := _find_landmark(str(tgt.get("id", "")))
		var hd: Dictionary = Defs.HOLD_DEFS[str(tgt.get("type", "stronghold"))]
		var s := 1.0 + float(hd["g_scale"]) * f
		guards_n = int(hd["guards"]) + 2 * f
		guards = {"atk": float(hd["g_atk"]) * s, "def": float(hd["g_def"]) * s, "hp": float(hd["g_hp"]) * s,
			"name": "حرّاس %s" % hd["name"]}
		target_name = str(lm.get("name", hd["name"]))
	else:
		var s2 := 1.0 + 0.12 * f
		guards_n = int(Defs.VENT["guards"]) + 3 * f
		guards = {"atk": 10.0 * s2, "def": 7.0 * s2, "hp": 30.0 * s2, "name": "حرّاس المنفث"}
	var rep := Combat.fight(army, mods, {"beast": guards_n}, {"beast": guards}, storm_active(t))
	var survivors := {}
	for k in rep["att_left"]:
		survivors[k] = int(rep["att_left"][k])
	venture["survivors"] = survivors
	venture["resolved"] = true
	venture["won"] = bool(rep["att_win"])
	# الخسائر الخام تُخزن — والجرحى والقتلى يُحسمون عند العودة وفق سعة المستوصف حينها
	var losses := {}
	for k in rep["att_loss"]:
		if int(rep["att_loss"][k]) > 0:
			losses[k] = int(rep["att_loss"][k])
	venture["losses"] = losses
	venture["report"] = {"win": bool(rep["att_win"]), "rounds": int(rep["rounds"]), "log": rep["log"], "dead": 0,
		"target": target_name}
	if rep["att_win"]:
		if str(tgt.get("kind", "vent")) == "hold":
			var hid := str(tgt["id"])
			holds[hid] = str(tgt.get("type", "stronghold"))
			var hd2: Dictionary = Defs.HOLD_DEFS[str(holds[hid])]
			var rew := {"aurora": int(hd2["reward_aurora"]) + f, "gems": int(hd2["reward_gems"])}
			give(rew)
			venture["report"]["reward"] = rew
			venture["report"]["hold"] = hid
			toast.emit("احتُلّ %s — %s" % [target_name, hd2["eff"]])
		else:
			vent["captured"] = true
			var rew2 := {"aurora": 8 + 2 * f, "gems": 5}
			give(rew2)
			venture["report"]["reward"] = rew2
			toast.emit("احتُلّ المنفث الحراري — المدينة اكتسبت +%d° دفئًا دائمًا" % int(Defs.VENT_HEAT))
	else:
		toast.emit("صُدّ الهجوم عن %s — الحرّاس أقوى من المتوقع" % target_name)
	recompute()
	changed.emit()
	save_game()

func _return_venture() -> void:
	## عودة الناجين مرة واحدة فقط — والجرحى تخضع لسعة المستوصف وقت العودة فعليًا
	var room_left := maxi(wounded_cap() - wounded_total(), 0)
	var dead_total := 0
	for k in venture.get("losses", {}):
		var lost := int(venture["losses"][k])
		var dead := int(round(lost * float(venture.get("dead_factor", 0.25))))
		var w := mini(lost - dead, room_left)
		room_left -= w
		dead += (lost - dead) - w
		wounded[k] = int(wounded.get(k, 0)) + w
		dead_total += dead
	for k in venture.get("survivors", {}):
		troops[k] = int(troops.get(k, 0)) + int(venture["survivors"][k])
	var rep: Dictionary = venture.get("report", {})
	rep["dead"] = dead_total
	venture_done.emit(rep)
	venture = {}
	changed.emit()
	save_game()


# ================================================================ المرحلة الثانية: الحسابات العامة
func bonus(eff: String) -> float:
	var b := 0.0
	for id in techs:
		if int(techs[id]) > 0 and Defs.TECHS[id]["eff"] == eff:
			b += float(Defs.TECHS[id]["val"]) * int(techs[id])
	if governor != "" and heroes.has(governor) and heroes[governor]["owned"]:
		var ce: Dictionary = Defs.HEROES[governor]["city_eff"]
		if ce.has(eff):
			# مهارة الحاكم تقوى مع النجوم
			b += float(ce[eff]) * (1.0 + 0.15 * int(heroes[governor]["stars"]))
	return b


func trust_mult() -> float:
	return 0.9 + 0.2 * clampf(trust, 0.0, 100.0) / 100.0


func troop_total() -> int:
	var n := 0
	for k in troops:
		n += int(troops[k])
	return n


func wounded_total() -> int:
	var n := 0
	for k in wounded:
		n += int(wounded[k])
	return n


func wounded_cap() -> int:
	var c := 50
	for id in Defs.PLOTS:
		if Defs.PLOTS[id]["type"] == "infirmary":
			c += 40 * level(id)
	return c


func max_tier() -> int:
	var b := max_level_of("barracks")
	var t := 0
	for i in range(1, 5):
		if b >= Defs.TIER_BARRACKS[i]:
			t = i
	return t


func train_batch() -> int:
	return Defs.train_batch(max_level_of("barracks")) + int(bonus("train_cap"))


func heroes_owned() -> int:
	var n := 0
	for id in heroes:
		if heroes[id]["owned"]:
			n += 1
	return n


func hero_cap() -> int:
	return clampi(max_level_of("hero_hall") * 5, 0, 50)


func power() -> float:
	var p := 0.0
	for k in troops:
		var parts: PackedStringArray = String(k).split("_")
		p += int(troops[k]) * Defs.troop_power(parts[0], int(parts[1]))
	for id in Defs.PLOTS:
		p += level(id) * 12.0
	for id in heroes:
		if heroes[id]["owned"]:
			p += Defs.hero_power(int(heroes[id]["lv"]), int(heroes[id]["stars"]))
	for id in techs:
		p += int(techs[id]) * 20.0
	return p


func army_mods(hero_id: String) -> Dictionary:
	var m := {"atk": {"shield": 0.0, "spear": bonus("atk_spear"), "bow": bonus("atk_bow")},
			"def": {"shield": bonus("def_shield"), "spear": 0.0, "bow": 0.0},
			"hp": {}, "hp_all": bonus("hp_all"), "all": 0.0, "skill": "", "taken": 1.0}
	if hero_id != "" and heroes.has(hero_id) and heroes[hero_id]["owned"]:
		var h: Dictionary = heroes[hero_id]
		var tp: String = Defs.HEROES[hero_id]["troop"]
		var b := Defs.hero_bonus(int(h["lv"]), int(h["stars"]))
		m["atk"][tp] = float(m["atk"][tp]) + b
		m["def"][tp] = float(m["def"][tp]) + b
		m["hp"][tp] = b
		m["skill"] = hero_id
		if hero_id == "salma":
			m["all"] = 0.06
		if hero_id == "reem":
			m["taken"] = 0.85
	return m


const EconomyStats := preload("res://scripts/game/economy_stats.gd")

func get_stats_snapshot() -> Dictionary:
	return EconomyStats.get_stats_snapshot(self)


func _simulate_stage2(dt: float, t: float) -> void:
	var mins := dt / 60.0
	# الثقة تتأثر بالبرد والجوع، وتميل للاستقرار عند الدفء
	if cold_level == 2:
		trust -= 0.6 * mins
	if hungry:
		trust -= 1.0 * mins
	if cold_level == 0 and not hungry and trust < 70.0:
		trust = minf(trust + 0.15 * mins, 70.0)
	trust = clampf(trust, 0.0, 100.0)
	if trust < 15.0 and pop > 4:
		_leave_acc += dt
		if _leave_acc >= 60.0:
			_leave_acc = 0.0
			pop -= 1
			if not _offline:
				toast.emit("غادر أحد الناجين المدينة لفقدان الثقة")
	else:
		_leave_acc = 0.0
	# التدريب
	if not train.is_empty() and float(train["end"]) <= t:
		var k: String = train["key"]
		troops[k] = int(troops.get(k, 0)) + int(train["n"])
		stats["trained"] = int(stats.get("trained", 0)) + int(train["n"])
		var parts: PackedStringArray = k.split("_")
		toast.emit("اكتمل تدريب %d %s" % [int(train["n"]), Defs.TROOPS[parts[0]]["plural"]])
		train = {}
	# البحث
	if not research.is_empty() and float(research["end"]) <= t:
		var rid: String = research["id"]
		techs[rid] = int(research["lv"])
		stats["research"] = int(stats.get("research", 0)) + 1
		toast.emit("اكتمل البحث: %s — المستوى %d" % [Defs.TECHS[rid]["name"], techs[rid]])
		research = {}
	# علاج الجرحى في المستوصف
	var wt := wounded_total()
	if wt > 0:
		var inf := 0
		for id in Defs.PLOTS:
			if Defs.PLOTS[id]["type"] == "infirmary":
				inf += level(id)
		var heal := (2.0 + 3.0 * inf) * (1.0 + bonus("heal")) * mins
		var budget := int(floor(heal + randf()))
		for k in wounded:
			if budget <= 0:
				break
			var h := mini(int(wounded[k]), budget)
			wounded[k] = int(wounded[k]) - h
			troops[k] = int(troops[k]) + h
			budget -= h
	if _offline:
		return
	# بلورات الشفق: العاصفة فرصة وليست كارثة فقط
	if storm_active(t):
		_crystal_acc += dt
		while _crystal_acc >= 9.0:
			_crystal_acc -= 9.0
			if crystals.size() < 10:
				_spawn_crystal()
	else:
		_crystal_acc = 0.0
	# غارات الذئاب
	if max_level_of("barracks") > 0 and raid_next <= 0.0:
		raid_next = t + 420.0
	if raid_next > 0.0 and t >= raid_next:
		_run_raid()
	# دفتر القائد
	if pending_decision < 0 and furnace_level() >= 2 and t >= decision_next:
		pending_decision = randi() % Defs.DECISIONS.size()
		decision_ready.emit()
		toast.emit("قرار جديد ينتظرك في دفتر القائد")


func _spawn_crystal() -> void:
	for attempt in 12:
		var a := randf() * TAU
		var r := randf_range(9.0, 44.0)
		var p := Defs.CITY_CENTER + Vector3(cos(a), 0, sin(a)) * r
		var ok := true
		for id in Defs.PLOTS:
			if Defs.plot_pos(id).distance_to(p) < 4.5:
				ok = false
				break
		if ok:
			crystals.append({"x": p.x, "z": p.z, "v": randi_range(3, 6)})
			crystals_changed.emit()
			return


func collect_crystal(i: int) -> int:
	if i < 0 or i >= crystals.size():
		return 0
	var v := int(round(float(crystals[i]["v"]) * (1.0 + bonus("aurora_gain"))))
	crystals.remove_at(i)
	aurora += v
	stats["aurora"] = int(stats.get("aurora", 0)) + v
	crystals_changed.emit()
	changed.emit()
	return v


# ---------------------------------------------------------------- التدريب
func train_check(tp: String, tier: int, n: int) -> Dictionary:
	var reasons: Array[String] = []
	if not dev_mode:   # المطور: تجاوز اشتراط المعسكر والرتبة
		if max_level_of("barracks") <= 0:
			reasons.append("ابنِ المعسكر أولًا")
		if tier > max_tier():
			reasons.append("الرتبة تتطلب المعسكر بالمستوى %d" % Defs.TIER_BARRACKS[tier])
	if not train.is_empty():
		reasons.append("المعسكر مشغول بدفعة أخرى")
	if n <= 0:
		reasons.append("اختر عددًا")
	var c := Defs.troop_cost(tp, tier, n)
	var missing := {}
	for r in c:
		if res[r] < c[r]:
			missing[r] = c[r] - res[r]
	if dev_mode:
		missing = {}
	var time := Defs.troop_time(tp, tier, n) / (1.0 + bonus("train_speed"))
	return {"ok": reasons.is_empty() and missing.is_empty(), "reasons": reasons, "missing": missing, "cost": c, "time": time}


func start_train(tp: String, tier: int, n: int) -> bool:
	var chk := train_check(tp, tier, n)
	if not chk["ok"]:
		return false
	if not dev_mode:
		for r in chk["cost"]:
			res[r] -= chk["cost"][r]
	var t := now()
	train = {"key": "%s_%d" % [tp, tier], "n": n, "start": t, "end": t + float(chk["time"])}
	changed.emit()
	save_game()
	return true


func speedup_train() -> bool:
	if train.is_empty():
		return false
	var g := gems_for_time(float(train["end"]) - now())
	if not dev_mode:
		if gems < g:
			toast.emit("الجواهر غير كافية")
			return false
		gems -= g
	train["end"] = now()
	_simulate(0.0, now())
	changed.emit()
	save_game()
	return true


func cancel_train() -> void:
	if train.is_empty():
		return
	var parts: PackedStringArray = String(train["key"]).split("_")
	var c := Defs.troop_cost(parts[0], int(parts[1]), int(train["n"]))
	for r in c:
		res[r] += c[r]
	train = {}
	toast.emit("تم إلغاء التدريب واسترجاع الموارد")
	changed.emit()


# ---------------------------------------------------------------- الأبحاث
func tech_check(id: String) -> Dictionary:
	var lv := int(techs[id]) + 1
	var tdef: Dictionary = Defs.TECHS[id]
	var reasons: Array[String] = []
	if lv > int(tdef["max"]):
		reasons.append("وصل البحث لأعلى مستوى")
	if not dev_mode:   # المطور: تجاوز اشتراطات المختبر وسلسلة البحث
		if max_level_of("lab") <= 0:
			reasons.append("ابنِ مختبر الجمر أولًا")
		elif max_level_of("lab") < Defs.tech_lab_req(id, lv):
			reasons.append("يتطلب المختبر بالمستوى %d" % Defs.tech_lab_req(id, lv))
		if tdef["req"] != "" and int(techs[tdef["req"]]) < 1:
			reasons.append("يتطلب بحث: %s" % Defs.TECHS[tdef["req"]]["name"])
	if not research.is_empty():
		reasons.append("المختبر مشغول ببحث آخر")
	var c := Defs.tech_cost(id, lv)
	var missing := {}
	for r in c:
		var have: float = float(aurora) if r == "aurora" else float(res[r])
		if have < c[r]:
			missing[r] = c[r] - have
	if dev_mode:
		missing = {}
	var time := Defs.tech_time(id, lv) / (1.0 + bonus("research_speed"))
	return {"ok": reasons.is_empty() and missing.is_empty(), "reasons": reasons, "missing": missing, "cost": c, "time": time, "next": lv}


func start_research(id: String) -> bool:
	var chk := tech_check(id)
	if not chk["ok"]:
		return false
	if not dev_mode:
		for r in chk["cost"]:
			if r == "aurora":
				aurora -= int(chk["cost"][r])
			else:
				res[r] -= chk["cost"][r]
	var t := now()
	research = {"id": id, "lv": chk["next"], "start": t, "end": t + float(chk["time"])}
	changed.emit()
	save_game()
	return true


func speedup_research() -> bool:
	if research.is_empty():
		return false
	var g := gems_for_time(float(research["end"]) - now())
	if not dev_mode:
		if gems < g:
			toast.emit("الجواهر غير كافية")
			return false
		gems -= g
	research["end"] = now()
	_simulate(0.0, now())
	changed.emit()
	save_game()
	return true


# ---------------------------------------------------------------- الأبطال
const HeroMgr := preload("res://scripts/game/heroes.gd")

func hero_unlock(id: String) -> bool:
	return HeroMgr.hero_unlock(self, id)


func hero_summon(id: String) -> bool:
	return HeroMgr.hero_summon(self, id)


func hero_level_check(id: String) -> Dictionary:
	return HeroMgr.hero_level_check(self, id)


func hero_level_up(id: String) -> bool:
	return HeroMgr.hero_level_up(self, id)


func hero_star_up(id: String) -> bool:
	return HeroMgr.hero_star_up(self, id)


func set_role(id: String, role: String) -> void:
	HeroMgr.set_role(self, id, role)


# ---------------------------------------------------------------- غارات الذئاب
func raid_strength() -> Dictionary:
	var f := furnace_level()
	var red := minf(Defs.FORT_RAID_CAP, Defs.FORT_RAID_RED * holds_count("fortress"))
	var s := (1.0 + 0.07 * (f - 1) + 0.04 * raid_count) * (1.0 - red)
	return {"n": int(round((10 + 5 * mini(raid_count, 20) + 3 * f) * (1.0 - red))),
			"beast": {"atk": 9.0 * s, "def": 6.0 * s, "hp": 26.0 * s, "name": "الذئاب"}}


func raid_soon() -> float:
	if raid_next <= 0.0:
		return -1.0
	var r := raid_next - now()
	return r if r > 0 and r < 90.0 else -1.0


func _run_raid() -> void:
	var st := raid_strength()
	var army := {}
	for k in troops:
		if int(troops[k]) > 0:
			army[k] = int(troops[k])
	var rep := {}
	var storm := storm_active()
	if army.is_empty():
		rep = {"att_win": true, "rounds": 0, "att_left": {"beast": st["n"]}, "att_loss": {"beast": 0},
				"def_left": {}, "def_loss": {}, "log": ["لم يكن في المدينة جنود للدفاع، فاقتحمت الذئاب المخازن."]}
	else:
		rep = Combat.fight({"beast": st["n"]}, {"beast": st["beast"]}, army, army_mods(defender), storm)
	var win: bool = not rep["att_win"]
	# الخسائر: معظمها جرحى، والباقي قتلى
	var dead_total := 0
	var wounded_total_new := 0
	for k in rep["def_loss"]:
		var lost := int(rep["def_loss"][k])
		if lost <= 0:
			continue
		var dead := int(round(lost * 0.25))
		if defender == "layla":
			dead = int(round(dead * 0.5))
		var w := lost - dead
		var room := maxi(wounded_cap() - wounded_total(), 0)
		if w > room:
			dead += w - room
			w = room
		troops[k] = maxi(int(troops[k]) - lost, 0)
		wounded[k] = int(wounded[k]) + w
		dead_total += dead
		wounded_total_new += w
	var reward := {}
	var loss := {}
	var f := maxi(furnace_level(), 1)
	if win:
		reward = {"food": 400 * f, "iron": 40 * f, "aurora": 6 + raid_count, "gems": 5}
		give(reward)
		trust = minf(trust + 4.0, 100.0)
		raid_wins += 1
	else:
		for r in ["food", "wood"]:
			loss[r] = int(res[r] * 0.08)
			res[r] -= loss[r]
		trust = maxf(trust - 6.0, 0.0)
		sick = minf(sick + 2.0, float(pop))
	raid_count += 1
	raid_next = now() + randf_range(780.0, 1140.0)
	toast.emit("غارة ذئاب: صمدت المدينة" if win else "غارة ذئاب: اخترقت الذئاب الدفاع")
	last_raid = {"win": win, "wolves": st["n"], "killed": int(rep["att_loss"].get("beast", 0)), "dead": dead_total,
			"wounded": wounded_total_new, "reward": reward, "loss": loss, "log": rep["log"], "storm": storm,
			"hero": defender, "time": now()}
	raid_unseen = true
	raid_happened.emit(last_raid)
	changed.emit()
	save_game()


# ---------------------------------------------------------------- دفتر القائد
func decision_option_ok(opt: Dictionary) -> bool:
	for k in opt["eff"]:
		var v := float(opt["eff"][k])
		if v >= 0:
			continue
		if res.has(k) and res[k] < -v:
			return false
		if k == "aurora" and aurora < -v:
			return false
	return true


func choose_decision(which: String) -> void:
	if pending_decision < 0:
		return
	var dd: Dictionary = Defs.DECISIONS[pending_decision]
	var opt: Dictionary = dd[which]
	if not decision_option_ok(opt):
		toast.emit("لا تملك ما يكفي لهذا الخيار")
		return
	for k in opt["eff"]:
		var v := float(opt["eff"][k])
		match k:
			"trust":
				trust = clampf(trust + v, 0.0, 100.0)
			"pop":
				pop = maxi(pop + int(v), 1)
			"sick":
				sick = clampf(sick + v, 0.0, float(pop))
			"aurora":
				aurora = maxi(aurora + int(v), 0)
			"gems":
				gems += int(v)
			"troop_bonus":
				troops["shield_1"] = int(troops["shield_1"]) + int(v / 2)
				troops["spear_1"] = int(troops["spear_1"]) + int(v) - int(v / 2)
			_:
				res[k] = maxf(float(res[k]) + v, 0.0)
	stats["decisions"] = int(stats.get("decisions", 0)) + 1
	pending_decision = -1
	decision_next = now() + randf_range(360.0, 600.0)
	recompute()
	changed.emit()
	save_game()
