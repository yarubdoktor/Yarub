extends RefCounted
## تعريفات اللعبة: المباني، والمواقع، والتكاليف، والمهام.
## عدّل الأرقام هنا لموازنة اللعبة دون لمس بقية الكود.

const RES := ["food", "wood", "coal", "iron"]
const RES_NAMES := {"food": "طعام", "wood": "خشب", "coal": "فحم", "iron": "حديد", "gems": "جواهر", "aurora": "بلورات الشفق",
		"trust": "ثقة الناس", "pop": "ناجين", "sick": "مرضى", "wounded": "جرحى", "shards": "شظايا"}

const CITY_CENTER := Vector3(60, 0, 60)

## type: الإنتاج (prod) أو غيره. max: أعلى مستوى. cost: تكلفة المستوى الأول. from: المستوى الذي تبدأ فيه تكلفة هذا المورد
const BUILDINGS := {
	"furnace": {"name": "الفرن المركزي", "max": 30, "time": 20.0,
		"cost": {"wood": 260, "coal": 90, "iron": 60}, "from": {"wood": 2, "coal": 3, "iron": 6},
		"desc": "قلب المدينة. يدفئ السكان ويحدد أعلى مستوى لبقية المباني."},
	"shelter": {"name": "مأوى", "max": 30, "time": 8.0,
		"cost": {"wood": 50, "coal": 20, "iron": 20}, "from": {"wood": 1, "coal": 4, "iron": 8},
		"desc": "يؤوي الناجين. كل مستوى يزيد عدد السكان الممكن."},
	"hunter": {"name": "كوخ الصيادين", "max": 30, "time": 9.0, "prod": "food", "rate": 720.0,
		"cost": {"wood": 60, "coal": 25, "iron": 20}, "from": {"wood": 1, "coal": 3, "iron": 7},
		"desc": "ينتج الطعام. يحتاج عمالًا من السكان الأصحاء."},
	"sawmill": {"name": "المنشرة", "max": 30, "time": 9.0, "prod": "wood", "rate": 600.0,
		"cost": {"wood": 45, "coal": 25, "iron": 20}, "from": {"wood": 1, "coal": 3, "iron": 7},
		"desc": "تقطع الخشب اللازم للبناء."},
	"coal_mine": {"name": "منجم الفحم", "max": 30, "time": 10.0, "prod": "coal", "rate": 330.0,
		"cost": {"wood": 120, "coal": 30, "iron": 25}, "from": {"wood": 1, "coal": 4, "iron": 7},
		"desc": "يستخرج الفحم وقود الفرن. بدونه تتجمد المدينة."},
	"iron_mine": {"name": "منجم الحديد", "max": 30, "time": 14.0, "prod": "iron", "rate": 140.0,
		"cost": {"wood": 420, "coal": 160, "iron": 40}, "from": {"wood": 1, "coal": 1, "iron": 6},
		"desc": "يستخرج الحديد للمباني المتقدمة."},
	"storehouse": {"name": "المخزن", "max": 30, "time": 12.0,
		"cost": {"wood": 220, "coal": 60, "iron": 40}, "from": {"wood": 1, "coal": 2, "iron": 6},
		"desc": "يزيد سعة تخزين مباني الإنتاج، فتتحمل غيابك مدة أطول."},
	"infirmary": {"name": "المستوصف", "max": 30, "time": 12.0,
		"cost": {"wood": 300, "coal": 90, "iron": 40}, "from": {"wood": 1, "coal": 1, "iron": 6},
		"desc": "يعالج المرضى المصابين بالبرد والجنود الجرحى ويعيدهم."},
	"barracks": {"name": "المعسكر", "max": 30, "time": 14.0,
		"cost": {"wood": 380, "coal": 120, "iron": 50}, "from": {"wood": 1, "coal": 1, "iron": 4},
		"desc": "يدرّب الدروع والرمّاحين والرماة. المستوى يفتح رتبًا أقوى ويزيد عدد الدفعة."},
	"hero_hall": {"name": "قاعة الأبطال", "max": 30, "time": 16.0,
		"cost": {"wood": 520, "coal": 160, "iron": 80}, "from": {"wood": 1, "coal": 1, "iron": 1},
		"desc": "مقر الأبطال. كل مستوى يرفع الحد الأعلى لمستوى الأبطال بخمسة."},
	"lab": {"name": "مختبر الجمر", "max": 30, "time": 16.0,
		"cost": {"wood": 600, "coal": 200, "iron": 90}, "from": {"wood": 1, "coal": 1, "iron": 1},
		"desc": "يطوّر تقنيات الاقتصاد والبقاء والحرب. مستواه يفتح أبحاثًا أعمق."},
}

## مواقع البناء الثابتة: المعرّف ← النوع، والزاوية بالدرجات، ونصف القطر، ومستوى الفرن المطلوب
const PLOTS := {
	"furnace": {"type": "furnace", "a": 0.0, "r": 0.0, "unlock": 0},
	"sh1": {"type": "shelter", "a": 0.0, "r": 17.0, "unlock": 1},
	"sh2": {"type": "shelter", "a": 60.0, "r": 17.0, "unlock": 1},
	"sh3": {"type": "shelter", "a": 120.0, "r": 17.0, "unlock": 2},
	"sh4": {"type": "shelter", "a": 180.0, "r": 17.0, "unlock": 3},
	"sh5": {"type": "shelter", "a": 240.0, "r": 17.0, "unlock": 4},
	"sh6": {"type": "shelter", "a": 300.0, "r": 17.0, "unlock": 5},
	"sh7": {"type": "shelter", "a": 60.0, "r": 41.0, "unlock": 7},
	"sh8": {"type": "shelter", "a": 120.0, "r": 41.0, "unlock": 9},
	"sh9": {"type": "shelter", "a": 240.0, "r": 41.0, "unlock": 11},
	"sh10": {"type": "shelter", "a": 300.0, "r": 41.0, "unlock": 13},
	"hu1": {"type": "hunter", "a": 15.0, "r": 30.5, "unlock": 1},
	"sa1": {"type": "sawmill", "a": 45.0, "r": 30.5, "unlock": 1},
	"co1": {"type": "coal_mine", "a": 75.0, "r": 30.5, "unlock": 2},
	"hu2": {"type": "hunter", "a": 105.0, "r": 30.5, "unlock": 3},
	"sa2": {"type": "sawmill", "a": 135.0, "r": 30.5, "unlock": 3},
	"ir1": {"type": "iron_mine", "a": 165.0, "r": 30.5, "unlock": 4},
	"st1": {"type": "storehouse", "a": 195.0, "r": 30.5, "unlock": 2},
	"co2": {"type": "coal_mine", "a": 225.0, "r": 30.5, "unlock": 5},
	"in1": {"type": "infirmary", "a": 255.0, "r": 30.5, "unlock": 3},
	"hu3": {"type": "hunter", "a": 285.0, "r": 30.5, "unlock": 7},
	"sa3": {"type": "sawmill", "a": 315.0, "r": 30.5, "unlock": 8},
	"ir2": {"type": "iron_mine", "a": 345.0, "r": 30.5, "unlock": 10},
	"ba1": {"type": "barracks", "a": 0.0, "r": 41.0, "unlock": 3},
	"hh1": {"type": "hero_hall", "a": 270.0, "r": 41.0, "unlock": 4},
	"lb1": {"type": "lab", "a": 180.0, "r": 41.0, "unlock": 5},
}

## مهام الفصل بالترتيب. الأنواع: level (أعلى مستوى لنوع) • count (عدد المباني المبنية) • pop • temp • collect • march
const TASKS := [
	{"text": "ابنِ أول مأوى للناجين", "type": "count", "b": "shelter", "n": 1, "reward": {"wood": 300, "gems": 20}},
	{"text": "ابنِ كوخ الصيادين", "type": "count", "b": "hunter", "n": 1, "reward": {"food": 600, "wood": 200}},
	{"text": "ابنِ المنشرة", "type": "count", "b": "sawmill", "n": 1, "reward": {"wood": 400}},
	{"text": "اجمع 500 خشب من المباني", "type": "collect", "r": "wood", "n": 500, "reward": {"wood": 500, "gems": 20}},
	{"text": "طوّر الفرن إلى المستوى 2", "type": "level", "b": "furnace", "n": 2, "reward": {"coal": 400, "gems": 30}},
	{"text": "ابنِ منجم الفحم", "type": "count", "b": "coal_mine", "n": 1, "reward": {"coal": 500}},
	{"text": "ابنِ المخزن", "type": "count", "b": "storehouse", "n": 1, "reward": {"wood": 800, "food": 800}},
	{"text": "ابنِ مأويين", "type": "count", "b": "shelter", "n": 2, "reward": {"wood": 600, "gems": 20}},
	{"text": "طوّر الفرن إلى المستوى 3", "type": "level", "b": "furnace", "n": 3, "reward": {"coal": 800, "iron": 200, "gems": 40}},
	{"text": "ابنِ المستوصف", "type": "count", "b": "infirmary", "n": 1, "reward": {"food": 1500, "wood": 800}},
	{"text": "اجعل حرارة المدينة فوق 0°", "type": "temp", "n": 0, "reward": {"coal": 1000, "gems": 30}},
	{"text": "وصّل عدد السكان إلى 20", "type": "pop", "n": 20, "reward": {"food": 2500, "gems": 30}},
	{"text": "أرسل فرقة جمع من الخريطة", "type": "march", "n": 1, "reward": {"wood": 1500, "gems": 30}},
	{"text": "طوّر كوخ الصيادين إلى 4", "type": "level", "b": "hunter", "n": 4, "reward": {"food": 3000}},
	{"text": "طوّر الفرن إلى المستوى 4", "type": "level", "b": "furnace", "n": 4, "reward": {"iron": 500, "gems": 50}},
	{"text": "ابنِ منجم الحديد", "type": "count", "b": "iron_mine", "n": 1, "reward": {"iron": 600, "coal": 1200}},
	{"text": "اجمع 5000 طعام", "type": "collect", "r": "food", "n": 5000, "reward": {"wood": 3000, "gems": 40}},
	{"text": "طوّر الفرن إلى المستوى 5", "type": "level", "b": "furnace", "n": 5, "reward": {"iron": 1000, "gems": 60}},
	{"text": "ابنِ 5 مآوٍ", "type": "count", "b": "shelter", "n": 5, "reward": {"wood": 5000, "food": 5000}},
	{"text": "وصّل عدد السكان إلى 60", "type": "pop", "n": 60, "reward": {"coal": 5000, "gems": 80}},
	{"text": "طوّر الفرن إلى المستوى 7", "type": "level", "b": "furnace", "n": 7, "reward": {"iron": 3000, "gems": 100}},
	{"text": "اجمع 10000 فحم", "type": "collect", "r": "coal", "n": 10000, "reward": {"iron": 2500, "gems": 60}},
	{"text": "طوّر الفرن إلى المستوى 10", "type": "level", "b": "furnace", "n": 10, "reward": {"gems": 300}},
]

## مهام الفصل الثاني: الجيش والأبطال والأبحاث (تُعرض بعد الفصل الأول أو بالتوازي معه حين يُبنى المعسكر)
const TASKS2 := [
	{"text": "ابنِ المعسكر", "type": "count", "b": "barracks", "n": 1, "reward": {"food": 2000, "iron": 200, "gems": 30}},
	{"text": "درّب 30 جنديًا", "type": "train", "n": 30, "reward": {"food": 3000, "wood": 1500}},
	{"text": "ابنِ قاعة الأبطال", "type": "count", "b": "hero_hall", "n": 1, "reward": {"shards_siraj": 10, "gems": 40}},
	{"text": "انضم إليك بطلك الأول", "type": "hero", "n": 1, "reward": {"aurora": 40, "food": 2000}},
	{"text": "عيّن بطلًا قائدًا للدفاع", "type": "defender", "n": 1, "reward": {"iron": 400, "gems": 20}},
	{"text": "اجمع 30 بلورة شفق من العواصف", "type": "aurora", "n": 30, "reward": {"aurora": 30, "gems": 30}},
	{"text": "اتخذ قرارًا في دفتر القائد", "type": "decision", "n": 1, "reward": {"food": 2500, "wood": 2500}},
	{"text": "اصمد أمام غارة ذئاب", "type": "raid_win", "n": 1, "reward": {"iron": 800, "aurora": 20, "gems": 40}},
	{"text": "ابنِ مختبر الجمر", "type": "count", "b": "lab", "n": 1, "reward": {"coal": 3000, "gems": 40}},
	{"text": "أكمل بحثًا واحدًا", "type": "research", "n": 1, "reward": {"wood": 4000, "iron": 600}},
	{"text": "طوّر بطلًا إلى المستوى 5", "type": "hero_lv", "n": 5, "reward": {"aurora": 40, "gems": 40}},
	{"text": "عيّن حاكمًا للمدينة", "type": "governor", "n": 1, "reward": {"food": 5000, "gems": 30}},
	{"text": "درّب 150 جنديًا", "type": "train", "n": 150, "reward": {"iron": 2000, "gems": 60}},
	{"text": "وصّل قوة المدينة إلى 5000", "type": "power", "n": 5000, "reward": {"aurora": 60, "gems": 80}},
	{"text": "اصمد أمام 3 غارات", "type": "raid_win", "n": 3, "reward": {"iron": 3000, "gems": 80}},
	{"text": "أكمل 8 مستويات أبحاث", "type": "research", "n": 8, "reward": {"aurora": 80, "gems": 100}},
	{"text": "اجمع بطلين", "type": "hero", "n": 2, "reward": {"gems": 150}},
	{"text": "طوّر المعسكر إلى المستوى 6", "type": "level", "b": "barracks", "n": 6, "reward": {"iron": 5000, "gems": 120}},
]

# ================================================================ الجيش
## مثلث التفوق: الرمح يخترق الدرع • الدرع يصد السهام • السهم يصيب الرماح
const TROOPS := {
	"shield": {"name": "حامل الدرع", "plural": "الدروع", "atk": 8.0, "def": 14.0, "hp": 30.0, "row": 0, "beats": "bow",
		"cost": {"food": 40, "wood": 25, "iron": 3}, "time": 2.0,
		"desc": "الصف الأول. يتحمل الضربات ويصد السهام. أقوى دفاعًا وقت العاصفة."},
	"spear": {"name": "الرمّاح", "plural": "الرمّاحون", "atk": 13.0, "def": 9.0, "hp": 24.0, "row": 1, "beats": "shield",
		"cost": {"food": 45, "wood": 30, "iron": 4}, "time": 2.2,
		"desc": "الصف الثاني. رماحه تخترق الدروع، وتتفوق على الوحوش."},
	"bow": {"name": "الرامي", "plural": "الرماة", "atk": 16.0, "def": 5.0, "hp": 18.0, "row": 2, "beats": "spear",
		"cost": {"food": 50, "wood": 35, "iron": 2}, "time": 2.4,
		"desc": "الصف الخلفي. ضرره الأعلى ويصيب الرمّاحين، لكن العاصفة تضعف سهامه."},
}
const TROOP_ORDER := ["shield", "spear", "bow"]
const TIER_NAMES := ["", "مجنّد", "محارب", "نخبة", "حارس الجمر"]
const TIER_BARRACKS := [0, 1, 6, 12, 18]
const COUNTER_BONUS := 1.35

static func tier_mult(t: int) -> float:
	return pow(1.5, t - 1)

static func troop_cost(type: String, tier: int, n: int) -> Dictionary:
	var out := {}
	for r in TROOPS[type]["cost"]:
		out[r] = int(ceil(float(TROOPS[type]["cost"][r]) * pow(1.7, tier - 1) * n))
	return out

static func troop_time(type: String, tier: int, n: int) -> float:
	return float(TROOPS[type]["time"]) * pow(1.35, tier - 1) * n

static func troop_power(type: String, tier: int) -> float:
	var t: Dictionary = TROOPS[type]
	return (float(t["atk"]) + float(t["def"]) + float(t["hp"]) / 3.0) * tier_mult(tier) * 0.25

static func train_batch(barracks_lv: int) -> int:
	return 0 if barracks_lv <= 0 else 20 + 10 * barracks_lv

# ================================================================ الأبطال
## لكل بطل دوران: قائد في المعركة، أو حاكم للمدينة (لمسة خاصة بلعبتنا)
## الاستدعاء بلا حظ: تختار البطل الذي تريده وتدفع بلورات الشفق مقابل شظاياه
const HEROES := {
	"siraj": {"name": "سراج", "title": "رامي الجمر", "elem": "نار", "troop": "bow", "color": "ff9a4a",
		"skill": "سهام الجمر", "skill_desc": "الرماة لا يضعفون في العاصفة، ويزيد ضررهم 15% في أول 3 جولات.",
		"city": "حارس الموقد", "city_desc": "يرفع حرارة المدينة 3 درجات.", "city_eff": {"heat": 3.0},
		"story": "آخر من بقي من قافلة النار. يقسم أن الجمر لا ينطفئ ما دام يحمل قوسه."},
	"reem": {"name": "ريم", "title": "درع الصقيع", "elem": "جليد", "troop": "shield", "color": "8fd3ff",
		"skill": "جدار الجليد", "skill_desc": "يقل الضرر الذي يتلقاه جيشها 15%.",
		"city": "حامية المرضى", "city_desc": "يقل المرض بسبب البرد 30%.", "city_eff": {"sick_res": 0.3},
		"story": "حارسة البوابة الشمالية. وقفت وحدها أمام العاصفة الكبرى ثلاث ليالٍ."},
	"nimr": {"name": "نمر", "title": "رمح العاصفة", "elem": "ريح", "troop": "spear", "color": "9fe39a",
		"skill": "الاندفاع", "skill_desc": "ضرر جيشه مضاعف في الجولة الأولى.",
		"city": "مدرّب الكتائب", "city_desc": "يسرّع التدريب 15%.", "city_eff": {"train_speed": 0.15},
		"story": "صياد وحوش تحول إلى قائد. يرتدي جلد النمر الذي هزمه في صباه."},
	"bariq": {"name": "بارق", "title": "حدّاد العتمة", "elem": "معدن", "troop": "shield", "color": "e0b070",
		"skill": "صائد الوحوش", "skill_desc": "يزيد الضرر ضد الوحوش 25%.",
		"city": "سيد المناجم", "city_desc": "يزيد إنتاج الفحم والحديد 12%.", "city_eff": {"prod_coal": 0.12, "prod_iron": 0.12},
		"story": "صنع أول فرن في المدينة بيديه. يقول إن الحديد يسمع من يحترمه."},
	"layla": {"name": "ليلى", "title": "عرّافة الشفق", "elem": "شفق", "troop": "bow", "color": "c8a0ff",
		"skill": "نور الشفاء", "skill_desc": "نصف قتلى جيشها يعودون جرحى بعد المعركة.",
		"city": "قارئة السماء", "city_desc": "تزيد بلورات الشفق من العواصف 50%، والعلاج 30%.", "city_eff": {"aurora_gain": 0.5, "heal": 0.3},
		"story": "ظهرت مع أول شفق بعد التجمد. لا أحد يعرف من أين أتت."},
	"salma": {"name": "سلمى", "title": "حكيمة القافلة", "elem": "حكمة", "troop": "spear", "color": "ffd36b",
		"skill": "خطة محكمة", "skill_desc": "يزيد هجوم ودفاع كل الجيش 6%.",
		"city": "أمينة المؤن", "city_desc": "تزيد الطعام والخشب 12%، وسرعة البحث 10%.", "city_eff": {"prod_food": 0.12, "prod_wood": 0.12, "research_speed": 0.1},
		"story": "تحفظ خرائط العالم القديم في ذاكرتها، وتعرف أين يختبئ الدفء."},
}
const HERO_ORDER := ["siraj", "reem", "nimr", "bariq", "layla", "salma"]
const STAR_SHARDS := [10, 10, 20, 30, 50, 80]   # [للفتح، ثم لكل نجمة]
const SUMMON_COST := 60       # بلورة شفق مقابل 10 شظايا

static func hero_bonus(lv: int, stars: int) -> float:
	## نسبة تعزيز نوع جنود البطل (هجوم ودفاع وصحة)
	return 0.05 + 0.008 * lv + 0.05 * stars

static func hero_level_cost(lv: int) -> Dictionary:
	return {"food": int(round(300.0 * pow(lv, 1.45) / 10.0) * 10), "iron": int(round(25.0 * pow(lv, 1.35) / 5.0) * 5)}

static func hero_power(lv: int, stars: int) -> float:
	return 60.0 + 22.0 * lv + 150.0 * stars

# ================================================================ الأبحاث
## eff: مفتاح التأثير • val: قيمته لكل مستوى • lab: مستوى المختبر المطلوب للمستوى الأول • req: بحث سابق
const TECHS := {
	# الاقتصاد
	"saw": {"branch": 0, "name": "مناشير مسنونة", "eff": "prod_wood", "val": 0.05, "max": 8, "lab": 1, "req": "", "cost": {"wood": 600, "coal": 150}, "time": 30.0},
	"trap": {"branch": 0, "name": "فخاخ الصيد", "eff": "prod_food", "val": 0.05, "max": 8, "lab": 1, "req": "", "cost": {"wood": 700, "coal": 150}, "time": 30.0},
	"deep": {"branch": 0, "name": "حفر أعمق", "eff": "prod_coal", "val": 0.05, "max": 8, "lab": 2, "req": "saw", "cost": {"wood": 900, "iron": 120}, "time": 45.0},
	"smelt": {"branch": 0, "name": "صهر الحديد", "eff": "prod_iron", "val": 0.05, "max": 8, "lab": 3, "req": "deep", "cost": {"wood": 1400, "coal": 500}, "time": 60.0},
	"crane": {"branch": 0, "name": "روافع البناء", "eff": "build_speed", "val": 0.04, "max": 10, "lab": 2, "req": "trap", "cost": {"wood": 1200, "iron": 150}, "time": 50.0},
	# البقاء
	"insul": {"branch": 1, "name": "عزل الجدران", "eff": "heat", "val": 1.0, "max": 8, "lab": 1, "req": "", "cost": {"wood": 800, "coal": 300}, "time": 35.0},
	"herbs": {"branch": 1, "name": "طب الأعشاب", "eff": "heal", "val": 0.12, "max": 6, "lab": 1, "req": "", "cost": {"food": 900, "wood": 400}, "time": 35.0},
	"cellar": {"branch": 1, "name": "أقبية مبطنة", "eff": "storage", "val": 0.5, "max": 6, "lab": 2, "req": "insul", "cost": {"wood": 1100, "iron": 100}, "time": 50.0},
	"sled": {"branch": 1, "name": "زلاجات القوافل", "eff": "march_speed", "val": 0.08, "max": 6, "lab": 2, "req": "herbs", "cost": {"wood": 1000, "coal": 400}, "time": 45.0},
	"seer": {"branch": 1, "name": "قراءة الشفق", "eff": "aurora_gain", "val": 0.1, "max": 5, "lab": 3, "req": "cellar", "cost": {"coal": 900, "aurora": 20}, "time": 70.0},
	# الحرب
	"drill": {"branch": 2, "name": "تدريب مكثف", "eff": "train_speed", "val": 0.06, "max": 8, "lab": 1, "req": "", "cost": {"food": 1000, "iron": 80}, "time": 40.0},
	"camp": {"branch": 2, "name": "خيام أوسع", "eff": "train_cap", "val": 10.0, "max": 8, "lab": 1, "req": "", "cost": {"wood": 1000, "food": 600}, "time": 40.0},
	"plate": {"branch": 2, "name": "دروع مصقولة", "eff": "def_shield", "val": 0.04, "max": 8, "lab": 2, "req": "drill", "cost": {"iron": 300, "coal": 400}, "time": 55.0},
	"pike": {"branch": 2, "name": "رماح مقساة", "eff": "atk_spear", "val": 0.04, "max": 8, "lab": 2, "req": "drill", "cost": {"iron": 300, "wood": 600}, "time": 55.0},
	"string": {"branch": 2, "name": "أوتار متينة", "eff": "atk_bow", "val": 0.04, "max": 8, "lab": 2, "req": "camp", "cost": {"iron": 250, "wood": 800}, "time": 55.0},
	"banner": {"branch": 2, "name": "راية الجمر", "eff": "hp_all", "val": 0.04, "max": 6, "lab": 3, "req": "plate", "cost": {"iron": 600, "aurora": 25}, "time": 80.0},
}
const BRANCHES := ["الاقتصاد", "البقاء", "الحرب"]
const EFF_NAMES := {"prod_wood": "إنتاج الخشب", "prod_food": "إنتاج الطعام", "prod_coal": "إنتاج الفحم", "prod_iron": "إنتاج الحديد",
	"build_speed": "سرعة البناء", "heat": "حرارة المدينة", "heal": "سرعة العلاج", "storage": "ساعات التخزين",
	"march_speed": "سرعة الفرق", "aurora_gain": "بلورات الشفق", "train_speed": "سرعة التدريب", "train_cap": "حجم الدفعة",
	"def_shield": "دفاع الدروع", "atk_spear": "هجوم الرمّاحين", "atk_bow": "هجوم الرماة", "hp_all": "صحة كل الجيش",
	"sick_res": "مقاومة المرض", "research_speed": "سرعة البحث"}

static func eff_text(eff: String, v: float) -> String:
	match eff:
		"heat":
			return "+%d°" % int(v)
		"storage":
			return "+%s ساعة" % str(v)
		"train_cap":
			return "+%d جندي" % int(v)
	return "+%d%%" % int(round(v * 100.0))

static func tech_cost(id: String, lv: int) -> Dictionary:
	var out := {}
	for r in TECHS[id]["cost"]:
		out[r] = int(round(float(TECHS[id]["cost"][r]) * pow(1.6, lv - 1) / 10.0) * 10) if r != "aurora" else int(ceil(float(TECHS[id]["cost"][r]) * pow(1.3, lv - 1)))
	return out

static func tech_time(id: String, lv: int) -> float:
	return float(TECHS[id]["time"]) * pow(1.45, lv - 1)

static func tech_lab_req(id: String, lv: int) -> int:
	return int(TECHS[id]["lab"]) + (lv - 1) * 2

# ================================================================ دفتر القائد (قرارات ذات عواقب)
const DECISIONS := [
	{"title": "قافلة لاجئين عند البوابة", "text": "عشرون ناجيًا يرتجفون عند البوابة، ومعهم أطفال. طعامنا محدود.",
		"a": {"label": "افتحوا البوابة", "eff": {"pop": 6, "food": -800, "trust": 8}},
		"b": {"label": "أعطوهم طعامًا وارحلوا", "eff": {"food": -300, "trust": -4}}},
	{"title": "صياد عاد بجرح غريب", "text": "يقول الصياد إنه رأى عرين ذئاب خلف التلال، ويطلب رجالًا للهجوم عليه.",
		"a": {"label": "أرسل الصيادين", "eff": {"food": 1500, "sick": 2}},
		"b": {"label": "لا نخاطر بأحد", "eff": {"trust": 3}}},
	{"title": "تاجر الشمال", "text": "تاجر غامض يعرض بلورات شفق مقابل الحديد.",
		"a": {"label": "بادل الحديد", "eff": {"iron": -300, "aurora": 25}},
		"b": {"label": "اطرده", "eff": {"trust": 2}}},
	{"title": "عمال المنجم يطلبون راحة", "text": "يشكو عمال المنجم من البرد، ويطلبون يوم راحة.",
		"a": {"label": "امنحهم الراحة", "eff": {"coal": -400, "trust": 7}},
		"b": {"label": "العمل لا يتوقف", "eff": {"coal": 600, "trust": -6}}},
	{"title": "مخزن قديم تحت الثلج", "text": "عثر الأطفال على باب حديدي مدفون قرب السور.",
		"a": {"label": "احفروا فورًا", "eff": {"wood": 1200, "iron": 150, "sick": 1}},
		"b": {"label": "أغلقوه، قد يكون فخًا", "eff": {"trust": 1, "gems": 10}}},
	{"title": "حفل الجمر", "text": "يقترح كبار المدينة حفلًا حول الفرن ليرفع المعنويات.",
		"a": {"label": "أقيموا الحفل", "eff": {"food": -600, "wood": -400, "trust": 12}},
		"b": {"label": "ليس الآن", "eff": {"trust": -2}}},
	{"title": "جندي نائم في الحراسة", "text": "وُجد أحد الحراس نائمًا في نوبته الليلية.",
		"a": {"label": "عاقبه أمام الجميع", "eff": {"trust": -5, "troop_bonus": 10}},
		"b": {"label": "سامحه هذه المرة", "eff": {"trust": 4}}},
	{"title": "ضوء الشفق الكبير", "text": "السماء تتوهج بشكل لم نره من قبل. البلورات تتساقط بعيدًا عن المدينة.",
		"a": {"label": "أرسل فريقًا لجمعها", "eff": {"aurora": 35, "sick": 3}},
		"b": {"label": "ابقوا في الدفء", "eff": {"trust": 3, "aurora": 8}}},
	{"title": "طفل مريض في المأوى", "text": "طفل حرارته مرتفعة، والدواء قليل.",
		"a": {"label": "استخدم مخزون الدواء", "eff": {"sick": -4, "trust": 6, "wood": -300}},
		"b": {"label": "انتظروا المستوصف", "eff": {"trust": -5}}},
	{"title": "حطاب يقترح قطع الغابة المقدسة", "text": "شجر ضخم قديم يعتبره الناس رمزًا للمدينة.",
		"a": {"label": "اقطعوها", "eff": {"wood": 2500, "trust": -8}},
		"b": {"label": "احموها", "eff": {"trust": 6}}},
	{"title": "مبارزة تدريبية", "text": "يطلب الجنود مبارزة علنية بين الكتائب.",
		"a": {"label": "وافق وقدّم جائزة", "eff": {"food": -500, "troop_bonus": 15, "trust": 3}},
		"b": {"label": "وفّروا طاقتكم", "eff": {"trust": -1}}},
	{"title": "رسالة من مدينة بعيدة", "text": "طائر يحمل رسالة: مدينة أخرى نجت وتطلب الفحم.",
		"a": {"label": "أرسل الفحم", "eff": {"coal": -700, "gems": 25, "trust": 4}},
		"b": {"label": "نحتاجه أكثر منهم", "eff": {"trust": -3}}},
]

static func decision_effect_text(eff: Dictionary) -> String:
	var parts: Array[String] = []
	for k in eff:
		var v: float = float(eff[k])
		var sgn := "+" if v > 0 else "−"
		if k == "troop_bonus":
			parts.append("%s%d جنود متدربين" % [sgn, int(absf(v))])
		elif k == "trust":
			parts.append("%s%d ثقة" % [sgn, int(absf(v))])
		else:
			parts.append("%s%s %s" % [sgn, fmt(absf(v)), RES_NAMES.get(k, k)])
	return "، ".join(parts)


static func cost(type: String, level: int) -> Dictionary:
	## تكلفة الوصول إلى المستوى level
	var b: Dictionary = BUILDINGS[type]
	var out := {}
	var g := 1.58
	for r in b["cost"]:
		var from: int = b["from"][r]
		if level >= from:
			var v: float = b["cost"][r] * pow(g, level - from)
			out[r] = int(round(v / 10.0) * 10)
	return out


static func build_time(type: String, level: int) -> float:
	return float(BUILDINGS[type]["time"]) * pow(1.42, level - 1)


static func prod_rate(type: String, level: int) -> float:
	## الإنتاج في الساعة بكامل العمال
	if level <= 0 or not BUILDINGS[type].has("prod"):
		return 0.0
	return float(BUILDINGS[type]["rate"]) * level * (1.0 + 0.09 * level)


static func workers_needed(type: String, level: int) -> int:
	if level <= 0:
		return 0
	if BUILDINGS[type].has("prod"):
		return 1 + level
	if type == "infirmary":
		return 1 + level / 2
	return 0


static func shelter_capacity(level: int) -> int:
	return 0 if level <= 0 else 3 + 2 * level


static func furnace_heat(level: int) -> float:
	return 8.0 + 1.6 * level


static func furnace_coal(level: int) -> float:
	## استهلاك الفحم في الساعة (الوضع العادي)
	return 24.0 + 16.0 * level


static func plot_pos(id: String) -> Vector3:
	var p: Dictionary = PLOTS[id]
	var a := deg_to_rad(float(p["a"]))
	return CITY_CENTER + Vector3(cos(a), 0, sin(a)) * float(p["r"])


static func fmt(n: float) -> String:
	var a := absf(n)
	if a >= 1000000.0:
		return "%.1fM" % (n / 1000000.0)
	if a >= 10000.0:
		return "%dK" % int(n / 1000.0)
	if a >= 1000.0:
		return "%.1fK" % (n / 1000.0)
	return str(int(n))


# ================================================================ المرحلة 3: جبهة الصقيع (نموذج أولي)
## منفث حراري جوفي واحد + جبهة برد دورية — إثبات الفكرة قبل التوسع فيها
const VENT := {"x": 700, "y": 920, "guards": 12}
const FRONT_PERIOD := 900.0   # دورة الجبهة: 15 دقيقة
const FRONT_LEN := 180.0     # مدة الجبهة: 3 دقائق
const FRONT_DROP := 6.0      # انخفاض إضافي في الحرارة الخارجية أثناء الجبهة
const VENT_HEAT := 4.0       # دفء المنفث المُحتل (درجات)
const VENT_FIGHT_WORK := 8.0 # مدة المعركة عند المنفث (للرسم والتوقيت)

# ================================================================ تعميق الخريطة: المعاقل والتشكيلات وضباب الحرب
## التشكيلات القتالية لفرقة الاحتلال — تُختار عند الإرسال وتُثبَّت مع ظروف المعركة
const FORMATIONS := {
	"balanced": {"name": "متوازنة", "desc": "الصفوف القياسية: لا مكسب ولا مخاطرة.",
		"atk": 0.0, "def": 0.0, "taken": 1.0, "dead": 0.25},
	"aggressive": {"name": "هجومية", "desc": "زحف كاسح: هجوم +15% ودفاع −15%، وضرر متلقّى +15% وقتلى أكثر.",
		"atk": 0.15, "def": -0.15, "taken": 1.15, "dead": 0.30},
	"defensive": {"name": "دفاعية", "desc": "ترسّح محكم: دفاع +20% وهجوم −10%، وضرر متلقّى −15% وقتلى أقل.",
		"atk": -0.10, "def": 0.20, "taken": 0.85, "dead": 0.18},
}
const FORMATION_ORDER := ["balanced", "aggressive", "defensive"]

## المعاقل والقلاع القابلة للاحتلال (من معالم الخريطة) — الحراس يقوون مع مستوى الفرن
const HOLD_DEFS := {
	"stronghold": {"name": "معقل", "guards": 10, "g_atk": 9.0, "g_def": 6.0, "g_hp": 26.0, "g_scale": 0.11,
		"reward_aurora": 6, "reward_gems": 4, "eff": "+4% إنتاج لكل مورد لكل معقل محتل"},
	"fortress": {"name": "قلعة", "guards": 14, "g_atk": 11.0, "g_def": 8.0, "g_hp": 34.0, "g_scale": 0.13,
		"reward_aurora": 10, "reward_gems": 6, "eff": "−5% قوة غارات الذئاب لكل قلعة محتلة (حتى −40%)"},
}
const STRONGHOLD_PROD := 0.04   # مكافأة المعقل الدائمة: إنتاج لكل مورد
const FORT_RAID_RED := 0.05     # مكافأة القلعة الدائمة: تخفيف الغارات
const FORT_RAID_CAP := 0.40

## ضباب الحرب: شبكة كشف 150×150 (كل خلية 8×8 خانة) — كشف دائم للمناطق لا رؤية آنية
const FOG_CELL := 8
const FOG_GRID := 150
const FOG_REVEAL_HOME := 60.0    # نصف قطر الكشف حول المدينة عند البداية
const FOG_REVEAL_MARCH := 18.0   # نصف قطر الكشف حول مسار الفرق أثناء الحركة
const FOG_REVEAL_SCOUT := 30.0   # نصف قطر كشف فرقة الاستطلاع عند الهدف

static func fmt_time(sec: float) -> String:
	var s := int(ceil(maxf(sec, 0.0)))
	var d := s / 86400
	var h := (s % 86400) / 3600
	var m := (s % 3600) / 60
	var ss := s % 60
	if d > 0:
		return "%dي %02d:%02d:%02d" % [d, h, m, ss]
	if h > 0:
		return "%02d:%02d:%02d" % [h, m, ss]
	return "%02d:%02d" % [m, ss]


static func reward_text(reward: Dictionary) -> String:
	var parts: Array[String] = []
	for k in reward:
		if String(k).begins_with("shards_"):
			parts.append("%d شظايا %s" % [int(reward[k]), HEROES[String(k).substr(7)]["name"]])
		else:
			parts.append("%s %s" % [fmt(float(reward[k])), RES_NAMES.get(k, k)])
	return "، ".join(parts)
