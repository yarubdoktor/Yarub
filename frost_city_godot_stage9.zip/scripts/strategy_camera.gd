extends Node3D
## كاميرا استراتيجية بأسلوب ألعاب الخرائط (Whiteout Survival / Last Empire War)
## - سحب بإصبع واحد: الأرض تبقى تحت الإصبع تمامًا + انزلاق بعد الإفلات
## - إصبعان: تكبير/تصغير نحو منتصف الإصبعين + تحريك في نفس الوقت
## - الميلان يتغير تلقائيًا مع التكبير (قريب = مائل، بعيد = من الأعلى)
## - الفأرة: سحب بالزر الأيسر وعجلة للتكبير (للتجربة على الكمبيوتر)

signal tapped(world_pos: Vector3, screen_pos: Vector2)
signal view_changed(focus: Vector3, dist: float)

@export var map_size := 1200.0
@export var edge_margin := 10.0
@export var min_dist := 12.0
@export var max_dist := 300.0
@export var near_pitch_deg := 40.0
@export var far_pitch_deg := 64.0
@export var yaw_deg := 0.0
@export var friction := 4.5          # كلما زاد توقف الانزلاق أسرع
@export var max_glide_speed := 900.0
@export var zoom_smooth := 12.0
@export var tap_max_move := 14.0
@export var tap_max_time := 0.35
@export var ground_y := 0.2

var cam: Camera3D
var focus := Vector3(600, 0, 600)
var dist := 60.0
var target_dist := 60.0
var velocity := Vector2.ZERO
var ui_hit_test: Callable = Callable()

var _touches := {}            # index -> Vector2
var _ignored := {}            # لمسات بدأت فوق الواجهة
var _tap_start := Vector2.ZERO
var _tap_time := 0.0
var _tap_moved := false
var _last_drag := 0.0
var _clock := 0.0   # ساعة مبنية على delta حتى تعمل بثبات على كل الأجهزة
var _pinch_dist := 0.0
var _pinch_mid := Vector2.ZERO
var _zoom_anchor := Vector2(-1, -1)
var _mouse_down := false
var _tween: Tween
var _fly := false


func _ready() -> void:
	cam = Camera3D.new()
	cam.fov = 38.0
	cam.near = 0.5
	cam.far = 2200.0
	add_child(cam)
	cam.make_current()
	_apply()


# ---------------------------------------------------------------- الإسقاط
func screen_to_ground(sp: Vector2) -> Vector3:
	var o := cam.project_ray_origin(sp)
	var d := cam.project_ray_normal(sp)
	if absf(d.y) < 0.0001:
		return focus
	var t := (ground_y - o.y) / d.y
	if t < 0.0:
		return focus
	return o + d * t


func _pitch() -> float:
	var k := clampf(inverse_lerp(min_dist, max_dist, dist), 0.0, 1.0)
	k = pow(k, 0.7)
	return deg_to_rad(lerpf(near_pitch_deg, far_pitch_deg, k))


func _apply() -> void:
	focus.x = clampf(focus.x, edge_margin, map_size - edge_margin)
	focus.z = clampf(focus.z, edge_margin, map_size - edge_margin)
	focus.y = ground_y
	global_position = focus
	var p := _pitch()
	var off := Vector3(0, sin(p), cos(p)) * dist
	off = off.rotated(Vector3.UP, deg_to_rad(yaw_deg))
	cam.global_position = focus + off
	cam.look_at(focus, Vector3.UP)
	view_changed.emit(focus, dist)


func _pan(from_sp: Vector2, to_sp: Vector2) -> void:
	var a := screen_to_ground(from_sp)
	var b := screen_to_ground(to_sp)
	var delta := a - b
	focus += Vector3(delta.x, 0, delta.z)
	var dt := maxf(_clock - _last_drag, 1.0 / 120.0)
	_last_drag = _clock
	var inst := Vector2(delta.x, delta.z) / dt
	velocity = velocity.lerp(inst, 0.4).limit_length(max_glide_speed)
	_apply()


## تكبير يحافظ على النقطة تحت الشاشة ثابتة
func _zoom_keep(sp: Vector2, new_dist: float) -> void:
	var before := screen_to_ground(sp)
	dist = clampf(new_dist, min_dist, max_dist)
	_apply()
	var after := screen_to_ground(sp)
	focus += Vector3(before.x - after.x, 0, before.z - after.z)
	_apply()


func _stop_motion() -> void:
	velocity = Vector2.ZERO
	if _tween and _tween.is_valid():
		_tween.kill()
	_fly = false


func _over_ui(p: Vector2) -> bool:
	return ui_hit_test.is_valid() and ui_hit_test.call(p)


# ---------------------------------------------------------------- الإدخال
func _unhandled_input(event: InputEvent) -> void:
	# تجاهل أحداث الفأرة المحاكاة من اللمس (نستعمل اللمس مباشرة)
	if event is InputEventMouse and event.device == InputEvent.DEVICE_ID_EMULATION:
		return

	if event is InputEventScreenTouch:
		_on_touch(event)
	elif event is InputEventScreenDrag:
		_on_drag(event)
	elif event is InputEventMouseButton:
		_on_mouse_button(event)
	elif event is InputEventMouseMotion and _mouse_down:
		if (event.position - _tap_start).length() > tap_max_move:
			_tap_moved = true
		_pan(event.position - event.relative, event.position)
	elif event is InputEventMagnifyGesture:
		_zoom_keep(event.position, dist / event.factor)
		target_dist = dist
	elif event is InputEventPanGesture:
		_pan(event.position, event.position - event.delta * 8.0)


func _on_touch(e: InputEventScreenTouch) -> void:
	if e.pressed:
		if _over_ui(e.position):
			_ignored[e.index] = true
			return
		_stop_motion()
		_touches[e.index] = e.position
		target_dist = dist
		if _touches.size() == 1:
			_tap_start = e.position
			_tap_time = _clock
			_tap_moved = false
			_last_drag = _clock
		elif _touches.size() == 2:
			_tap_moved = true
			_init_pinch()
	else:
		if _ignored.has(e.index):
			_ignored.erase(e.index)
			return
		_touches.erase(e.index)
		if _touches.size() == 0:
			var held := _clock - _tap_time
			if not _tap_moved and held < tap_max_time:
				velocity = Vector2.ZERO
				tapped.emit(screen_to_ground(e.position), e.position)
			elif _clock - _last_drag > 0.09:
				velocity = Vector2.ZERO   # الإصبع توقف قبل الإفلات
		elif _touches.size() == 1:
			velocity = Vector2.ZERO
			_last_drag = _clock
		else:
			_init_pinch()


func _init_pinch() -> void:
	var pts := _touches.values()
	_pinch_dist = maxf((pts[0] - pts[1]).length(), 1.0)
	_pinch_mid = (pts[0] + pts[1]) * 0.5


func _on_drag(e: InputEventScreenDrag) -> void:
	if _ignored.has(e.index) or not _touches.has(e.index):
		return
	var prev: Vector2 = _touches[e.index]
	_touches[e.index] = e.position
	if _touches.size() == 1:
		if (e.position - _tap_start).length() > tap_max_move:
			_tap_moved = true
		if _tap_moved:
			_pan(prev, e.position)
	else:
		var pts := _touches.values()
		var d := maxf((pts[0] - pts[1]).length(), 1.0)
		var mid: Vector2 = (pts[0] + pts[1]) * 0.5
		_zoom_keep(_pinch_mid, dist * _pinch_dist / d)
		target_dist = dist
		_pan(_pinch_mid, mid)
		velocity = Vector2.ZERO
		_pinch_dist = d
		_pinch_mid = mid


func _on_mouse_button(e: InputEventMouseButton) -> void:
	match e.button_index:
		MOUSE_BUTTON_LEFT:
			if e.pressed:
				if _over_ui(e.position):
					return
				_stop_motion()
				_mouse_down = true
				_tap_start = e.position
				_tap_time = _clock
				_tap_moved = false
				_last_drag = _clock
			elif _mouse_down:
				_mouse_down = false
				var held := _clock - _tap_time
				if not _tap_moved and held < tap_max_time:
					velocity = Vector2.ZERO
					tapped.emit(screen_to_ground(e.position), e.position)
				elif _clock - _last_drag > 0.09:
					velocity = Vector2.ZERO
		MOUSE_BUTTON_WHEEL_UP:
			if e.pressed:
				target_dist = clampf(target_dist * 0.85, min_dist, max_dist)
				_zoom_anchor = e.position
		MOUSE_BUTTON_WHEEL_DOWN:
			if e.pressed:
				target_dist = clampf(target_dist * 1.18, min_dist, max_dist)
				_zoom_anchor = e.position


# ---------------------------------------------------------------- كل إطار
func _process(delta: float) -> void:
	_clock += delta
	if _fly:
		_apply()
		return
	var moving := false
	if _touches.is_empty() and not _mouse_down and velocity.length() > 0.5:
		focus += Vector3(velocity.x, 0, velocity.y) * delta
		velocity *= exp(-friction * delta)
		# ارتداد ناعم عند حدود الخريطة
		if focus.x <= edge_margin or focus.x >= map_size - edge_margin:
			velocity.x = 0.0
		if focus.z <= edge_margin or focus.z >= map_size - edge_margin:
			velocity.y = 0.0
		moving = true
	if absf(target_dist - dist) > 0.01:
		var nd := lerpf(dist, target_dist, 1.0 - exp(-zoom_smooth * delta))
		var anchor := _zoom_anchor
		if anchor.x < 0:
			anchor = get_viewport().get_visible_rect().size * 0.5
		_zoom_keep(anchor, nd)
		moving = false
	elif moving:
		_apply()


## انتقال سلس إلى موقع (مثل زر "مدينتي")
func fly_to(pos: Vector3, to_dist: float = -1.0, time: float = 0.9) -> void:
	_stop_motion()
	if to_dist < 0:
		to_dist = dist
	_fly = true
	var from_focus := focus
	var from_dist := dist
	# يرتفع قليلًا أثناء الانتقال البعيد ثم ينزل
	var lift := clampf(from_focus.distance_to(pos) * 0.25, 0.0, 120.0)
	_tween = create_tween()
	_tween.tween_method(func(t: float) -> void:
		var e := t * t * (3.0 - 2.0 * t)
		focus = from_focus.lerp(pos, e)
		dist = lerpf(from_dist, to_dist, e) + sin(t * PI) * lift
		, 0.0, 1.0, time)
	_tween.finished.connect(func() -> void:
		_fly = false
		target_dist = dist
		_zoom_anchor = Vector2(-1, -1)
		_apply())


func set_view(pos: Vector3, d: float) -> void:
	focus = pos
	dist = clampf(d, min_dist, max_dist)
	target_dist = dist
	_apply()
