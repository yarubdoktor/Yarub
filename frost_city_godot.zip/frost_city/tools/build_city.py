"""Builds the city (base) 3D assets as GLB for Godot 4.
Run: python3 build_city.py   -> ../assets/city/*.glb
City space: 120 x 120 metres, furnace at (60, 60). Y is up. Models face +Z.
"""
import os
import numpy as np
from glb import GLB, MeshBuilder, T, box_soup, cyl_soup, cone_soup, octa_soup, ring_soup

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "assets", "city")
os.makedirs(OUT, exist_ok=True)


def lin(h):
    return (np.array([(h >> 16) & 255, (h >> 8) & 255, h & 255], np.float32) / 255) ** 2.2


C = {k: lin(v) for k, v in dict(
    snow=0xcbd7e2, snowD=0xa9bccd, path=0x8a8f96, stone=0x8e9aa6, stoneD=0x5f6b77, wood=0x7a4b2a, woodL=0xa36a3e,
    woodD=0x4e2f1a, roof=0xe9eef2, metal=0x3b3f45, metalL=0x6c737c, fire=0xffa04d, pine=0x2f5a4a, rock=0x6d7884,
    coal=0x2b2b2e, iron=0x86b6d6, meat=0xb5523b, canvas=0xd9c08a, red=0xd33f3f, blue=0x4fb4ff, gold=0xe8b44a,
    coat=0x3d6e9e, coat2=0x9e4a3d, skin=0xf1d2b3, white=0xf4f6f8, glass=0xffd38a).items()}

ROT_X = np.array([[1, 0, 0, 0], [0, 0, -1, 0], [0, 1, 0, 0], [0, 0, 0, 1]], np.float32)   # y->z
ROT_Z = np.array([[0, -1, 0, 0], [1, 0, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]], np.float32)   # y->-x


def save(name, mb):
    g = GLB()
    n = g.add_node(name, mesh=g.add_mesh(name, mb))
    g.save(os.path.join(OUT, f"{name}.glb"), [n])


def roof_gable(m, w, d, h, y0, col, xf=np.eye(4, dtype=np.float32)):
    """Triangular prism roof along X."""
    x, z = w / 2, d / 2
    v = np.array([[-x, y0, -z], [x, y0, -z], [x, y0, z], [-x, y0, z], [-x, y0 + h, 0], [x, y0 + h, 0]], np.float32)
    f = [(0, 4, 5), (0, 5, 1), (3, 2, 5), (3, 5, 4), (0, 3, 4), (1, 5, 2)]
    m.add_soup("Matte", v[np.array(f)], col, xf)


def window(m, x, y, z, ry=0.0, s=1.0):
    m.add_soup("Fire", box_soup(.36 * s, .4 * s, .05), C["glass"], T(x, y, z, ry=ry))


# ================================================================ buildings (3 visual tiers)
def furnace(t):
    m = MeshBuilder()
    r = 4.2 + t * .6
    m.add_soup("Matte", cyl_soup(r + 1.2, r + 1.0, .5, 10), C["stoneD"], T(ry=np.pi / 10))
    m.add_soup("Matte", cyl_soup(r, r - .3, 1.4, 10, y0=.5), C["stone"], T(ry=np.pi / 10))
    h = 3.5 + t * 1.6
    m.add_soup("Metal", cyl_soup(r * .62, r * .5, h, 14, y0=1.9), C["metal"])
    for k in range(2 + t):
        m.add_soup("Metal", ring_soup(r * .5, r * .66, .25, 18, y0=2.4 + k * 1.3), C["metalL"])
    top = 1.9 + h
    m.add_soup("Matte", ring_soup(r * .42, r * .6, .35, 16, y0=top), C["stoneD"])
    m.add_soup("Fire", cyl_soup(r * .44, r * .44, .45, 16, y0=top - .1), C["fire"])
    m.add_soup("Metal", cyl_soup(.7 + t * .1, .55, 3.5 + t, 10, y0=top), C["metal"])
    # furnace doors with fire glow
    for a in range(4):
        ang = a * np.pi / 2 + np.pi / 4
        m.add_soup("Fire", box_soup(1.2, 1.1, .2), C["fire"], T(np.cos(ang) * r * .6, 2.0, np.sin(ang) * r * .6, ry=-ang + np.pi / 2))
    # pipes and coal heaps
    for a in range(3 + t):
        ang = a / (3 + t) * 2 * np.pi
        px, pz = np.cos(ang) * (r * .9), np.sin(ang) * (r * .9)
        m.add_soup("Metal", cyl_soup(.25, .25, 2.4 + t * .5, 6, y0=1.9), C["metalL"], T(px, 0, pz))
        m.add_soup("Metal", cyl_soup(.35, .35, .3, 6, y0=4.2 + t * .5), C["metal"], T(px, 0, pz))
    for k in range(4):
        ang = k * np.pi / 2
        m.add_soup("Matte", octa_soup(.6, np.array([1.3, .6, 1.1])), C["coal"], T(np.cos(ang) * (r + .6), .5, np.sin(ang) * (r + .6)))
    if t >= 2:
        for a in range(6):
            ang = a / 6 * 2 * np.pi
            m.add_soup("Matte", cyl_soup(.5, .45, 2.2, 8, y0=.5), C["stone"], T(np.cos(ang) * (r - .1), 0, np.sin(ang) * (r - .1)))
            m.add_soup("Matte", cone_soup(.65, .8, 8, y0=2.7), C["gold"], T(np.cos(ang) * (r - .1), 0, np.sin(ang) * (r - .1)))
    return m


def shelter(t):
    m = MeshBuilder()
    if t == 0:
        m.add_soup("Matte", cone_soup(1.5, 2.2, 6), C["canvas"])
        m.add_soup("Matte", cone_soup(.9, .5, 6, y0=1.75), C["roof"])
        m.add_soup("Matte", box_soup(.06, 2.6, .06), C["woodD"])
        m.add_soup("Matte", box_soup(.5, .8, .1), C["woodD"], T(0, 0, 1.25))
    else:
        w, d, h = (2.6, 2.2, 1.4) if t == 1 else (3.0, 2.6, 1.9)
        m.add_soup("Matte", box_soup(w + .3, .25, d + .3), C["stoneD"])
        m.add_soup("Matte", box_soup(w, h, d, y0=.25), C["wood"] if t == 1 else C["stone"])
        roof_gable(m, w + .5, d + .6, 1.2, .25 + h, C["roof"])
        m.add_soup("Matte", box_soup(.6, .95, .08), C["woodD"], T(0, .25, d / 2 + .02))
        window(m, -w * .3, .25 + h * .55, d / 2 + .03)
        window(m, w * .3, .25 + h * .55, d / 2 + .03)
        m.add_soup("Matte", box_soup(.35, 1.0, .35, y0=.25 + h + .3), C["stoneD"], T(w * .3, 0, -d * .2))
        if t == 2:
            m.add_soup("Matte", box_soup(.9, .4, .9, y0=.25), C["woodL"], T(-w / 2 - .7, 0, .4))
    return m


def hunter(t):
    m = MeshBuilder()
    s = 1 + t * .15
    m.add_soup("Matte", box_soup(2.4 * s, .2, 2.0 * s), C["woodD"])
    m.add_soup("Matte", box_soup(2.0 * s, 1.3 * s, 1.6 * s, y0=.2), C["woodL"])
    roof_gable(m, 2.5 * s, 2.1 * s, 1.0 * s, .2 + 1.3 * s, C["roof"])
    m.add_soup("Matte", box_soup(.5, .8, .08), C["woodD"], T(0, .2, .8 * s + .02))
    # drying rack with meat
    for x in (1.7, 2.9):
        m.add_soup("Matte", box_soup(.08, 1.3, .08), C["woodD"], T(x * s, 0, .4))
    m.add_soup("Matte", box_soup(1.3 * s, .06, .06), C["woodD"], T(2.3 * s, 1.25, .4))
    for k in range(2 + t):
        m.add_soup("Matte", box_soup(.18, .4, .12), C["meat"], T((1.9 + k * .32) * s, .85, .4))
    # antlers on roof
    m.add_soup("Matte", box_soup(.08, .5, .08), C["white"], T(-.2, .2 + 2.3 * s, .9 * s))
    m.add_soup("Matte", box_soup(.08, .5, .08), C["white"], T(.2, .2 + 2.3 * s, .9 * s))
    if t >= 1:
        m.add_soup("Matte", cyl_soup(.35, .3, .5, 8), C["woodD"], T(-1.7 * s, 0, .6))
    return m


def sawmill(t):
    m = MeshBuilder()
    s = 1 + t * .15
    m.add_soup("Matte", box_soup(3.4 * s, .2, 2.4 * s), C["woodD"])
    for x in (-1.5, 1.5):
        for z in (-1.0, 1.0):
            m.add_soup("Matte", box_soup(.15, 1.8 * s, .15, y0=.2), C["wood"], T(x * s, 0, z * s))
    roof_gable(m, 3.6 * s, 2.6 * s, .9, .2 + 1.8 * s, C["roof"])
    m.add_soup("Matte", box_soup(2.2 * s, .6, .5, y0=.2), C["woodD"], T(0, 0, 0))
    m.add_soup("Metal", cyl_soup(.6, .6, .06, 16, y0=-.03), C["metalL"], T(0, .9, 0) @ ROT_X)
    for k in range(3 + t * 2):
        y = .35 + (k % 3) * .36
        zz = 1.7 * s + (k // 3) * .45
        m.add_soup("Matte", cyl_soup(.18, .18, 2.2, 7, y0=-1.1), C["woodL"], T(-.2, y, zz) @ ROT_Z)
    return m


def coal_mine(t, ore="coal"):
    m = MeshBuilder()
    s = 1 + t * .15
    oc = C["coal"] if ore == "coal" else C["iron"]
    m.add_soup("Matte", octa_soup(2.0 * s, np.array([1.3, .9, 1.0])), C["rock"], T(0, .2, -.6))
    m.add_soup("Matte", octa_soup(1.2 * s, np.array([1.0, .8, 1.0])), C["stoneD"], T(1.3 * s, .1, -.9))
    m.add_soup("Matte", box_soup(1.4, 1.5, .5), C["woodD"], T(0, 0, .9 * s))
    m.add_soup("Matte", box_soup(1.0, 1.1, .52), C["coal"], T(0, 0, .92 * s))
    m.add_soup("Matte", box_soup(1.7, .2, .55, y0=1.5), C["wood"], T(0, 0, .9 * s))
    # rails + cart
    for x in (-.3, .3):
        m.add_soup("Metal", box_soup(.06, .05, 2.4), C["metalL"], T(x, 0, 2.0 * s))
    m.add_soup("Metal", box_soup(.8, .45, .6, y0=.12), C["metal"], T(0, 0, 2.3 * s))
    m.add_soup("Matte", octa_soup(.3, np.array([1.2, .7, 1])), oc, T(0, .6, 2.3 * s))
    for k in range(2 + t):
        m.add_soup("Matte", octa_soup(.45, np.array([1.2, .7, 1.1])), oc, T(-1.6 * s + k * .5, .25, 1.4 * s))
    if ore == "iron":
        m.add_soup("Matte", box_soup(.15, 2.6 * s, .15), C["wood"], T(1.6 * s, 0, 1.2 * s))
        m.add_soup("Matte", box_soup(1.4, .12, .12), C["wood"], T(1.1 * s, 2.5 * s, 1.2 * s))
        for k in range(3):
            m.add_soup("Metal", cone_soup(.14, .7, 5), C["iron"], T(-1.2 + k * .4, .4, -.0 + .4 * s))
    return m


def storehouse(t):
    m = MeshBuilder()
    s = 1 + t * .2
    w, d, h = 3.6 * s, 2.6 * s, 1.6 * s
    m.add_soup("Matte", box_soup(w + .4, .25, d + .4), C["stoneD"])
    m.add_soup("Matte", box_soup(w, h, d, y0=.25), C["wood"])
    roof_gable(m, w + .4, d + .5, 1.3 * s, .25 + h, C["roof"])
    m.add_soup("Matte", box_soup(1.2, 1.2, .08), C["woodD"], T(0, .25, d / 2 + .02))
    m.add_soup("Matte", box_soup(1.25, .08, .1), C["woodL"], T(0, .85, d / 2 + .05))
    for k in range(3 + t * 2):
        m.add_soup("Matte", box_soup(.6, .6, .6), C["woodL"], T(-w / 2 - .5 + (k % 2) * .1, (k // 2) * .6, d / 2 - .2 - (k % 2) * .7))
    for k in range(2 + t):
        m.add_soup("Matte", cyl_soup(.3, .3, .8, 8), C["woodD"], T(w / 2 + .5, 0, d / 2 - .3 - k * .7))
    return m


def infirmary(t):
    m = MeshBuilder()
    s = 1 + t * .15
    if t == 0:
        m.add_soup("Matte", box_soup(2.6, .15, 2.0), C["woodD"])
        roof_gable(m, 2.6, 2.0, 1.6, .15, C["white"])
    else:
        w, d, h = 3.0 * s, 2.2 * s, 1.5 * s
        m.add_soup("Matte", box_soup(w + .3, .2, d + .3), C["stoneD"])
        m.add_soup("Matte", box_soup(w, h, d, y0=.2), C["white"])
        roof_gable(m, w + .4, d + .5, 1.0, .2 + h, C["roof"])
        window(m, -w * .3, .2 + h * .55, d / 2 + .03)
        window(m, w * .3, .2 + h * .55, d / 2 + .03)
        m.add_soup("Matte", box_soup(.6, 1.0, .08), C["woodD"], T(0, .2, d / 2 + .02))
    y = 1.85 if t == 0 else .2 + 1.5 * s + 1.1
    m.add_soup("Matte", box_soup(.9, .25, .1), C["red"], T(0, y, .0))
    m.add_soup("Matte", box_soup(.25, .9, .1), C["red"], T(0, y - .32, .0))
    m.add_soup("Matte", box_soup(.08, 2.4, .08), C["woodD"], T(1.8 * s, 0, .9))
    m.add_soup("Matte", box_soup(.6, .4, .04), C["red"], T(1.5 * s, 2.0, .9))
    return m


BUILDERS = {"furnace": furnace, "shelter": shelter, "hunter": hunter, "sawmill": sawmill,
            "coal_mine": coal_mine, "iron_mine": lambda t: coal_mine(t, "iron"),
            "storehouse": storehouse, "infirmary": infirmary}


def plot():
    m = MeshBuilder()
    m.add_soup("Snow", cyl_soup(1.9, 1.8, .08, 8), C["snowD"], T(ry=np.pi / 8))
    for k in range(4):
        a = k * np.pi / 2 + np.pi / 4
        m.add_soup("Matte", box_soup(.12, .6, .12), C["woodD"], T(np.cos(a) * 1.6, 0, np.sin(a) * 1.6))
        m.add_soup("Matte", box_soup(.2, .1, .2), C["blue"], T(np.cos(a) * 1.6, .6, np.sin(a) * 1.6))
    return m


def scaffold():
    m = MeshBuilder()
    for x in (-1.4, 1.4):
        for z in (-1.4, 1.4):
            m.add_soup("Matte", box_soup(.1, 2.6, .1), C["woodL"], T(x, 0, z))
    for y in (.9, 1.8, 2.6):
        for (x, z, w, d) in [(0, 1.4, 2.9, .08), (0, -1.4, 2.9, .08), (1.4, 0, .08, 2.9), (-1.4, 0, .08, 2.9)]:
            m.add_soup("Matte", box_soup(w, .08, d, y0=y), C["woodL"], T(x, 0, z))
    m.add_soup("Matte", box_soup(.8, .4, .5), C["woodD"], T(1.9, 0, 1.0))
    m.add_soup("Matte", octa_soup(.4, np.array([1.3, .6, 1])), C["stone"], T(-1.9, .2, .8))
    m.add_soup("Matte", box_soup(.6, .12, .6), C["gold"], T(0, 2.7, 0))
    return m


def citizen(col):
    m = MeshBuilder()
    m.add_soup("Matte", cyl_soup(.16, .12, .48, 6), col)
    m.add_soup("Matte", octa_soup(.12), C["skin"], T(0, .6, 0))
    m.add_soup("Matte", cone_soup(.14, .16, 6, y0=.66), col)
    return m


def ground():
    """Heightfield 160x160 (from -20 to 140), flat inside r<44, hills outside, trees, wall, paths."""
    rng = np.random.default_rng(7)
    N = 161
    xs = np.linspace(-20, 140, N)
    GX, GZ = np.meshgrid(xs, xs)
    d = np.hypot(GX - 60, GZ - 60)
    noise = np.zeros_like(GX)
    for f, a in [(.05, 1), (.11, .5), (.23, .25)]:
        ph = rng.uniform(0, 6, 2)
        noise += a * np.sin(GX * f + ph[0]) * np.cos(GZ * f * 1.3 + ph[1])
    k = np.clip((d - 50) / 30, 0, 1)
    H = k * k * (6 + 10 * (noise + 1)) + np.clip((d - 72) / 10, 0, 1) * 8 * (noise + 1.2)
    H += (noise * .15) * (d > 46)
    # colors
    col = np.tile(C["snow"], (N, N, 1))
    col = col * (1 - .25 * (noise[..., None] + 1) / 2) + C["snowD"] * (.25 * (noise[..., None] + 1) / 2)
    dHz, dHx = np.gradient(H, xs, xs)
    slope = np.hypot(dHx, dHz)
    rk = np.clip((slope - .5) / .6, 0, .85)[..., None]
    col = col * (1 - rk) + C["rock"] * rk
    # paths: ring roads + radial roads to the gate
    ang = np.arctan2(GZ - 60, GX - 60)
    p = np.zeros_like(d)
    for rr in (11.5, 24.0, 36.0):
        p = np.maximum(p, np.clip(1 - np.abs(d - rr) / 1.4, 0, 1))
    for a0 in np.radians([90, 210, 330, 30, 150, 270]):
        da = np.abs(np.angle(np.exp(1j * (ang - a0)))) * d
        p = np.maximum(p, np.clip(1 - da / 1.2, 0, 1) * (d < 47) * (d > 6))
    col = col * (1 - p[..., None] * .55) + C["path"] * (p[..., None] * .55)
    m = MeshBuilder()
    pos = np.stack([GX, H, GZ], -1).reshape(-1, 3)
    nrm = np.stack([-dHx, np.ones_like(H), -dHz], -1)
    nrm = (nrm / np.linalg.norm(nrm, axis=-1, keepdims=True)).reshape(-1, 3)
    idx = []
    for r in range(N - 1):
        for c in range(N - 1):
            a = r * N + c
            idx += [a, a + N, a + 1, a + 1, a + N, a + N + 1]
    m.add("Snow", pos, nrm, col.reshape(-1, 3), idx)

    def h_at(x, z):
        i = int(round((z + 20))); j = int(round((x + 20)))
        return H[min(max(i, 0), N - 1), min(max(j, 0), N - 1)]

    # palisade wall (gate gap toward +Z / south)
    n = 150
    for i in range(n):
        a = i / n * 2 * np.pi
        if abs(np.angle(np.exp(1j * (a - np.pi / 2)))) < .09:
            continue
        x, z = 60 + np.cos(a) * 46, 60 + np.sin(a) * 46
        hh = 1.6 + (i % 3) * .25
        m.add_soup("Matte", cyl_soup(.22, .2, hh, 5), C["wood"], T(x, h_at(x, z) - .1, z))
        m.add_soup("Matte", cone_soup(.22, .35, 5, y0=hh - .1), C["woodD"], T(x, h_at(x, z) - .1, z))
    for s in (-1, 1):
        a = np.pi / 2 + s * .11
        x, z = 60 + np.cos(a) * 46, 60 + np.sin(a) * 46
        m.add_soup("Matte", cyl_soup(.8, .7, 3.4, 8), C["stone"], T(x, 0, z))
        m.add_soup("Matte", cone_soup(1.0, 1.2, 8, y0=3.4), C["blue"], T(x, 0, z))
        m.add_soup("Fire", box_soup(.3, .3, .3, y0=3.2), C["fire"], T(x, 0, z + .75))
    # trees outside the wall
    trunk = cyl_soup(.12, .1, .6, 5)
    cones = [cone_soup(.9, 1.4, 6, y0=.5), cone_soup(.7, 1.2, 6, y0=1.2), cone_soup(.45, .9, 6, y0=1.9)]
    cnt = 0
    while cnt < 700:
        x, z = rng.uniform(-18, 138, 2)
        dd = np.hypot(x - 60, z - 60)
        if dd < 48.5 or (abs(x - 60) < 4 and z > 100):
            continue
        s = rng.uniform(.8, 1.6)
        xf = T(x, h_at(x, z) - .05, z, ry=rng.uniform(0, 6), s=s)
        m.add_soup("Matte", trunk, C["woodD"], xf)
        for kk, cn in enumerate(cones):
            m.add_soup("Matte", cn, C["pine"] if kk < 2 else C["snow"], xf)
        cnt += 1
    for i in range(120):
        x, z = rng.uniform(-18, 138, 2)
        if np.hypot(x - 60, z - 60) < 50:
            continue
        m.add_soup("Matte", octa_soup(rng.uniform(.6, 1.6), rng.uniform(.6, 1.3, 3)), C["rock"], T(x, h_at(x, z), z, ry=rng.uniform(0, 6)))
    # inner decoration: lamp posts along inner road
    for i in range(12):
        a = i / 12 * 2 * np.pi + .26
        x, z = 60 + np.cos(a) * 17.5, 60 + np.sin(a) * 17.5
        m.add_soup("Metal", box_soup(.1, 2.0, .1), C["metal"], T(x, 0, z))
        m.add_soup("Fire", box_soup(.28, .28, .28, y0=2.0), C["fire"], T(x, 0, z))
    return m


if __name__ == "__main__":
    for name, fn in BUILDERS.items():
        for t in range(3):
            save(f"{name}_t{t}", fn(t))
    save("plot", plot())
    save("scaffold", scaffold())
    save("citizen_a", citizen(C["coat"]))
    save("citizen_b", citizen(C["coat2"]))
    save("ground", ground())
    for f in sorted(os.listdir(OUT)):
        if f.endswith(".glb"):
            print(f, round(os.path.getsize(os.path.join(OUT, f)) / 1e3, 1), "KB")
