extends Node3D
## خريطة الصقيع 1200×1200 — المشهد الرئيسي
## يحمّل الخريطة GLB، ويوزّع المدن والموارد والوحوش من ملف JSON،
## ويبني الواجهة العربية ونظام إرسال القوات.

const StrategyCamera := preload("res://scripts/strategy_camera.gd")
const Defs := preload("res://scripts/defs.gd")
const MAP_PATH := "res://assets/frost_map.glb"
const DATA_PATH := "res://data/map_data.json"
const FONT_PATH := "res://fonts/NotoKufiArabic.ttf"

const RES_NAMES := {"coal": "منجم فحم", "wood": "معسكر خشب", "iron": "منجم حديد", "food": "أرض صيد"}
const RES_GAIN := {"coal": 1800, "wood": 3200, "iron": 600, "food": 4500}
const BEAST_NAMES := {"wolf": "ذئب الثلج", "bear": "دب قطبي"}
const TEAM_NAMES := {"me": "مدينتك", "ally": "تحالف حليف", "enemy": "تحالف عدو", "neutral": "محايد"}
const LM_TYPES := {"sun_city": "المركز — معركة السيادة", "stronghold": "معقل", "fortress": "قلعة",
		"gate": "بوابة", "pass": "ممر جبلي"}

var data: Dictionary
var rig: Node3D
var font: Font
var lookup := {}
var env: Environment
var sky_mat: ProceduralSkyMaterial
var sun: DirectionalLight3D
var night := false
var snow: CPUParticles3D

var ui: Control
var ui_blockers: Array[Control] = []
var coord_label: Label
var res_label: Label
var march_label: Label
var panel: PanelContainer
var p_title: Label
var p_sub: Label
var p_info: Label
var p_action: Button
var toast: Label
var toast_time := 0.0

var selected: Dictionary = {}
var sel_ring: MeshInstance3D
var sel_rr := 1.0
var home_node: MeshInstance3D
var home_label: Label3D
var home_pos: Vector3
var home_info: Dictionary
var troop_mesh: Mesh
var march_mat: StandardMaterial3D


func _ready() -> void:
	font = load(FONT_PATH)
	data = JSON.parse_string(FileAccess.get_file_as_string(DATA_PATH))
	_setup_env()
	var map: Node = load(MAP_PATH).instantiate()
	_fix_materials(map)
	add_child(map)
	_spawn_all()
	_setup_camera()
	_setup_ui()
	_toast("اسحب للتحرك • إصبعان للتكبير • اضغط على أي خانة")
	Game.changed.connect(_refresh_stock)
	Game.toast.connect(_toast)


# ================================================================ البيئة
func _setup_env() -> void:
	env = Environment.new()
	sky_mat = ProceduralSkyMaterial.new()
	var sky := Sky.new()
	sky.sky_material = sky_mat
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.tonemap_white = 1.6
	env.fog_enabled = true
	env.glow_enabled = true
	env.glow_intensity = 0.35
	env.glow_hdr_threshold = 1.6
	env.glow_bloom = 0.0
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)
	sun = DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-52, -35, 0)
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 260.0
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
	add_child(sun)
	_apply_daytime()


func _apply_daytime() -> void:
	if night:
		sky_mat.sky_top_color = Color("101826")
		sky_mat.sky_horizon_color = Color("2a3346")
		sky_mat.ground_horizon_color = Color("2a3346")
		sky_mat.ground_bottom_color = Color("101826")
		env.ambient_light_energy = 0.3
		env.fog_light_color = Color("222b3c")
		env.fog_density = 0.0022
		sun.light_color = Color("c4d0f0")
		sun.light_energy = 0.35
	else:
		sky_mat.sky_top_color = Color("8fb4d4")
		sky_mat.sky_horizon_color = Color("e2ebf2")
		sky_mat.ground_horizon_color = Color("e2ebf2")
		sky_mat.ground_bottom_color = Color("c9d6e0")
		env.ambient_light_energy = 0.4
		env.fog_light_color = Color("dde7ef")
		env.fog_density = 0.0012
		sun.light_color = Color("fff1dc")
		sun.light_energy = 0.95


# ================================================================ توزيع العناصر
func _find_mesh(n: Node) -> MeshInstance3D:
	if n is MeshInstance3D:
		return n
	for c in n.get_children():
		var r := _find_mesh(c)
		if r:
			return r
	return null


## نضمن أن ألوان الرؤوس (Vertex Colors) تُستخدم كلون أساسي للمواد
func _fix_mesh(m: Mesh) -> void:
	for s in m.get_surface_count():
		var mat := m.surface_get_material(s) as BaseMaterial3D
		if mat:
			mat.vertex_color_use_as_albedo = true
			if mat.resource_name == "Snow" or mat.resource_name == "Matte":
				mat.metallic_specular = 0.25


func _fix_materials(n: Node) -> void:
	if n is MeshInstance3D and n.mesh:
		_fix_mesh(n.mesh)
	for c in n.get_children():
		_fix_materials(c)


func _mesh_from(path: String) -> Mesh:
	var inst: Node = load(path).instantiate()
	var mi := _find_mesh(inst)
	var m: Mesh = mi.mesh
	_fix_mesh(m)
	inst.free()
	return m


func _spawn_group(mesh: Mesh, items: Array) -> void:
	var regions := {}
	for it in items:
		var key := Vector2i(int(it["x"]) / 300, int(it["y"]) / 300)
		if not regions.has(key):
			regions[key] = []
		regions[key].append(it)
	for key in regions:
		var arr: Array = regions[key]
		var mm := MultiMesh.new()
		mm.transform_format = MultiMesh.TRANSFORM_3D
		mm.mesh = mesh
		mm.instance_count = arr.size()
		for i in arr.size():
			var it: Dictionary = arr[i]
			var ry: float = it.get("ry", fmod(it["x"] * 12.9898 + it["y"] * 78.233, TAU))
			var b := Basis(Vector3.UP, ry)
			mm.set_instance_transform(i, Transform3D(b, Vector3(it["x"], it["h"], it["y"])))
		var mmi := MultiMeshInstance3D.new()
		mmi.multimesh = mm
		add_child(mmi)


func _reg(x0: int, y0: int, w: int, info: Dictionary) -> void:
	for dx in w:
		for dy in w:
			lookup[Vector2i(x0 + dx, y0 + dy)] = info


func _label3d(text: String, pos: Vector3, size: int, color: Color, range_end: float) -> Label3D:
	var l := Label3D.new()
	l.text = text
	l.font = font
	l.font_size = size
	l.outline_size = int(size * 0.22)
	l.modulate = color
	l.outline_modulate = Color(0.04, 0.08, 0.14, 0.9)
	l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	l.fixed_size = true
	l.pixel_size = 0.0009
	l.no_depth_test = true
	l.position = pos
	if range_end > 0:
		l.visibility_range_end = range_end
	add_child(l)
	return l


func _spawn_all() -> void:
	# الموارد
	for t in RES_NAMES:
		var items: Array = data["resources"].filter(func(r): return r["t"] == t)
		_spawn_group(_mesh_from("res://assets/res_%s.glb" % t), items)
		for r in items:
			_reg(int(r["x"]), int(r["y"]), 1, {"kind": "res", "t": t, "l": r["l"],
					"x": int(r["x"]), "y": int(r["y"]), "pos": Vector3(r["x"], r["h"], r["y"])})
	# الوحوش
	for t in BEAST_NAMES:
		var items: Array = data["beasts"].filter(func(b): return b["t"] == t)
		_spawn_group(_mesh_from("res://assets/beast_%s.glb" % t), items)
		for b in items:
			_reg(int(b["x"]), int(b["y"]), 1, {"kind": "beast", "t": t, "l": b["l"],
					"x": int(b["x"]), "y": int(b["y"]), "pos": Vector3(b["x"], b["h"], b["y"])})
	# المدن
	for team in ["ally", "enemy", "neutral"]:
		var items: Array = data["cities"].filter(func(c): return c["team"] == team)
		_spawn_group(_mesh_from("res://assets/city_%s.glb" % team), items)
		var col: Color = {"ally": Color("8fd0ff"), "enemy": Color("ff9a8a"), "neutral": Color("f2f2f2")}[team]
		for c in items:
			var p := Vector3(c["x"], c["h"], c["y"])
			_reg(int(c["x"]) - 1, int(c["y"]) - 1, 2, {"kind": "city", "n": c["n"], "team": team,
					"l": c["l"], "x": int(c["x"]), "y": int(c["y"]), "pos": p})
			_label3d("%s  %d" % [c["n"], c["l"]], p + Vector3(0, 3.2, 0), 26, col, 75.0)
	# مدينتك
	var h: Dictionary = data["home"]
	h["x"] = Game.home.x + 0.5
	h["y"] = Game.home.y + 0.5
	h["l"] = Game.furnace_level()
	h["n"] = "مدينتي"
	home_pos = Vector3(h["x"], h["h"], h["y"])
	home_node = MeshInstance3D.new()
	home_node.mesh = _mesh_from("res://assets/city_me.glb")
	home_node.position = home_pos
	add_child(home_node)
	home_label = _label3d("%s  %d" % [h["n"], h["l"]], home_pos + Vector3(0, 3.4, 0), 32, Color("ffd36b"), 0)
	home_info = {"kind": "city", "n": h["n"], "team": "me", "l": h["l"], "x": Game.home.x, "y": Game.home.y, "pos": home_pos}
	_reg(Game.home.x - 1, Game.home.y - 1, 2, home_info)
	# المعالم (مبنية داخل frost_map.glb) — نضيف الأسماء ومناطق الضغط
	for L in data["landmarks"]:
		var p := Vector3(L["x"], L["h"], L["y"])
		var r: int = L["r"]
		var info := {"kind": "lm", "n": L["name"], "type": L["type"], "x": int(L["x"]), "y": int(L["y"]), "pos": p, "r": r}
		_reg(int(L["x"]) - r, int(L["y"]) - r, r * 2 + 1, info)
		var big: bool = L["type"] == "sun_city"
		var lh: float = {"sun_city": 26.0, "stronghold": 14.0, "fortress": 12.0}.get(L["type"], 8.0)
		_label3d(L["name"], p + Vector3(0, lh, 0), 44 if big else 34,
				Color("ffd36b") if big else Color("ffffff"), 0.0 if big else 420.0)
	# حلقة التحديد
	sel_ring = MeshInstance3D.new()
	var torus := TorusMesh.new()
	torus.inner_radius = 0.94
	torus.outer_radius = 1.0
	torus.rings = 48
	sel_ring.mesh = torus
	var rm := StandardMaterial3D.new()
	rm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	rm.albedo_color = Color("ffd36b")
	rm.no_depth_test = true
	sel_ring.material_override = rm
	sel_ring.visible = false
	add_child(sel_ring)
	# القوات
	troop_mesh = _mesh_from("res://assets/troop.glb")
	march_mat = StandardMaterial3D.new()
	march_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	march_mat.albedo_color = Color("7fd3ff")
	march_mat.no_depth_test = true
	march_mat.cull_mode = BaseMaterial3D.CULL_DISABLED


# ================================================================ الكاميرا والثلج
func _setup_camera() -> void:
	rig = StrategyCamera.new()
	rig.map_size = float(data["size"])
	add_child(rig)
	rig.ui_hit_test = _over_ui
	rig.tapped.connect(_on_tap)
	rig.view_changed.connect(_on_view)
	rig.set_view(home_pos, 34.0)

	snow = CPUParticles3D.new()
	snow.amount = 900
	snow.lifetime = 6.0
	snow.preprocess = 6.0
	snow.local_coords = true
	snow.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	snow.emission_box_extents = Vector3(60, 1, 60)
	snow.direction = Vector3(0.3, -1, 0.1)
	snow.spread = 12.0
	snow.gravity = Vector3(0, -2.0, 0)
	snow.initial_velocity_min = 3.0
	snow.initial_velocity_max = 6.0
	var q := SphereMesh.new()
	q.radius = 0.07
	q.height = 0.14
	q.radial_segments = 6
	q.rings = 3
	var sm := StandardMaterial3D.new()
	sm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	sm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	sm.albedo_color = Color(1, 1, 1, 0.85)
	q.material = sm
	snow.mesh = q
	rig.add_child(snow)


func _on_view(f: Vector3, d: float) -> void:
	if coord_label:
		coord_label.text = "X: %d   Y: %d" % [int(f.x), int(f.z)]
	if env:
		env.fog_density = (0.0022 if night else 0.0012) * clampf(60.0 / d, 0.25, 1.5)
	if snow:
		var s := clampf(d * 0.9, 40.0, 200.0)
		snow.emission_box_extents = Vector3(s, 1, s)
		snow.position = Vector3(0, clampf(d * 0.45, 18.0, 90.0), 0)
		snow.scale = Vector3.ONE * clampf(d / 60.0, 1.0, 3.0)


# ================================================================ الواجهة
func _style(bg: Color, radius: int = 14) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.set_corner_radius_all(radius)
	s.content_margin_left = 16
	s.content_margin_right = 16
	s.content_margin_top = 8
	s.content_margin_bottom = 8
	s.border_color = Color(1, 1, 1, 0.12)
	s.set_border_width_all(1)
	return s


func _button(text: String, cb: Callable, accent := false) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(0, 56)
	b.add_theme_stylebox_override("normal", _style(Color("e0a33a") if accent else Color(0.07, 0.12, 0.2, 0.86)))
	b.add_theme_stylebox_override("hover", _style(Color("f0b54a") if accent else Color(0.12, 0.2, 0.32, 0.92)))
	b.add_theme_stylebox_override("pressed", _style(Color("c78a25") if accent else Color(0.04, 0.08, 0.14, 0.95)))
	b.add_theme_color_override("font_color", Color("1a1206") if accent else Color.WHITE)
	b.add_theme_color_override("font_hover_color", Color("1a1206") if accent else Color.WHITE)
	b.add_theme_color_override("font_pressed_color", Color("1a1206") if accent else Color.WHITE)
	b.pressed.connect(cb)
	return b


func _panel(anchor_preset: int) -> PanelContainer:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", _style(Color(0.05, 0.1, 0.17, 0.82)))
	ui.add_child(p)
	p.set_anchors_and_offsets_preset(anchor_preset, Control.PRESET_MODE_MINSIZE, 14)
	ui_blockers.append(p)
	return p


func _setup_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	ui = Control.new()
	ui.set_anchors_preset(Control.PRESET_FULL_RECT)
	ui.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var th := Theme.new()
	th.default_font = font
	th.default_font_size = 20
	ui.theme = th
	layer.add_child(ui)

	# أعلى اليمين: اسم الخريطة + الإحداثيات
	var tr := _panel(Control.PRESET_TOP_RIGHT)
	tr.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	var v := VBoxContainer.new()
	tr.add_child(v)
	var title := Label.new()
	title.text = "خريطة الصقيع • 1200×1200"
	title.add_theme_color_override("font_color", Color("ffd36b"))
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	v.add_child(title)
	coord_label = Label.new()
	coord_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	v.add_child(coord_label)

	# أعلى اليسار: الموارد
	var tl := _panel(Control.PRESET_TOP_LEFT)
	var rv := VBoxContainer.new()
	tl.add_child(rv)
	res_label = Label.new()
	res_label.add_theme_font_size_override("font_size", 17)
	rv.add_child(res_label)
	march_label = Label.new()
	march_label.add_theme_font_size_override("font_size", 15)
	march_label.add_theme_color_override("font_color", Color("7fd3ff"))
	rv.add_child(march_label)
	_refresh_stock()

	# أسفل اليمين: أزرار التنقل
	var br := HBoxContainer.new()
	br.add_theme_constant_override("separation", 10)
	ui.add_child(br)
	br.add_child(_button("الليل/النهار", _toggle_night))
	br.add_child(_button("الخريطة كاملة", func(): rig.fly_to(Vector3(600, 0, 600), 300.0, 1.0)))
	br.add_child(_button("مدينة الشمس", func(): rig.fly_to(Vector3(600, 0, 600), 95.0)))
	br.add_child(_button("مدينتي", func(): rig.fly_to(home_pos, 34.0)))
	br.add_child(_button("دخول المدينة", _go_city, true))
	br.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT, Control.PRESET_MODE_MINSIZE, 14)
	br.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	br.grow_vertical = Control.GROW_DIRECTION_BEGIN
	ui_blockers.append(br)

	# لوحة المعلومات (أسفل اليسار)
	panel = PanelContainer.new()
	panel.add_theme_stylebox_override("panel", _style(Color(0.05, 0.1, 0.17, 0.9), 18))
	panel.custom_minimum_size = Vector2(360, 0)
	ui.add_child(panel)
	ui_blockers.append(panel)
	var pv := VBoxContainer.new()
	pv.add_theme_constant_override("separation", 6)
	panel.add_child(pv)
	p_title = Label.new()
	p_title.add_theme_font_size_override("font_size", 24)
	p_title.add_theme_color_override("font_color", Color("ffd36b"))
	p_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	pv.add_child(p_title)
	p_sub = Label.new()
	p_sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	p_sub.add_theme_color_override("font_color", Color("b9cbe0"))
	pv.add_child(p_sub)
	p_info = Label.new()
	p_info.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	p_info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	p_info.add_theme_font_size_override("font_size", 17)
	pv.add_child(p_info)
	var ph := HBoxContainer.new()
	ph.add_theme_constant_override("separation", 10)
	pv.add_child(ph)
	var close := _button("إغلاق", _close_panel)
	close.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	ph.add_child(close)
	p_action = _button("إرسال قوات", _on_action, true)
	p_action.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	ph.add_child(p_action)
	panel.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_LEFT, Control.PRESET_MODE_MINSIZE, 14)
	panel.grow_vertical = Control.GROW_DIRECTION_BEGIN
	panel.visible = false

	# رسالة عائمة
	toast = Label.new()
	toast.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	toast.add_theme_stylebox_override("normal", _style(Color(0.04, 0.08, 0.14, 0.85), 20))
	ui.add_child(toast)
	toast.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP, Control.PRESET_MODE_MINSIZE, 92)
	toast.grow_horizontal = Control.GROW_DIRECTION_BOTH
	toast.mouse_filter = Control.MOUSE_FILTER_IGNORE

	_on_view(rig.focus, rig.dist)


func _over_ui(p: Vector2) -> bool:
	for c in ui_blockers:
		if c.is_visible_in_tree() and c.get_global_rect().has_point(p):
			return true
	return false


func _refresh_stock() -> void:
	res_label.text = "طعام %s   خشب %s\nفحم %s   حديد %s" % [Defs.fmt(Game.res["food"]), Defs.fmt(Game.res["wood"]),
			Defs.fmt(Game.res["coal"]), Defs.fmt(Game.res["iron"])]
	march_label.text = "الفرق في مهمة: %d / %d" % [Game.marches.size(), Game.MAX_MARCHES]


func _fmt(n: int) -> String:
	if n >= 1000000:
		return "%.1fM" % (n / 1000000.0)
	if n >= 1000:
		return "%.1fK" % (n / 1000.0)
	return str(n)


func _toast(t: String) -> void:
	toast.text = t
	toast.modulate.a = 1.0
	toast.visible = true
	toast_time = 3.0


func _go_city() -> void:
	Game.save_game()
	get_tree().change_scene_to_file("res://city.tscn")


func _toggle_night() -> void:
	night = not night
	_apply_daytime()
	_on_view(rig.focus, rig.dist)


# ================================================================ الاختيار
func _on_tap(world: Vector3, _sp: Vector2) -> void:
	var tile := Vector2i(floori(world.x), floori(world.z))
	if tile.x < 0 or tile.y < 0 or tile.x >= 1200 or tile.y >= 1200:
		return
	var info: Dictionary = lookup.get(tile, {})
	if info.is_empty():
		info = {"kind": "empty", "x": tile.x, "y": tile.y, "pos": Vector3(tile.x + 0.5, world.y, tile.y + 0.5)}
	_select(info)


func _select(info: Dictionary) -> void:
	selected = info
	var pos: Vector3 = info["pos"]
	var rr := 1.0
	match info["kind"]:
		"res":
			p_title.text = "%s  Lv.%d" % [RES_NAMES[info["t"]], info["l"]]
			p_sub.text = "مورد قابل للجمع"
			p_info.text = "الكمية المتوقعة: %s" % _fmt(RES_GAIN[info["t"]] * info["l"])
			p_action.text = "جمع"
			rr = 0.9
		"beast":
			p_title.text = "%s  Lv.%d" % [BEAST_NAMES[info["t"]], info["l"]]
			p_sub.text = "وحش بري"
			p_info.text = "القوة المقدّرة: %s" % _fmt(info["l"] * 3500)
			p_action.text = "هجوم"
			rr = 1.0
		"city":
			p_title.text = "%s  Lv.%d" % [info["n"], info["l"]]
			p_sub.text = TEAM_NAMES[info["team"]]
			p_info.text = "مدينة لاعب"
			p_action.text = {"me": "دخول المدينة", "ally": "تعزيز", "enemy": "هجوم", "neutral": "استطلاع"}[info["team"]]
			rr = 1.6
		"lm":
			p_title.text = info["n"]
			p_sub.text = LM_TYPES[info["type"]]
			p_info.text = "منطقة قابلة للاحتلال في حرب التحالفات"
			p_action.text = "احتلال"
			rr = float(info["r"]) + 0.5
		_:
			p_title.text = "أرض ثلجية"
			p_sub.text = "خانة فارغة"
			p_info.text = "يمكنك نقل مدينتك إلى هنا"
			p_action.text = "نقل المدينة"
			rr = 1.2
	p_sub.text += "   •   X: %d  Y: %d" % [info["x"], info["y"]]
	panel.visible = true
	sel_ring.visible = true
	sel_ring.position = pos + Vector3(0, 0.15, 0)
	sel_rr = rr


func _close_panel() -> void:
	panel.visible = false
	sel_ring.visible = false
	selected = {}


func _on_action() -> void:
	if selected.is_empty():
		return
	var info := selected
	if info["kind"] == "empty":
		_move_home(info)
	elif info["kind"] == "city" and info["team"] == "me":
		_go_city()
	elif info["kind"] == "city" and info["team"] != "neutral" and info["team"] != "enemy":
		_toast("ميزة التعزيز ستتوفر مع نظام الجيش في المرحلة القادمة")
	elif Game.start_march(info):
		var m: Dictionary = Game.marches.back()
		_toast("انطلقت الفرقة — الوصول خلال %s" % Defs.fmt_time(float(m["arrive"]) - Game.now()))
	_close_panel()


func _move_home(info: Dictionary) -> void:
	for dx in 2:
		for dy in 2:
			lookup.erase(Vector2i(home_info["x"] - 1 + dx, home_info["y"] - 1 + dy))
	var p: Vector3 = info["pos"]
	home_pos = Vector3(info["x"] + 0.5, p.y, info["y"] + 0.5)
	home_info["x"] = info["x"]
	home_info["y"] = info["y"]
	home_info["pos"] = home_pos
	_reg(info["x"] - 1, info["y"] - 1, 2, home_info)
	home_node.position = home_pos
	home_label.position = home_pos + Vector3(0, 3.4, 0)
	Game.home = Vector2i(info["x"], info["y"])
	Game.save_game()
	_toast("تم نقل مدينتك إلى X: %d  Y: %d" % [info["x"], info["y"]])


# ================================================================ المسيرات (مصدرها Game.marches)
var march_vis := {}   # start time -> {troop, line, im}


func _march_pos(m: Dictionary, t: float) -> Array:
	## [الموقع، الوجهة الحالية للرسم]
	var a := Vector3(m["fx"], 0, m["fy"])
	var b := Vector3(m["tx"], 0, m["ty"])
	if t < float(m["arrive"]):
		var k := inverse_lerp(float(m["start"]), float(m["arrive"]), t)
		return [a.lerp(b, k), b]
	if t < float(m["leave"]):
		return [b, b]
	var k2 := inverse_lerp(float(m["leave"]), float(m["back"]), t)
	return [b.lerp(a, clampf(k2, 0.0, 1.0)), a]


func _sync_marches() -> void:
	var alive := {}
	for m in Game.marches:
		var key := str(m["start"])
		alive[key] = true
		if not march_vis.has(key):
			var troop := MeshInstance3D.new()
			troop.mesh = troop_mesh
			add_child(troop)
			var line := MeshInstance3D.new()
			var im := ImmediateMesh.new()
			line.mesh = im
			line.material_override = march_mat
			line.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			add_child(line)
			march_vis[key] = {"troop": troop, "line": line, "im": im}
	for key in march_vis.keys():
		if not alive.has(key):
			(march_vis[key]["troop"] as Node).queue_free()
			(march_vis[key]["line"] as Node).queue_free()
			march_vis.erase(key)


func _draw_dashes(im: ImmediateMesh, a: Vector3, b: Vector3, phase: float) -> void:
	im.clear_surfaces()
	var d := b - a
	d.y = 0
	var length := d.length()
	if length < 0.6:
		return
	var dir := d / length
	var side := Vector3(-dir.z, 0, dir.x) * 0.22
	var y := 0.6
	im.surface_begin(Mesh.PRIMITIVE_TRIANGLES)
	var s := fmod(phase, 1.6)
	if s < 0:
		s += 1.6
	while s < length:
		var e := minf(s + 0.9, length)
		var p0 := Vector3(a.x, y, a.z) + dir * s
		var p1 := Vector3(a.x, y, a.z) + dir * e
		im.surface_add_vertex(p0 - side)
		im.surface_add_vertex(p0 + side)
		im.surface_add_vertex(p1 + side)
		im.surface_add_vertex(p0 - side)
		im.surface_add_vertex(p1 + side)
		im.surface_add_vertex(p1 - side)
		s += 1.6
	im.surface_end()


func _process(delta: float) -> void:
	if toast_time > 0:
		toast_time -= delta
		toast.modulate.a = clampf(toast_time / 0.6, 0.0, 1.0)
		if toast_time <= 0:
			toast.visible = false
	if sel_ring.visible:
		var k := (1.0 + sin(Time.get_ticks_msec() / 180.0) * 0.06) * sel_rr
		sel_ring.scale = Vector3(k, 1, k)
	_sync_marches()
	var t := Game.now()
	var t_now := Time.get_ticks_msec() / 1000.0
	for m in Game.marches:
		var key := str(m["start"])
		if not march_vis.has(key):
			continue
		var v: Dictionary = march_vis[key]
		var pr := _march_pos(m, t)
		var p: Vector3 = pr[0]
		var to: Vector3 = pr[1]
		var troop: MeshInstance3D = v["troop"]
		troop.position = Vector3(p.x, 0.35, p.z)
		var dir := to - p
		if dir.length() > 0.05:
			troop.rotation.y = atan2(-dir.z, dir.x)
		_draw_dashes(v["im"], p, to, -t_now * 2.0)
