extends Node
## حالة اللعبة الكاملة (Autoload باسم Game)
## الاقتصاد، والحرارة، والسكان، وطابور البناء، والمسيرات، والمهام، والحفظ، والتقدم أثناء الغياب.

const Defs := preload("res://scripts/defs.gd")
const SAVE_PATH := "user://frost_save.json"
const SAVE_VERSION := 1
const BUILDERS := 2
const MAX_MARCHES := 2
const OFFLINE_CAP := 8.0 * 3600.0
const FREE_SPEEDUP := 180.0

signal changed
signal toast(text: String)
signal building_done(plot_id: String)
signal march_done(m: Dictionary)
signal storm_changed(active: bool)

var res := {}
var gems := 0
var plots := {}          # plot_id -> level
var stored := {}         # plot_id -> float (موارد جاهزة للجمع داخل المبنى)
var queue: Array = []    # [{plot, level, start, end}]
var pop := 0
var sick := 0.0
var furnace_mode := 1    # 0 مطفأ • 1 عادي • 2 مضاعف
var stats := {}
var task_index := 0
var last_daily := ""
var home := Vector2i(790, 842)
var marches: Array = []
var storm_start := 0.0
var storm_end := 0.0
var quality_high := true
var offline_report: Dictionary = {}
var daily_ready := false

# قيم محسوبة لكل لحظة (للواجهة)
var inside_temp := 0.0
var outside_temp := 0.0
var hungry := false
var cold_level := 0      # 0 دافئ • 1 بارد • 2 متجمد
var workers := {}        # plot_id -> عدد العمال
var _grow_acc := 0.0
var _tick_acc := 0.0
var _save_acc := 0.0
var _rng := RandomNumberGenerator.new()


func now() -> float:
	return Time.get_unix_time_from_system()


func _ready() -> void:
	_rng.randomize()
	if not load_game():
		new_game()
	_check_daily()
	recompute()


# ================================================================ لعبة جديدة / حفظ / تحميل
func new_game() -> void:
	res = {"food": 2500, "wood": 1800, "coal": 600, "iron": 0}
	gems = 200
	plots = {}
	for id in Defs.PLOTS:
		plots[id] = 0
	plots["furnace"] = 1
	stored = {}
	queue = []
	pop = 4
	sick = 0.0
	furnace_mode = 1
	stats = {"collected": {"food": 0, "wood": 0, "coal": 0, "iron": 0}, "marches": 0, "built": 0}
	task_index = 0
	last_daily = ""
	home = Vector2i(790, 842)
	marches = []
	_schedule_storm(now() + 420.0)
	save_game()


func _schedule_storm(after: float) -> void:
	storm_start = after + _rng.randf_range(0.0, 360.0)
	storm_end = storm_start + _rng.randf_range(100.0, 160.0)


func save_game() -> void:
	var d := {
		"v": SAVE_VERSION, "time": now(), "res": res, "gems": gems, "plots": plots, "stored": stored,
		"queue": queue, "pop": pop, "sick": sick, "furnace_mode": furnace_mode, "stats": stats,
		"task_index": task_index, "last_daily": last_daily, "home": [home.x, home.y],
		"marches": marches, "storm": [storm_start, storm_end], "quality_high": quality_high,
	}
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(d))


func load_game() -> bool:
	if not FileAccess.file_exists(SAVE_PATH):
		return false
	var d = JSON.parse_string(FileAccess.get_file_as_string(SAVE_PATH))
	if typeof(d) != TYPE_DICTIONARY or int(d.get("v", 0)) != SAVE_VERSION:
		return false
	res = d["res"]
	for r in Defs.RES:
		res[r] = float(res.get(r, 0))
	gems = int(d["gems"])
	plots = {}
	for id in Defs.PLOTS:
		plots[id] = int(d["plots"].get(id, 0))
	stored = d["stored"]
	queue = d["queue"]
	for q in queue:
		q["level"] = int(q["level"])
	pop = int(d["pop"])
	sick = float(d["sick"])
	furnace_mode = int(d["furnace_mode"])
	stats = d["stats"]
	task_index = int(d["task_index"])
	last_daily = str(d["last_daily"])
	home = Vector2i(int(d["home"][0]), int(d["home"][1]))
	marches = d["marches"]
	storm_start = float(d["storm"][0])
	storm_end = float(d["storm"][1])
	quality_high = bool(d.get("quality_high", true))
	# التقدم أثناء الغياب
	var t0 := float(d["time"])
	var elapsed := clampf(now() - t0, 0.0, OFFLINE_CAP)
	if elapsed > 60.0:
		var before := {}
		for id in stored:
			before[id] = float(stored[id])
		var built_before := queue.size()
		var pop_before := pop
		var t := t0
		var step := 30.0
		while t < t0 + elapsed:
			var dt := minf(step, t0 + elapsed - t)
			t += dt
			_simulate(dt, t)
		var gained := {"food": 0.0, "wood": 0.0, "coal": 0.0, "iron": 0.0}
		for id in stored:
			var tp: String = Defs.PLOTS[id]["type"]
			if Defs.BUILDINGS[tp].has("prod"):
				gained[Defs.BUILDINGS[tp]["prod"]] += float(stored[id]) - float(before.get(id, 0.0))
		offline_report = {"elapsed": elapsed, "gained": gained, "built": built_before - queue.size(),
				"pop": pop - pop_before}
	return true


func reset_game() -> void:
	DirAccess.remove_absolute(ProjectSettings.globalize_path(SAVE_PATH))
	new_game()
	recompute()
	changed.emit()


func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_CLOSE_REQUEST \
			or what == NOTIFICATION_APPLICATION_FOCUS_OUT:
		save_game()


# ================================================================ الحساب
func level(id: String) -> int:
	return int(plots.get(id, 0))


func furnace_level() -> int:
	return level("furnace")


func max_level_of(type: String) -> int:
	var m := 0
	for id in Defs.PLOTS:
		if Defs.PLOTS[id]["type"] == type:
			m = maxi(m, level(id))
	return m


func count_of(type: String) -> int:
	var c := 0
	for id in Defs.PLOTS:
		if Defs.PLOTS[id]["type"] == type and level(id) > 0:
			c += 1
	return c


func pop_capacity() -> int:
	var c := 4
	for id in Defs.PLOTS:
		if Defs.PLOTS[id]["type"] == "shelter":
			c += Defs.shelter_capacity(level(id))
	return c


func healthy() -> int:
	return maxi(pop - int(floor(sick)), 0)


func storage_hours() -> float:
	return 2.0 + 0.5 * max_level_of("storehouse")


func storage_cap(id: String) -> float:
	var tp: String = Defs.PLOTS[id]["type"]
	return Defs.prod_rate(tp, level(id)) * storage_hours()


func efficiency(id: String) -> float:
	var tp: String = Defs.PLOTS[id]["type"]
	var need := Defs.workers_needed(tp, level(id))
	if need <= 0:
		return 1.0
	return float(workers.get(id, 0)) / need


func current_rate(id: String) -> float:
	## الإنتاج الفعلي في الساعة
	var tp: String = Defs.PLOTS[id]["type"]
	var r := Defs.prod_rate(tp, level(id)) * efficiency(id)
	if cold_level == 2:
		r *= 0.5
	if _under_construction(id):
		r = 0.0
	return r


func coal_use() -> float:
	if furnace_mode == 0:
		return 0.0
	return Defs.furnace_coal(furnace_level()) * (2.0 if furnace_mode == 2 else 1.0)


func food_use() -> float:
	return pop * 6.0


func net_rate(r: String) -> float:
	var n := 0.0
	for id in Defs.PLOTS:
		var tp: String = Defs.PLOTS[id]["type"]
		if Defs.BUILDINGS[tp].get("prod", "") == r:
			n += current_rate(id)
	if r == "coal":
		n -= coal_use()
	if r == "food":
		n -= food_use()
	return n


func storm_active(t: float = -1.0) -> bool:
	if t < 0:
		t = now()
	return t >= storm_start and t < storm_end


func storm_soon() -> float:
	## ثوانٍ حتى العاصفة إن كانت قريبة (أقل من 90 ثانية)، وإلا -1
	var s := storm_start - now()
	return s if s > 0 and s < 90 else -1.0


func _outside(t: float) -> float:
	var o := -16.0 + 3.0 * sin(t * TAU / 600.0)
	if storm_active(t):
		o -= 22.0
	return o


func recompute(t: float = -1.0) -> void:
	if t < 0:
		t = now()
	outside_temp = _outside(t)
	var heat := 0.0
	if furnace_mode > 0 and res["coal"] > 0.0:
		heat = Defs.furnace_heat(furnace_level()) + (10.0 if furnace_mode == 2 else 0.0)
	inside_temp = outside_temp + heat
	cold_level = 0 if inside_temp >= -5.0 else (1 if inside_temp >= -15.0 else 2)
	hungry = res["food"] <= 0.0
	# توزيع العمال: الأولوية للطعام ثم الفحم ثم الخشب ثم الحديد ثم المستوصف
	workers = {}
	var avail := healthy()
	for tp in ["hunter", "coal_mine", "sawmill", "iron_mine", "infirmary"]:
		for id in Defs.PLOTS:
			if Defs.PLOTS[id]["type"] != tp or level(id) <= 0:
				continue
			var need := Defs.workers_needed(tp, level(id))
			var w := mini(need, avail)
			workers[id] = w
			avail -= w


func _under_construction(id: String) -> bool:
	for q in queue:
		if q["plot"] == id:
			return true
	return false


func _simulate(dt: float, t: float) -> void:
	recompute(t)
	var h := dt / 3600.0
	# إنتاج المباني (يُخزّن داخلها حتى تجمعه)
	for id in Defs.PLOTS:
		var tp: String = Defs.PLOTS[id]["type"]
		if not Defs.BUILDINGS[tp].has("prod") or level(id) <= 0:
			continue
		var s := float(stored.get(id, 0.0)) + current_rate(id) * h
		stored[id] = minf(s, storage_cap(id))
	# الاستهلاك
	res["food"] = maxf(res["food"] - food_use() * h, 0.0)
	res["coal"] = maxf(res["coal"] - coal_use() * h, 0.0)
	# المرض والشفاء
	var mins := dt / 60.0
	var rate: float = [0.0, 0.02, 0.06][cold_level] + (0.03 if hungry else 0.0)
	sick = minf(sick + healthy() * rate * mins, float(pop))
	if cold_level < 2:
		var heal := 0.25
		for id in Defs.PLOTS:
			if Defs.PLOTS[id]["type"] == "infirmary" and level(id) > 0:
				heal += 0.6 * level(id) * efficiency(id)
		sick = maxf(sick - heal * mins, 0.0)
	# وصول ناجين جدد
	if pop < pop_capacity() and cold_level < 2 and not hungry:
		_grow_acc += dt
		while _grow_acc >= 15.0 and pop < pop_capacity():
			_grow_acc -= 15.0
			pop += 1
	else:
		_grow_acc = 0.0
	# طابور البناء
	for i in range(queue.size() - 1, -1, -1):
		var q: Dictionary = queue[i]
		if float(q["end"]) <= t:
			_finish(i)
	# العاصفة
	if t >= storm_end:
		_schedule_storm(t + 480.0)
	# المسيرات
	for i in range(marches.size() - 1, -1, -1):
		var m: Dictionary = marches[i]
		if float(m["back"]) <= t:
			_march_reward(m)
			marches.remove_at(i)


func _finish(i: int) -> void:
	var q: Dictionary = queue[i]
	var id: String = q["plot"]
	plots[id] = int(q["level"])
	queue.remove_at(i)
	stats["built"] = int(stats.get("built", 0)) + 1
	building_done.emit(id)
	var tp: String = Defs.PLOTS[id]["type"]
	toast.emit("اكتمل: %s — المستوى %d" % [Defs.BUILDINGS[tp]["name"], plots[id]])


func _process(delta: float) -> void:
	_tick_acc += delta
	_save_acc += delta
	if _tick_acc >= 0.5:
		var was_storm := storm_active(now() - _tick_acc)
		_simulate(_tick_acc, now())
		_tick_acc = 0.0
		if storm_active() != was_storm:
			storm_changed.emit(storm_active())
			toast.emit("عاصفة ثلجية تضرب المدينة — شغّل الفرن بالوضع المضاعف" if storm_active() else "انتهت العاصفة الثلجية")
		changed.emit()
	if _save_acc >= 15.0:
		_save_acc = 0.0
		save_game()


# ================================================================ الأفعال
func collect(id: String) -> float:
	var v := floorf(float(stored.get(id, 0.0)))
	if v < 1.0:
		return 0.0
	var tp: String = Defs.PLOTS[id]["type"]
	var r: String = Defs.BUILDINGS[tp]["prod"]
	res[r] += v
	stored[id] = float(stored[id]) - v
	stats["collected"][r] = float(stats["collected"].get(r, 0)) + v
	changed.emit()
	return v


func collect_all() -> Dictionary:
	var out := {}
	for id in stored:
		var tp: String = Defs.PLOTS[id]["type"]
		var r: String = Defs.BUILDINGS[tp]["prod"]
		var v := collect(id)
		if v > 0:
			out[r] = float(out.get(r, 0.0)) + v
	return out


func queue_entry(id: String) -> Dictionary:
	for q in queue:
		if q["plot"] == id:
			return q
	return {}


func check_upgrade(id: String) -> Dictionary:
	## {ok, reasons[], cost, time, next}
	var tp: String = Defs.PLOTS[id]["type"]
	var nxt := level(id) + 1
	var reasons: Array[String] = []
	var c := Defs.cost(tp, nxt)
	if nxt > int(Defs.BUILDINGS[tp]["max"]):
		reasons.append("وصل المبنى لأعلى مستوى")
	if furnace_level() < int(Defs.PLOTS[id]["unlock"]):
		reasons.append("يتطلب الفرن المستوى %d" % Defs.PLOTS[id]["unlock"])
	if tp != "furnace" and nxt > furnace_level():
		reasons.append("لا يتجاوز مستوى الفرن (%d)" % furnace_level())
	if tp == "furnace":
		if nxt >= 3 and max_level_of("shelter") < nxt - 1:
			reasons.append("يتطلب مأوى بالمستوى %d" % (nxt - 1))
		if nxt >= 4 and max_level_of("coal_mine") < nxt - 2:
			reasons.append("يتطلب منجم فحم بالمستوى %d" % (nxt - 2))
		if nxt >= 6 and max_level_of("storehouse") < nxt - 2:
			reasons.append("يتطلب مخزنًا بالمستوى %d" % (nxt - 2))
	if not queue_entry(id).is_empty():
		reasons.append("قيد البناء")
	var missing := {}
	for r in c:
		if res[r] < c[r]:
			missing[r] = c[r] - res[r]
	var builders_free := queue.size() < BUILDERS
	return {"ok": reasons.is_empty() and missing.is_empty() and builders_free, "reasons": reasons,
			"missing": missing, "cost": c, "time": Defs.build_time(tp, nxt), "next": nxt,
			"builders_free": builders_free}


func start_upgrade(id: String, instant: bool = false) -> bool:
	var chk := check_upgrade(id)
	if not chk["reasons"].is_empty() or not chk["missing"].is_empty():
		return false
	if not instant and not chk["builders_free"]:
		toast.emit("كل البنائين مشغولون")
		return false
	if instant:
		var g := gems_for_time(chk["time"])
		if gems < g:
			toast.emit("الجواهر غير كافية")
			return false
		gems -= g
	for r in chk["cost"]:
		res[r] -= chk["cost"][r]
	var t := now()
	queue.append({"plot": id, "level": chk["next"], "start": t, "end": t + (0.0 if instant else chk["time"])})
	if instant:
		_finish(queue.size() - 1)
	recompute()
	changed.emit()
	save_game()
	return true


func gems_for_time(sec: float) -> int:
	if sec <= FREE_SPEEDUP:
		return 0
	return int(ceil(sec / 60.0))


func speedup(id: String) -> bool:
	var q := queue_entry(id)
	if q.is_empty():
		return false
	var remain := float(q["end"]) - now()
	var g := gems_for_time(remain)
	if gems < g:
		toast.emit("الجواهر غير كافية")
		return false
	gems -= g
	q["end"] = now()
	_simulate(0.0, now())
	changed.emit()
	save_game()
	return true


func cancel(id: String) -> void:
	for i in queue.size():
		if queue[i]["plot"] == id:
			var tp: String = Defs.PLOTS[id]["type"]
			var c := Defs.cost(tp, int(queue[i]["level"]))
			for r in c:
				res[r] += c[r]
			queue.remove_at(i)
			toast.emit("تم إلغاء البناء واسترجاع الموارد")
			changed.emit()
			return


func set_furnace_mode(m: int) -> void:
	furnace_mode = m
	recompute()
	changed.emit()


# ================================================================ المهام والمكافآت
func current_task() -> Dictionary:
	if task_index >= Defs.TASKS.size():
		return {}
	return Defs.TASKS[task_index]


func task_progress(tk: Dictionary) -> Vector2:
	match tk["type"]:
		"count":
			return Vector2(count_of(tk["b"]), tk["n"])
		"level":
			return Vector2(max_level_of(tk["b"]), tk["n"])
		"collect":
			return Vector2(float(stats["collected"].get(tk["r"], 0)), tk["n"])
		"pop":
			return Vector2(pop, tk["n"])
		"temp":
			return Vector2(1 if inside_temp >= float(tk["n"]) else 0, 1)
		"march":
			return Vector2(int(stats.get("marches", 0)), tk["n"])
	return Vector2(0, 1)


func task_done(tk: Dictionary) -> bool:
	var p := task_progress(tk)
	return p.x >= p.y


func claim_task() -> bool:
	var tk := current_task()
	if tk.is_empty() or not task_done(tk):
		return false
	give(tk["reward"])
	task_index += 1
	toast.emit("تم استلام مكافأة المهمة")
	save_game()
	return true


func give(reward: Dictionary) -> void:
	for k in reward:
		if k == "gems":
			gems += int(reward[k])
		else:
			res[k] = float(res.get(k, 0.0)) + float(reward[k])
	changed.emit()


func _today() -> String:
	var d := Time.get_date_dict_from_system()
	return "%04d-%02d-%02d" % [d["year"], d["month"], d["day"]]


func _check_daily() -> void:
	daily_ready = last_daily != _today()


func daily_reward() -> Dictionary:
	var f := maxi(furnace_level(), 1)
	return {"food": 1500 * f, "wood": 1200 * f, "coal": 500 * f, "gems": 50}


func claim_daily() -> void:
	if not daily_ready:
		return
	give(daily_reward())
	last_daily = _today()
	daily_ready = false
	save_game()


# ================================================================ المسيرات (الخريطة الكبرى)
func march_speed() -> float:
	return 7.0   # خانة في الثانية


func start_march(target: Dictionary) -> bool:
	if marches.size() >= MAX_MARCHES:
		toast.emit("كل الفرق في مهمة — انتظر عودة إحداها")
		return false
	var from := Vector2(home.x + 0.5, home.y + 0.5)
	var to := Vector2(float(target["x"]) + 0.5, float(target["y"]) + 0.5)
	var travel := clampf(from.distance_to(to) / march_speed(), 4.0, 180.0)
	var work := 0.0
	match target["kind"]:
		"res":
			work = 12.0 + 2.0 * float(target["l"])
		"beast":
			work = 3.0
		"lm", "city":
			work = 5.0
	var t := now()
	var m := {"kind": target["kind"], "t": target.get("t", ""), "l": int(target.get("l", 1)),
			"name": str(target.get("n", "")), "fx": from.x, "fy": from.y, "tx": to.x, "ty": to.y,
			"start": t, "arrive": t + travel, "leave": t + travel + work, "back": t + travel * 2 + work}
	marches.append(m)
	stats["marches"] = int(stats.get("marches", 0)) + 1
	changed.emit()
	save_game()
	return true


func _march_reward(m: Dictionary) -> void:
	var reward := {}
	var lv := int(m["l"])
	match m["kind"]:
		"res":
			var amount := {"food": 4500, "wood": 3200, "coal": 1800, "iron": 600}
			reward[m["t"]] = amount[m["t"]] * lv
		"beast":
			reward = {"food": 2000 * lv, "wood": 800 * lv, "gems": 2 + lv / 3}
		_:
			reward = {"wood": 500}
	give(reward)
	var parts: Array[String] = []
	for k in reward:
		parts.append("%s %s" % [Defs.fmt(reward[k]), Defs.RES_NAMES[k]])
	toast.emit("عادت الفرقة: " + "، ".join(parts))
	march_done.emit(m)
