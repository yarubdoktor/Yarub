extends RefCounted
## أدوات واجهة مشتركة (أنماط، أزرار، أيقونات)

const FONT_PATH := "res://fonts/NotoKufiArabic.ttf"
const GOLD := Color("ffd36b")
const PANEL_BG := Color(0.05, 0.1, 0.17, 0.88)
const TEXT_DIM := Color("b9cbe0")
const RED := Color("ff7b6b")
const GREEN := Color("8fe3a1")

static var _icons := {}


static func icon(name: String) -> Texture2D:
	if not _icons.has(name):
		_icons[name] = load("res://assets/ui/%s.png" % name)
	return _icons[name]


static func style(bg: Color, radius: int = 14, border: Color = Color(1, 1, 1, 0.12), pad: int = 12) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.set_corner_radius_all(radius)
	s.content_margin_left = pad + 4
	s.content_margin_right = pad + 4
	s.content_margin_top = pad - 4
	s.content_margin_bottom = pad - 4
	s.border_color = border
	s.set_border_width_all(1)
	return s


static func theme() -> Theme:
	var th := Theme.new()
	th.default_font = load(FONT_PATH)
	th.default_font_size = 20
	return th


static func button(text: String, cb: Callable, kind: String = "dark", h: int = 54) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(0, h)
	b.focus_mode = Control.FOCUS_NONE
	var cols := {"dark": [Color(0.08, 0.14, 0.23, 0.92), Color.WHITE],
			"gold": [Color("e0a33a"), Color("1a1206")],
			"blue": [Color("2f7fd0"), Color.WHITE],
			"red": [Color("b9443a"), Color.WHITE],
			"green": [Color("3f9a5a"), Color.WHITE]}
	var c: Array = cols.get(kind, cols["dark"])
	var bg: Color = c[0]
	b.add_theme_stylebox_override("normal", style(bg))
	b.add_theme_stylebox_override("hover", style(bg.lightened(0.12)))
	b.add_theme_stylebox_override("pressed", style(bg.darkened(0.2)))
	b.add_theme_stylebox_override("disabled", style(Color(0.2, 0.22, 0.26, 0.85)))
	for k in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color"]:
		b.add_theme_color_override(k, c[1])
	b.add_theme_color_override("font_disabled_color", Color(0.65, 0.68, 0.72))
	b.pressed.connect(cb)
	return b


static func label(text: String, size: int = 20, color: Color = Color.WHITE, align := HORIZONTAL_ALIGNMENT_RIGHT) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.horizontal_alignment = align
	return l


static func icon_rect(name: String, size: int = 30) -> TextureRect:
	var t := TextureRect.new()
	t.texture = icon(name)
	t.custom_minimum_size = Vector2(size, size)
	t.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	t.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	t.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return t


## شريحة: أيقونة + نص (تُرجع [الحاوية، النص])
static func chip(icon_name: String, size: int = 30, font: int = 19) -> Array:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", style(Color(0.04, 0.08, 0.14, 0.78), 22, Color(1, 1, 1, 0.1), 8))
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 6)
	p.add_child(h)
	h.add_child(icon_rect(icon_name, size))
	var l := label("", font, Color.WHITE, HORIZONTAL_ALIGNMENT_LEFT)
	h.add_child(l)
	return [p, l]


static func panel(bg: Color = PANEL_BG, radius: int = 18) -> PanelContainer:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", style(bg, radius, Color(1, 1, 1, 0.14), 14))
	return p


static func progress_bar(color: Color = Color("4fb4ff")) -> ProgressBar:
	var pb := ProgressBar.new()
	pb.show_percentage = false
	pb.custom_minimum_size = Vector2(0, 10)
	var bg := StyleBoxFlat.new()
	bg.bg_color = Color(1, 1, 1, 0.12)
	bg.set_corner_radius_all(5)
	var fg := StyleBoxFlat.new()
	fg.bg_color = color
	fg.set_corner_radius_all(5)
	pb.add_theme_stylebox_override("background", bg)
	pb.add_theme_stylebox_override("fill", fg)
	pb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return pb
