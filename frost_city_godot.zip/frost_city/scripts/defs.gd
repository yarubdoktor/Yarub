extends RefCounted
## تعريفات اللعبة: المباني، والمواقع، والتكاليف، والمهام.
## عدّل الأرقام هنا لموازنة اللعبة دون لمس بقية الكود.

const RES := ["food", "wood", "coal", "iron"]
const RES_NAMES := {"food": "طعام", "wood": "خشب", "coal": "فحم", "iron": "حديد", "gems": "جواهر"}

const CITY_CENTER := Vector3(60, 0, 60)

## type: الإنتاج (prod) أو غيره. max: أعلى مستوى. cost: تكلفة المستوى الأول. from: المستوى الذي تبدأ فيه تكلفة هذا المورد
const BUILDINGS := {
	"furnace": {"name": "الفرن المركزي", "max": 30, "time": 20.0,
		"cost": {"wood": 260, "coal": 90, "iron": 60}, "from": {"wood": 2, "coal": 3, "iron": 6},
		"desc": "قلب المدينة. يدفئ السكان ويحدد أعلى مستوى لبقية المباني."},
	"shelter": {"name": "مأوى", "max": 30, "time": 8.0,
		"cost": {"wood": 50, "coal": 20, "iron": 20}, "from": {"wood": 1, "coal": 4, "iron": 8},
		"desc": "يؤوي الناجين. كل مستوى يزيد عدد السكان الممكن."},
	"hunter": {"name": "كوخ الصيادين", "max": 30, "time": 9.0, "prod": "food", "rate": 720.0,
		"cost": {"wood": 60, "coal": 25, "iron": 20}, "from": {"wood": 1, "coal": 3, "iron": 7},
		"desc": "ينتج الطعام. يحتاج عمالًا من السكان الأصحاء."},
	"sawmill": {"name": "المنشرة", "max": 30, "time": 9.0, "prod": "wood", "rate": 600.0,
		"cost": {"wood": 45, "coal": 25, "iron": 20}, "from": {"wood": 1, "coal": 3, "iron": 7},
		"desc": "تقطع الخشب اللازم للبناء."},
	"coal_mine": {"name": "منجم الفحم", "max": 30, "time": 10.0, "prod": "coal", "rate": 330.0,
		"cost": {"wood": 120, "coal": 30, "iron": 25}, "from": {"wood": 1, "coal": 4, "iron": 7},
		"desc": "يستخرج الفحم وقود الفرن. بدونه تتجمد المدينة."},
	"iron_mine": {"name": "منجم الحديد", "max": 30, "time": 14.0, "prod": "iron", "rate": 140.0,
		"cost": {"wood": 420, "coal": 160, "iron": 40}, "from": {"wood": 1, "coal": 1, "iron": 6},
		"desc": "يستخرج الحديد للمباني المتقدمة."},
	"storehouse": {"name": "المخزن", "max": 30, "time": 12.0,
		"cost": {"wood": 220, "coal": 60, "iron": 40}, "from": {"wood": 1, "coal": 2, "iron": 6},
		"desc": "يزيد سعة تخزين مباني الإنتاج، فتتحمل غيابك مدة أطول."},
	"infirmary": {"name": "المستوصف", "max": 30, "time": 12.0,
		"cost": {"wood": 300, "coal": 90, "iron": 40}, "from": {"wood": 1, "coal": 1, "iron": 6},
		"desc": "يعالج المرضى المصابين بالبرد ويعيدهم للعمل."},
}

## مواقع البناء الثابتة: المعرّف ← النوع، والزاوية بالدرجات، ونصف القطر، ومستوى الفرن المطلوب
const PLOTS := {
	"furnace": {"type": "furnace", "a": 0.0, "r": 0.0, "unlock": 0},
	"sh1": {"type": "shelter", "a": 0.0, "r": 17.0, "unlock": 1},
	"sh2": {"type": "shelter", "a": 60.0, "r": 17.0, "unlock": 1},
	"sh3": {"type": "shelter", "a": 120.0, "r": 17.0, "unlock": 2},
	"sh4": {"type": "shelter", "a": 180.0, "r": 17.0, "unlock": 3},
	"sh5": {"type": "shelter", "a": 240.0, "r": 17.0, "unlock": 4},
	"sh6": {"type": "shelter", "a": 300.0, "r": 17.0, "unlock": 5},
	"sh7": {"type": "shelter", "a": 60.0, "r": 41.0, "unlock": 7},
	"sh8": {"type": "shelter", "a": 120.0, "r": 41.0, "unlock": 9},
	"sh9": {"type": "shelter", "a": 240.0, "r": 41.0, "unlock": 11},
	"sh10": {"type": "shelter", "a": 300.0, "r": 41.0, "unlock": 13},
	"hu1": {"type": "hunter", "a": 15.0, "r": 30.5, "unlock": 1},
	"sa1": {"type": "sawmill", "a": 45.0, "r": 30.5, "unlock": 1},
	"co1": {"type": "coal_mine", "a": 75.0, "r": 30.5, "unlock": 2},
	"hu2": {"type": "hunter", "a": 105.0, "r": 30.5, "unlock": 3},
	"sa2": {"type": "sawmill", "a": 135.0, "r": 30.5, "unlock": 3},
	"ir1": {"type": "iron_mine", "a": 165.0, "r": 30.5, "unlock": 4},
	"st1": {"type": "storehouse", "a": 195.0, "r": 30.5, "unlock": 2},
	"co2": {"type": "coal_mine", "a": 225.0, "r": 30.5, "unlock": 5},
	"in1": {"type": "infirmary", "a": 255.0, "r": 30.5, "unlock": 3},
	"hu3": {"type": "hunter", "a": 285.0, "r": 30.5, "unlock": 7},
	"sa3": {"type": "sawmill", "a": 315.0, "r": 30.5, "unlock": 8},
	"ir2": {"type": "iron_mine", "a": 345.0, "r": 30.5, "unlock": 10},
}

## مهام الفصل بالترتيب. الأنواع: level (أعلى مستوى لنوع) • count (عدد المباني المبنية) • pop • temp • collect • march
const TASKS := [
	{"text": "ابنِ أول مأوى للناجين", "type": "count", "b": "shelter", "n": 1, "reward": {"wood": 300, "gems": 20}},
	{"text": "ابنِ كوخ الصيادين", "type": "count", "b": "hunter", "n": 1, "reward": {"food": 600, "wood": 200}},
	{"text": "ابنِ المنشرة", "type": "count", "b": "sawmill", "n": 1, "reward": {"wood": 400}},
	{"text": "اجمع 500 خشب من المباني", "type": "collect", "r": "wood", "n": 500, "reward": {"wood": 500, "gems": 20}},
	{"text": "طوّر الفرن إلى المستوى 2", "type": "level", "b": "furnace", "n": 2, "reward": {"coal": 400, "gems": 30}},
	{"text": "ابنِ منجم الفحم", "type": "count", "b": "coal_mine", "n": 1, "reward": {"coal": 500}},
	{"text": "ابنِ المخزن", "type": "count", "b": "storehouse", "n": 1, "reward": {"wood": 800, "food": 800}},
	{"text": "ابنِ مأويين", "type": "count", "b": "shelter", "n": 2, "reward": {"wood": 600, "gems": 20}},
	{"text": "طوّر الفرن إلى المستوى 3", "type": "level", "b": "furnace", "n": 3, "reward": {"coal": 800, "iron": 200, "gems": 40}},
	{"text": "ابنِ المستوصف", "type": "count", "b": "infirmary", "n": 1, "reward": {"food": 1500, "wood": 800}},
	{"text": "اجعل حرارة المدينة فوق 0°", "type": "temp", "n": 0, "reward": {"coal": 1000, "gems": 30}},
	{"text": "وصّل عدد السكان إلى 20", "type": "pop", "n": 20, "reward": {"food": 2500, "gems": 30}},
	{"text": "أرسل فرقة جمع من الخريطة", "type": "march", "n": 1, "reward": {"wood": 1500, "gems": 30}},
	{"text": "طوّر كوخ الصيادين إلى 4", "type": "level", "b": "hunter", "n": 4, "reward": {"food": 3000}},
	{"text": "طوّر الفرن إلى المستوى 4", "type": "level", "b": "furnace", "n": 4, "reward": {"iron": 500, "gems": 50}},
	{"text": "ابنِ منجم الحديد", "type": "count", "b": "iron_mine", "n": 1, "reward": {"iron": 600, "coal": 1200}},
	{"text": "اجمع 5000 طعام", "type": "collect", "r": "food", "n": 5000, "reward": {"wood": 3000, "gems": 40}},
	{"text": "طوّر الفرن إلى المستوى 5", "type": "level", "b": "furnace", "n": 5, "reward": {"iron": 1000, "gems": 60}},
	{"text": "ابنِ 5 مآوٍ", "type": "count", "b": "shelter", "n": 5, "reward": {"wood": 5000, "food": 5000}},
	{"text": "وصّل عدد السكان إلى 60", "type": "pop", "n": 60, "reward": {"coal": 5000, "gems": 80}},
	{"text": "طوّر الفرن إلى المستوى 7", "type": "level", "b": "furnace", "n": 7, "reward": {"iron": 3000, "gems": 100}},
	{"text": "اجمع 10000 فحم", "type": "collect", "r": "coal", "n": 10000, "reward": {"iron": 2500, "gems": 60}},
	{"text": "طوّر الفرن إلى المستوى 10", "type": "level", "b": "furnace", "n": 10, "reward": {"gems": 300}},
]


static func cost(type: String, level: int) -> Dictionary:
	## تكلفة الوصول إلى المستوى level
	var b: Dictionary = BUILDINGS[type]
	var out := {}
	var g := 1.58
	for r in b["cost"]:
		var from: int = b["from"][r]
		if level >= from:
			var v: float = b["cost"][r] * pow(g, level - from)
			out[r] = int(round(v / 10.0) * 10)
	return out


static func build_time(type: String, level: int) -> float:
	return float(BUILDINGS[type]["time"]) * pow(1.42, level - 1)


static func prod_rate(type: String, level: int) -> float:
	## الإنتاج في الساعة بكامل العمال
	if level <= 0 or not BUILDINGS[type].has("prod"):
		return 0.0
	return float(BUILDINGS[type]["rate"]) * level * (1.0 + 0.09 * level)


static func workers_needed(type: String, level: int) -> int:
	if level <= 0:
		return 0
	if BUILDINGS[type].has("prod"):
		return 1 + level
	if type == "infirmary":
		return 1 + level / 2
	return 0


static func shelter_capacity(level: int) -> int:
	return 0 if level <= 0 else 3 + 2 * level


static func furnace_heat(level: int) -> float:
	return 8.0 + 1.6 * level


static func furnace_coal(level: int) -> float:
	## استهلاك الفحم في الساعة (الوضع العادي)
	return 24.0 + 16.0 * level


static func plot_pos(id: String) -> Vector3:
	var p: Dictionary = PLOTS[id]
	var a := deg_to_rad(float(p["a"]))
	return CITY_CENTER + Vector3(cos(a), 0, sin(a)) * float(p["r"])


static func fmt(n: float) -> String:
	var a := absf(n)
	if a >= 1000000.0:
		return "%.1fM" % (n / 1000000.0)
	if a >= 10000.0:
		return "%dK" % int(n / 1000.0)
	if a >= 1000.0:
		return "%.1fK" % (n / 1000.0)
	return str(int(n))


static func fmt_time(sec: float) -> String:
	var s := int(ceil(maxf(sec, 0.0)))
	var d := s / 86400
	var h := (s % 86400) / 3600
	var m := (s % 3600) / 60
	var ss := s % 60
	if d > 0:
		return "%dي %02d:%02d:%02d" % [d, h, m, ss]
	if h > 0:
		return "%02d:%02d:%02d" % [h, m, ss]
	return "%02d:%02d" % [m, ss]
