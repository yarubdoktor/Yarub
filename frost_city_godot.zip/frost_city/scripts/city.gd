extends Node3D
## مشهد المدينة: البناء والتطوير، والفرن، والسكان، والجمع، والمهام

const Defs := preload("res://scripts/defs.gd")
const UI := preload("res://scripts/ui_kit.gd")
const StrategyCamera := preload("res://scripts/strategy_camera.gd")

var rig: Node3D
var env: Environment
var sky_mat: ProceduralSkyMaterial
var sun: DirectionalLight3D
var fire_light: OmniLight3D
var snow: CPUParticles3D
var smoke: CPUParticles3D
var font: Font
var scenes := {}
var plot_nodes := {}
var citizens: Array = []
var citizen_meshes: Array = []

# الواجهة
var ui: Control
var blockers: Array[Control] = []
var res_chips := {}
var gem_label: Label
var temp_label: Label
var temp_chip: PanelContainer
var pop_label: Label
var sick_label: Label
var builder_rows: Array = []
var storm_label: Label
var frost_overlay: ColorRect
var task_title: Label
var task_prog: Label
var task_btn: Button
var toast_box: VBoxContainer
var modal_layer: Control

# لوحة المبنى
var sel := ""
var bp: PanelContainer
var bp_title: Label
var bp_desc: Label
var bp_stats: Label
var bp_store_row: HBoxContainer
var bp_store: Label
var bp_cost_row: HBoxContainer
var bp_cost_chips := {}
var bp_time: Label
var bp_reasons: Label
var bp_progress: ProgressBar
var bp_main: Button
var bp_instant: Button
var bp_speed: Button
var bp_cancel: Button
var bp_mode_row: HBoxContainer
var bp_mode_btns: Array = []
var sel_ring: MeshInstance3D


func _ready() -> void:
	font = load(UI.FONT_PATH)
	_setup_env()
	var ground: Node3D = _inst("res://assets/city/ground.glb")
	add_child(ground)
	for id in Defs.PLOTS:
		_make_plot(id)
	_setup_fx()
	_setup_camera()
	_setup_ui()
	_setup_citizens()
	Game.changed.connect(_on_changed)
	Game.toast.connect(_toast)
	Game.building_done.connect(_on_building_done)
	_on_changed()
	_apply_quality()
	call_deferred("_welcome")


func _welcome() -> void:
	var rep: Dictionary = Game.offline_report
	if not rep.is_empty():
		var lines: Array[String] = ["غبت %s، وخلال غيابك:" % Defs.fmt_time(rep["elapsed"])]
		for r in rep["gained"]:
			if rep["gained"][r] >= 1:
				lines.append("• تجمّع %s %s في المباني" % [Defs.fmt(rep["gained"][r]), Defs.RES_NAMES[r]])
		if rep["built"] > 0:
			lines.append("• اكتمل %d من أعمال البناء" % rep["built"])
		if rep["pop"] > 0:
			lines.append("• وصل %d ناجين جدد" % rep["pop"])
		Game.offline_report = {}
		_modal("مرحبًا بعودتك أيها القائد", "\n".join(lines), [["جمع الكل", _collect_all, "gold"]], "gift")
	elif Game.daily_ready:
		_show_daily()
	elif Game.stats.get("built", 0) == 0 and Game.task_index == 0:
		_modal("مدينة الصقيع", "العالم تجمّد، ونجا معك قلة من الناس.\nأبقِ الفرن مشتعلًا، وابنِ المآوي، واجمع الموارد قبل العاصفة القادمة.\n\nاضغط على أي موقع بناء للبدء.",
				[["لنبدأ", func(): pass, "gold"]], "fire")


# ================================================================ البيئة
func _setup_env() -> void:
	env = Environment.new()
	sky_mat = ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color("8fb4d4")
	sky_mat.sky_horizon_color = Color("e2ebf2")
	sky_mat.ground_horizon_color = Color("e2ebf2")
	sky_mat.ground_bottom_color = Color("c9d6e0")
	var sky := Sky.new()
	sky.sky_material = sky_mat
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = 0.34
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.tonemap_white = 1.6
	env.fog_enabled = false
	env.fog_light_color = Color("dde7ef")
	env.fog_density = 0.0
	env.glow_enabled = true
	env.glow_intensity = 0.4
	env.glow_hdr_threshold = 1.5
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)
	sun = DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-50, -30, 0)
	sun.light_energy = 0.85
	sun.light_color = Color("fff1dc")
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 140.0
	add_child(sun)


func _apply_quality() -> void:
	sun.shadow_enabled = Game.quality_high
	env.glow_enabled = Game.quality_high
	snow.amount = 700 if Game.quality_high else 250
	smoke.amount = 60 if Game.quality_high else 25


func _fix(n: Node) -> void:
	if n is MeshInstance3D and n.mesh:
		for s in n.mesh.get_surface_count():
			var mat := n.mesh.surface_get_material(s) as BaseMaterial3D
			if mat:
				mat.vertex_color_use_as_albedo = true
				if mat.resource_name == "Snow" or mat.resource_name == "Matte":
					mat.metallic_specular = 0.25
	for c in n.get_children():
		_fix(c)


func _inst(path: String) -> Node3D:
	if not scenes.has(path):
		scenes[path] = load(path)
	var n: Node3D = scenes[path].instantiate()
	_fix(n)
	return n


func _setup_fx() -> void:
	fire_light = OmniLight3D.new()
	fire_light.position = Defs.CITY_CENTER + Vector3(0, 7, 0)
	fire_light.light_color = Color("ff9a4a")
	fire_light.omni_range = 34.0
	fire_light.omni_attenuation = 1.2
	add_child(fire_light)

	smoke = CPUParticles3D.new()
	smoke.amount = 60
	smoke.lifetime = 5.0
	smoke.preprocess = 4.0
	smoke.direction = Vector3(0.25, 1, 0.1)
	smoke.spread = 14.0
	smoke.gravity = Vector3(0.6, 0.6, 0)
	smoke.initial_velocity_min = 1.6
	smoke.initial_velocity_max = 2.6
	smoke.scale_amount_min = 0.8
	smoke.scale_amount_max = 1.6
	var curve := Curve.new()
	curve.add_point(Vector2(0, 0.4))
	curve.add_point(Vector2(1, 2.2))
	smoke.scale_amount_curve = curve
	var grad := Gradient.new()
	grad.set_color(0, Color(0.35, 0.36, 0.4, 0.75))
	grad.set_color(1, Color(0.8, 0.82, 0.86, 0.0))
	smoke.color_ramp = grad
	var sm := SphereMesh.new()
	sm.radius = 0.6
	sm.height = 1.2
	sm.radial_segments = 8
	sm.rings = 4
	var smat := StandardMaterial3D.new()
	smat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	smat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	smat.vertex_color_use_as_albedo = true
	sm.material = smat
	smoke.mesh = sm
	add_child(smoke)

	sel_ring = MeshInstance3D.new()
	var torus := TorusMesh.new()
	torus.inner_radius = 0.92
	torus.outer_radius = 1.0
	torus.rings = 48
	sel_ring.mesh = torus
	var rm := StandardMaterial3D.new()
	rm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	rm.albedo_color = UI.GOLD
	sel_ring.material_override = rm
	sel_ring.visible = false
	add_child(sel_ring)


func _setup_camera() -> void:
	rig = StrategyCamera.new()
	rig.map_size = 120.0
	rig.edge_margin = 24.0
	rig.min_dist = 12.0
	rig.max_dist = 85.0
	rig.near_pitch_deg = 40.0
	rig.far_pitch_deg = 60.0
	rig.ground_y = 0.0
	add_child(rig)
	rig.ui_hit_test = _over_ui
	rig.tapped.connect(_on_tap)
	rig.set_view(Defs.CITY_CENTER + Vector3(0, 0, 6), 52.0)

	snow = CPUParticles3D.new()
	snow.amount = 700
	snow.lifetime = 5.0
	snow.preprocess = 5.0
	snow.local_coords = true
	snow.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	snow.emission_box_extents = Vector3(45, 1, 45)
	snow.position = Vector3(0, 26, 0)
	snow.direction = Vector3(0.3, -1, 0.1)
	snow.spread = 12.0
	snow.gravity = Vector3(0, -2.0, 0)
	snow.initial_velocity_min = 3.0
	snow.initial_velocity_max = 6.0
	var q := SphereMesh.new()
	q.radius = 0.06
	q.height = 0.12
	q.radial_segments = 6
	q.rings = 3
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.albedo_color = Color(1, 1, 1, 0.9)
	q.material = m
	snow.mesh = q
	rig.add_child(snow)


# ================================================================ مواقع البناء
func _tier(id: String, lv: int) -> int:
	if lv < 5:
		return 0
	return 1 if lv < 15 else 2


func _make_plot(id: String) -> void:
	var root := Node3D.new()
	root.position = Defs.plot_pos(id)
	var dir := Defs.CITY_CENTER - root.position
	if dir.length() > 0.1:
		root.rotation.y = atan2(dir.x, dir.z)
	add_child(root)
	var tp: String = Defs.PLOTS[id]["type"]
	var top := 9.0 if tp == "furnace" else 3.6
	var badge := _label3d("", Vector3(0, top, 0), 30, Color.WHITE)
	root.add_child(badge)
	var timer := _label3d("", Vector3(0, top + 1.6, 0), 28, Color("7fd3ff"))
	root.add_child(timer)
	var bubble := Sprite3D.new()
	bubble.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	bubble.fixed_size = true
	bubble.pixel_size = 0.0006
	bubble.no_depth_test = true
	bubble.position = Vector3(0, top + 1.2, 0)
	bubble.visible = false
	if Defs.BUILDINGS[tp].has("prod"):
		bubble.texture = UI.icon(Defs.BUILDINGS[tp]["prod"])
	root.add_child(bubble)
	plot_nodes[id] = {"root": root, "model": null, "key": "", "badge": badge, "timer": timer,
			"bubble": bubble, "scaffold": null, "top": top}
	_refresh_plot(id)


func _label3d(text: String, pos: Vector3, size: int, color: Color) -> Label3D:
	var l := Label3D.new()
	l.text = text
	l.font = font
	l.font_size = size
	l.outline_size = 14
	l.modulate = color
	l.outline_modulate = Color(0.04, 0.08, 0.14, 0.95)
	l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	l.fixed_size = true
	l.pixel_size = 0.0009
	l.no_depth_test = true
	l.position = pos
	return l


func _refresh_plot(id: String) -> void:
	var pn: Dictionary = plot_nodes[id]
	var tp: String = Defs.PLOTS[id]["type"]
	var lv := Game.level(id)
	var q := Game.queue_entry(id)
	var locked := Game.furnace_level() < int(Defs.PLOTS[id]["unlock"])
	var key := ""
	if lv > 0:
		key = "res://assets/city/%s_t%d.glb" % [tp, _tier(id, lv)]
	elif q.is_empty():
		key = "res://assets/city/plot.glb"
	if key != pn["key"]:
		if pn["model"]:
			pn["model"].queue_free()
		pn["model"] = null
		if key != "":
			pn["model"] = _inst(key)
			pn["root"].add_child(pn["model"])
		pn["key"] = key
	var building: bool = not q.is_empty()
	if building and pn["scaffold"] == null:
		pn["scaffold"] = _inst("res://assets/city/scaffold.glb")
		if tp == "furnace":
			pn["scaffold"].scale = Vector3(2.4, 2.4, 2.4)
		pn["root"].add_child(pn["scaffold"])
	elif not building and pn["scaffold"] != null:
		pn["scaffold"].queue_free()
		pn["scaffold"] = null
	var badge: Label3D = pn["badge"]
	if lv > 0:
		badge.text = "%s  %d" % [Defs.BUILDINGS[tp]["name"], lv] if tp == "furnace" else "Lv.%d" % lv
		badge.modulate = UI.GOLD if tp == "furnace" else Color.WHITE
		badge.font_size = 34 if tp == "furnace" else 26
	elif locked:
		badge.text = "مقفل • الفرن %d" % Defs.PLOTS[id]["unlock"]
		badge.modulate = Color(0.75, 0.78, 0.82)
		badge.font_size = 22
	elif not building:
		badge.text = "+ " + str(Defs.BUILDINGS[tp]["name"])
		badge.modulate = Color("9fe0ff")
		badge.font_size = 24
	else:
		badge.text = ""
	if pn["model"] and lv == 0:
		pn["model"].visible = true
		(pn["model"] as Node3D).scale = Vector3.ONE * (0.8 if locked else 1.0)


func _update_plot_dynamic(id: String) -> void:
	var pn: Dictionary = plot_nodes[id]
	var q := Game.queue_entry(id)
	var timer: Label3D = pn["timer"]
	if q.is_empty():
		timer.text = ""
	else:
		timer.text = Defs.fmt_time(float(q["end"]) - Game.now())
	var bubble: Sprite3D = pn["bubble"]
	if bubble.texture:
		var s := float(Game.stored.get(id, 0.0))
		var cap := Game.storage_cap(id)
		bubble.visible = s >= 1.0 and s >= cap * 0.04 and q.is_empty()
		if bubble.visible:
			var t := Time.get_ticks_msec() / 1000.0
			bubble.position.y = pn["top"] + 1.4 + sin(t * 3.0 + id.hash() % 7) * 0.25
			bubble.modulate = Color(1, 0.85, 0.6) if s >= cap * 0.98 else Color.WHITE


# ================================================================ السكان
func _setup_citizens() -> void:
	citizen_meshes = [_inst("res://assets/city/citizen_a.glb"), _inst("res://assets/city/citizen_b.glb")]


func _sync_citizens() -> void:
	var want := mini(Game.healthy(), 36)
	while citizens.size() < want:
		var n: Node3D = (citizen_meshes[citizens.size() % 2] as Node3D).duplicate()
		n.scale = Vector3.ONE * 1.4
		add_child(n)
		var p := _random_spot()
		n.position = p
		citizens.append({"node": n, "to": _random_spot(), "wait": randf() * 2.0, "speed": randf_range(1.6, 2.4)})
	while citizens.size() > want:
		var c: Dictionary = citizens.pop_back()
		(c["node"] as Node).queue_free()


func _random_spot() -> Vector3:
	var built: Array = []
	for id in Defs.PLOTS:
		if Game.level(id) > 0 and id != "furnace":
			built.append(id)
	if built.is_empty() or randf() < 0.35:
		var a := randf() * TAU
		return Defs.CITY_CENTER + Vector3(cos(a), 0, sin(a)) * randf_range(8.0, 11.0)
	var id: String = built[randi() % built.size()]
	var p := Defs.plot_pos(id)
	var toward := (Defs.CITY_CENTER - p).normalized()
	return p + toward * 2.6 + Vector3(randf_range(-1, 1), 0, randf_range(-1, 1))


func _update_citizens(delta: float) -> void:
	for c in citizens:
		var n: Node3D = c["node"]
		if c["wait"] > 0:
			c["wait"] -= delta
			continue
		var to: Vector3 = c["to"]
		var d := to - n.position
		d.y = 0
		if d.length() < 0.3:
			c["to"] = _random_spot()
			c["wait"] = randf_range(0.5, 3.0)
			continue
		var step := d.normalized() * float(c["speed"]) * delta
		# الابتعاد عن الفرن
		var np := n.position + step
		var fc := np - Defs.CITY_CENTER
		fc.y = 0
		if fc.length() < 7.0:
			np = Defs.CITY_CENTER + fc.normalized() * 7.0
		n.position = np
		n.rotation.y = atan2(d.x, d.z)
		n.position.y = absf(sin(Time.get_ticks_msec() / 110.0 + float(c["speed"]) * 9.0)) * 0.08


# ================================================================ الواجهة
func _setup_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	ui = Control.new()
	ui.set_anchors_preset(Control.PRESET_FULL_RECT)
	ui.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.theme = UI.theme()
	layer.add_child(ui)

	frost_overlay = ColorRect.new()
	frost_overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
	frost_overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var sh := Shader.new()
	sh.code = """shader_type canvas_item;
uniform float amount = 0.0;
void fragment() {
	vec2 uv = UV - 0.5;
	float d = length(uv * vec2(1.0, 0.8)) * 1.55;
	float n = fract(sin(dot(floor(UV * 90.0), vec2(12.9898, 78.233))) * 43758.5453);
	float v = smoothstep(0.5, 1.05, d + n * 0.08) * amount;
	COLOR = vec4(0.82, 0.92, 1.0, v);
}"""
	var smat := ShaderMaterial.new()
	smat.shader = sh
	smat.set_shader_parameter("amount", 0.0)
	frost_overlay.material = smat
	ui.add_child(frost_overlay)

	# الشريط العلوي: الموارد
	var top := HBoxContainer.new()
	top.add_theme_constant_override("separation", 8)
	ui.add_child(top)
	top.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP, Control.PRESET_MODE_MINSIZE, 10)
	top.grow_horizontal = Control.GROW_DIRECTION_BOTH
	for r in ["food", "wood", "coal", "iron", "gems"]:
		var c := UI.chip("gem" if r == "gems" else r)
		(c[0] as Control).custom_minimum_size = Vector2(118, 0)
		top.add_child(c[0])
		if r == "gems":
			gem_label = c[1]
		else:
			res_chips[r] = c[1]
		var rr: String = r
		(c[0] as Control).gui_input.connect(func(e): _chip_input(e, rr))
		(c[0] as Control).mouse_filter = Control.MOUSE_FILTER_STOP
	blockers.append(top)

	# العمود الأيمن: الحرارة والسكان والبناؤون
	var right := VBoxContainer.new()
	right.add_theme_constant_override("separation", 8)
	ui.add_child(right)
	right.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT, Control.PRESET_MODE_MINSIZE, 12)
	right.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	right.position.y = 70
	var tc := UI.chip("temp", 34, 22)
	temp_chip = tc[0]
	temp_label = tc[1]
	temp_chip.mouse_filter = Control.MOUSE_FILTER_STOP
	temp_chip.gui_input.connect(func(e): _chip_input(e, "temp"))
	right.add_child(temp_chip)
	var prow := HBoxContainer.new()
	prow.add_theme_constant_override("separation", 6)
	right.add_child(prow)
	var pc := UI.chip("pop", 30)
	pop_label = pc[1]
	prow.add_child(pc[0])
	var sc := UI.chip("sick", 26)
	sick_label = sc[1]
	prow.add_child(sc[0])
	(pc[0] as Control).mouse_filter = Control.MOUSE_FILTER_STOP
	(pc[0] as Control).gui_input.connect(func(e): _chip_input(e, "pop"))
	for i in Game.BUILDERS:
		var bpnl := UI.panel(Color(0.04, 0.08, 0.14, 0.78), 14)
		bpnl.custom_minimum_size = Vector2(230, 0)
		var v := VBoxContainer.new()
		bpnl.add_child(v)
		var h := HBoxContainer.new()
		v.add_child(h)
		h.add_child(UI.icon_rect("hammer", 24))
		var l := UI.label("", 16, Color.WHITE, HORIZONTAL_ALIGNMENT_LEFT)
		l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		h.add_child(l)
		var pb := UI.progress_bar(UI.GOLD)
		pb.custom_minimum_size = Vector2(0, 6)
		v.add_child(pb)
		bpnl.mouse_filter = Control.MOUSE_FILTER_STOP
		var idx := i
		bpnl.gui_input.connect(func(e): _builder_input(e, idx))
		right.add_child(bpnl)
		builder_rows.append({"label": l, "bar": pb})
	blockers.append(right)

	storm_label = UI.label("", 20, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER)
	storm_label.add_theme_stylebox_override("normal", UI.style(Color(0.55, 0.15, 0.15, 0.85), 16))
	ui.add_child(storm_label)
	storm_label.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP, Control.PRESET_MODE_MINSIZE, 72)
	storm_label.grow_horizontal = Control.GROW_DIRECTION_BOTH
	storm_label.visible = false

	# أسفل اليمين: الأزرار
	var br := HBoxContainer.new()
	br.add_theme_constant_override("separation", 8)
	ui.add_child(br)
	br.add_child(_icon_button("gear", "الإعدادات", _show_settings))
	br.add_child(_icon_button("task", "المهام", _show_tasks))
	br.add_child(_icon_button("gift", "الجمع", _collect_all))
	br.add_child(_icon_button("map", "الخريطة", _go_map))
	br.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT, Control.PRESET_MODE_MINSIZE, 12)
	br.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	br.grow_vertical = Control.GROW_DIRECTION_BEGIN
	blockers.append(br)

	# أسفل اليسار: المهمة الحالية
	var tp := UI.panel(Color(0.05, 0.1, 0.17, 0.86), 16)
	tp.custom_minimum_size = Vector2(380, 0)
	ui.add_child(tp)
	var th := HBoxContainer.new()
	th.add_theme_constant_override("separation", 10)
	tp.add_child(th)
	task_btn = UI.button("", _task_action, "gold", 48)
	task_btn.custom_minimum_size = Vector2(96, 48)
	th.add_child(task_btn)
	var tv := VBoxContainer.new()
	tv.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	tv.add_theme_constant_override("separation", 0)
	th.add_child(tv)
	task_title = UI.label("", 18)
	task_title.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	tv.add_child(task_title)
	task_prog = UI.label("", 15, UI.TEXT_DIM)
	tv.add_child(task_prog)
	th.add_child(UI.icon_rect("task", 40))
	tp.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_LEFT, Control.PRESET_MODE_MINSIZE, 12)
	tp.grow_vertical = Control.GROW_DIRECTION_BEGIN
	blockers.append(tp)

	_build_building_panel()

	toast_box = VBoxContainer.new()
	toast_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	toast_box.add_theme_constant_override("separation", 6)
	ui.add_child(toast_box)
	toast_box.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP, Control.PRESET_MODE_MINSIZE, 120)
	toast_box.grow_horizontal = Control.GROW_DIRECTION_BOTH

	modal_layer = Control.new()
	modal_layer.set_anchors_preset(Control.PRESET_FULL_RECT)
	modal_layer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.add_child(modal_layer)


func _icon_button(icon_name: String, text: String, cb: Callable) -> Button:
	var b := UI.button(text, cb, "dark", 64)
	b.icon = UI.icon(icon_name)
	b.expand_icon = true
	b.add_theme_constant_override("icon_max_width", 34)
	b.add_theme_font_size_override("font_size", 17)
	b.custom_minimum_size = Vector2(108, 64)
	return b


func _over_ui(p: Vector2) -> bool:
	if modal_layer.get_child_count() > 0:
		return true
	for c in blockers:
		if c.is_visible_in_tree() and c.get_global_rect().has_point(p):
			return true
	return false


func _chip_input(e: InputEvent, what: String) -> void:
	if not (e is InputEventMouseButton and e.pressed):
		return
	match what:
		"temp":
			var st: String = ["دافئة", "باردة — يمرض السكان ببطء", "متجمدة — يمرض السكان بسرعة والإنتاج نصفه"][Game.cold_level]
			_toast("الخارج %d° • الداخل %d° • المدينة %s" % [int(Game.outside_temp), int(Game.inside_temp), st])
		"pop":
			_toast("السكان %d من %d • الأصحاء %d • المرضى %d • يأكل كل ساكن 6 طعام في الساعة" % [Game.pop, Game.pop_capacity(), Game.healthy(), int(Game.sick)])
		"gems":
			_toast("الجواهر تُستخدم لتسريع البناء. تحصل عليها من المهام والمكافأة اليومية")
		_:
			var n := Game.net_rate(what)
			_toast("%s: %s • الصافي %s%s في الساعة" % [Defs.RES_NAMES[what], Defs.fmt(Game.res[what]), "+" if n >= 0 else "", Defs.fmt(n)])


func _builder_input(e: InputEvent, idx: int) -> void:
	if not (e is InputEventMouseButton and e.pressed):
		return
	if idx < Game.queue.size():
		var id: String = Game.queue[idx]["plot"]
		_select(id)
	else:
		_toast("البنّاء متاح — اضغط على مبنى لتطويره")


# ---------------------------------------------------------------- لوحة المبنى
func _build_building_panel() -> void:
	bp = UI.panel(Color(0.05, 0.1, 0.17, 0.94), 20)
	bp.custom_minimum_size = Vector2(560, 0)
	ui.add_child(bp)
	blockers.append(bp)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 6)
	bp.add_child(v)
	var head := HBoxContainer.new()
	v.add_child(head)
	var close := UI.button("إغلاق", _close_panel, "dark", 44)
	close.custom_minimum_size = Vector2(90, 44)
	head.add_child(close)
	bp_title = UI.label("", 26, UI.GOLD)
	bp_title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(bp_title)
	bp_desc = UI.label("", 16, UI.TEXT_DIM)
	bp_desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	v.add_child(bp_desc)
	bp_stats = UI.label("", 18)
	bp_stats.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	v.add_child(bp_stats)
	bp_store_row = HBoxContainer.new()
	v.add_child(bp_store_row)
	bp_store_row.add_child(UI.button("جمع", func(): _collect(sel), "green", 44))
	bp_store = UI.label("", 18, Color.WHITE)
	bp_store.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bp_store_row.add_child(bp_store)
	bp_mode_row = HBoxContainer.new()
	bp_mode_row.add_theme_constant_override("separation", 6)
	v.add_child(bp_mode_row)
	for m in [[2, "مضاعف"], [1, "عادي"], [0, "إطفاء"]]:
		var mode: int = m[0]
		var b := UI.button(m[1], func(): Game.set_furnace_mode(mode), "dark", 44)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.toggle_mode = true
		bp_mode_row.add_child(b)
		bp_mode_btns.append([mode, b])
	bp_progress = UI.progress_bar(Color("4fb4ff"))
	v.add_child(bp_progress)
	bp_cost_row = HBoxContainer.new()
	bp_cost_row.add_theme_constant_override("separation", 6)
	bp_cost_row.alignment = BoxContainer.ALIGNMENT_END
	v.add_child(bp_cost_row)
	var tc := UI.chip("time", 24, 17)
	bp_time = tc[1]
	bp_cost_row.add_child(tc[0])
	for r in ["iron", "coal", "wood"]:
		var c := UI.chip(r, 24, 17)
		bp_cost_row.add_child(c[0])
		bp_cost_chips[r] = c
	bp_reasons = UI.label("", 16, UI.RED)
	bp_reasons.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	v.add_child(bp_reasons)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	v.add_child(row)
	bp_cancel = UI.button("إلغاء", func(): Game.cancel(sel); _refresh_all(), "red", 54)
	bp_speed = UI.button("", func(): Game.speedup(sel), "blue", 54)
	bp_instant = UI.button("", func(): _do_upgrade(true), "blue", 54)
	bp_main = UI.button("", func(): _do_upgrade(false), "gold", 54)
	for b in [bp_cancel, bp_speed, bp_instant, bp_main]:
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(b)
	bp.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM, Control.PRESET_MODE_MINSIZE, 12)
	bp.grow_horizontal = Control.GROW_DIRECTION_BOTH
	bp.grow_vertical = Control.GROW_DIRECTION_BEGIN
	bp.visible = false


func _select(id: String) -> void:
	sel = id
	bp.visible = true
	var p := Defs.plot_pos(id)
	sel_ring.visible = true
	sel_ring.position = p + Vector3(0, 0.12, 0)
	var r := 7.5 if id == "furnace" else 2.6
	sel_ring.scale = Vector3(r, 1, r)
	_update_panel()
	# تحريك الكاميرا ليظهر المبنى فوق اللوحة
	rig.fly_to(p + Vector3(0, 0, 6), clampf(rig.dist, 26.0, 45.0), 0.5)


func _close_panel() -> void:
	sel = ""
	bp.visible = false
	sel_ring.visible = false


func _update_panel() -> void:
	if sel == "" or not bp.visible:
		return
	var id := sel
	var tp: String = Defs.PLOTS[id]["type"]
	var b: Dictionary = Defs.BUILDINGS[tp]
	var lv := Game.level(id)
	var q := Game.queue_entry(id)
	var chk := Game.check_upgrade(id)
	var nxt: int = chk["next"]
	bp_title.text = "%s — المستوى %d" % [b["name"], lv] if lv > 0 else "بناء: %s" % b["name"]
	bp_desc.text = b["desc"]
	var st: Array[String] = []
	match tp:
		"furnace":
			st.append("الحرارة: +%d° ← +%d°   •   الحرارة الآن داخل المدينة %d°" % [int(Defs.furnace_heat(lv)), int(Defs.furnace_heat(nxt)), int(Game.inside_temp)])
			st.append("استهلاك الفحم: %s في الساعة   •   المخزون %s" % [Defs.fmt(Game.coal_use()), Defs.fmt(Game.res["coal"])])
			if Game.res["coal"] > 0 and Game.coal_use() > 0:
				st.append("يكفي الفحم لمدة %s" % Defs.fmt_time(Game.res["coal"] / Game.coal_use() * 3600.0))
		"shelter":
			st.append("يؤوي: %d ← %d ساكن   •   السكان %d / %d" % [Defs.shelter_capacity(lv), Defs.shelter_capacity(nxt), Game.pop, Game.pop_capacity()])
		"storehouse":
			st.append("مدة تخزين مباني الإنتاج: %s ← %s ساعة" % [str(2.0 + 0.5 * lv), str(2.0 + 0.5 * nxt)])
		"infirmary":
			st.append("العلاج: %.1f ← %.1f مريض في الدقيقة   •   المرضى %d" % [0.6 * lv, 0.6 * nxt, int(Game.sick)])
			st.append("العمال: %d / %d" % [int(Game.workers.get(id, 0)), Defs.workers_needed(tp, lv)])
		_:
			if b.has("prod"):
				var r: String = b["prod"]
				st.append("الإنتاج: %s ← %s %s في الساعة" % [Defs.fmt(Defs.prod_rate(tp, lv)), Defs.fmt(Defs.prod_rate(tp, nxt)), Defs.RES_NAMES[r]])
				if lv > 0:
					st.append("العمال: %d / %d   •   الإنتاج الفعلي %s في الساعة" % [int(Game.workers.get(id, 0)), Defs.workers_needed(tp, lv), Defs.fmt(Game.current_rate(id))])
	bp_stats.text = "\n".join(st)
	var has_store := b.has("prod") and lv > 0
	bp_store_row.visible = has_store
	if has_store:
		bp_store.text = "جاهز للجمع: %s / %s" % [Defs.fmt(float(Game.stored.get(id, 0.0))), Defs.fmt(Game.storage_cap(id))]
	bp_mode_row.visible = tp == "furnace"
	for mb in bp_mode_btns:
		(mb[1] as Button).set_pressed_no_signal(Game.furnace_mode == mb[0])
		(mb[1] as Button).modulate = Color(1.25, 1.1, 0.7) if Game.furnace_mode == mb[0] else Color.WHITE
	var building := not q.is_empty()
	bp_progress.visible = building
	bp_cost_row.visible = not building and nxt <= int(b["max"])
	bp_speed.visible = building
	bp_cancel.visible = building
	bp_main.visible = not building
	bp_instant.visible = not building
	if building:
		var total := float(q["end"]) - float(q["start"])
		var remain := float(q["end"]) - Game.now()
		bp_progress.value = 100.0 * (1.0 - remain / maxf(total, 0.01))
		var g := Game.gems_for_time(remain)
		bp_speed.text = "تسريع مجاني" if g == 0 else "تسريع • %d جوهرة" % g
		bp_speed.disabled = Game.gems < g
		bp_reasons.text = "قيد البناء إلى المستوى %d • متبقٍ %s" % [int(q["level"]), Defs.fmt_time(remain)]
		bp_reasons.add_theme_color_override("font_color", Color("7fd3ff"))
		return
	bp_reasons.add_theme_color_override("font_color", UI.RED)
	var cost: Dictionary = chk["cost"]
	for r in bp_cost_chips:
		var c: Array = bp_cost_chips[r]
		(c[0] as Control).visible = cost.has(r)
		if cost.has(r):
			(c[1] as Label).text = Defs.fmt(cost[r])
			(c[1] as Label).add_theme_color_override("font_color", UI.RED if Game.res[r] < cost[r] else Color.WHITE)
	bp_time.text = Defs.fmt_time(chk["time"])
	var reasons: Array = chk["reasons"].duplicate()
	if not chk["missing"].is_empty():
		var miss: Array[String] = []
		for r in chk["missing"]:
			miss.append("%s %s" % [Defs.fmt(chk["missing"][r]), Defs.RES_NAMES[r]])
		reasons.append("ينقصك: " + "، ".join(miss))
	if not chk["builders_free"]:
		reasons.append("كل البنائين مشغولون (يمكنك البناء الفوري)")
	bp_reasons.text = "\n".join(reasons)
	bp_main.text = "تطوير" if lv > 0 else "بناء"
	bp_main.disabled = not chk["ok"]
	var gi := Game.gems_for_time(chk["time"])
	bp_instant.text = "فوري • %d جوهرة" % gi if gi > 0 else "فوري • مجاني"
	bp_instant.disabled = not chk["reasons"].is_empty() or not chk["missing"].is_empty() or Game.gems < gi


func _do_upgrade(instant: bool) -> void:
	if Game.start_upgrade(sel, instant):
		_refresh_plot(sel)
		if not instant:
			_toast("بدأ البناء")
	_update_panel()


func _collect(id: String) -> void:
	var tp: String = Defs.PLOTS[id]["type"]
	var v := Game.collect(id)
	if v > 0:
		_float_text("+" + Defs.fmt(v), Defs.plot_pos(id) + Vector3(0, plot_nodes[id]["top"] + 1.0, 0), Defs.BUILDINGS[tp]["prod"])
	_update_panel()


func _collect_all() -> void:
	var got := {}
	for id in Defs.PLOTS:
		var tp: String = Defs.PLOTS[id]["type"]
		if not Defs.BUILDINGS[tp].has("prod"):
			continue
		var v := Game.collect(id)
		if v > 0:
			got[Defs.BUILDINGS[tp]["prod"]] = float(got.get(Defs.BUILDINGS[tp]["prod"], 0.0)) + v
			_float_text("+" + Defs.fmt(v), Defs.plot_pos(id) + Vector3(0, plot_nodes[id]["top"] + 1.0, 0), Defs.BUILDINGS[tp]["prod"])
	if got.is_empty():
		_toast("لا توجد موارد جاهزة للجمع الآن")
	else:
		var parts: Array[String] = []
		for r in got:
			parts.append("%s %s" % [Defs.fmt(got[r]), Defs.RES_NAMES[r]])
		_toast("تم جمع: " + "، ".join(parts))


func _float_text(t: String, pos: Vector3, r: String) -> void:
	var col := {"food": Color("ffd28a"), "wood": Color("e9b98a"), "coal": Color("d0d4dc"), "iron": Color("a9d8ff")}
	var l := _label3d(t, pos, 34, col.get(r, Color.WHITE))
	add_child(l)
	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property(l, "position:y", pos.y + 3.0, 1.1)
	tw.tween_property(l, "modulate:a", 0.0, 1.1).set_delay(0.3)
	tw.chain().tween_callback(l.queue_free)


# ---------------------------------------------------------------- النقر
func _on_tap(world: Vector3, sp: Vector2) -> void:
	# فقاعات الجمع أولًا (بالمسافة على الشاشة)
	var cam: Camera3D = rig.cam
	for id in plot_nodes:
		var bub: Sprite3D = plot_nodes[id]["bubble"]
		if bub.visible and not cam.is_position_behind(bub.global_position):
			if cam.unproject_position(bub.global_position).distance_to(sp) < 46.0:
				_collect(id)
				return
	var best := ""
	var bd := 1e9
	for id in Defs.PLOTS:
		var p := Defs.plot_pos(id)
		var d := Vector2(world.x - p.x, world.z - p.z).length()
		var lim := 7.0 if id == "furnace" else 3.6
		if d < lim and d < bd:
			bd = d
			best = id
	if best == "":
		_close_panel()
		return
	if Game.level(best) > 0 and float(Game.stored.get(best, 0.0)) >= 1.0:
		_collect(best)
	_select(best)


# ---------------------------------------------------------------- الأحداث
func _on_building_done(id: String) -> void:
	if not plot_nodes.has(id):
		return
	_refresh_all()
	var p := Defs.plot_pos(id)
	var burst := CPUParticles3D.new()
	burst.one_shot = true
	burst.emitting = true
	burst.amount = 40
	burst.lifetime = 1.2
	burst.explosiveness = 0.9
	burst.direction = Vector3.UP
	burst.spread = 60.0
	burst.initial_velocity_min = 4.0
	burst.initial_velocity_max = 8.0
	burst.gravity = Vector3(0, -6, 0)
	var m := BoxMesh.new()
	m.size = Vector3(0.18, 0.18, 0.18)
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.albedo_color = UI.GOLD
	m.material = mat
	burst.mesh = m
	burst.position = p + Vector3(0, 2, 0)
	add_child(burst)
	get_tree().create_timer(2.0).timeout.connect(burst.queue_free)


func _refresh_all() -> void:
	for id in plot_nodes:
		_refresh_plot(id)
	_update_panel()


var _last_sig := ""


func _on_changed() -> void:
	for r in res_chips:
		(res_chips[r] as Label).text = Defs.fmt(Game.res[r])
		(res_chips[r] as Label).add_theme_color_override("font_color", UI.RED if Game.net_rate(r) < 0 and Game.res[r] < 200 else Color.WHITE)
	gem_label.text = Defs.fmt(Game.gems)
	temp_label.text = "%d°" % int(round(Game.inside_temp))
	var tcol: Color = [UI.GREEN, Color("ffd36b"), UI.RED][Game.cold_level]
	temp_label.add_theme_color_override("font_color", tcol)
	pop_label.text = "%d/%d" % [Game.pop, Game.pop_capacity()]
	sick_label.text = str(int(Game.sick))
	for i in builder_rows.size():
		var row: Dictionary = builder_rows[i]
		if i < Game.queue.size():
			var q: Dictionary = Game.queue[i]
			var tp: String = Defs.PLOTS[q["plot"]]["type"]
			var remain := float(q["end"]) - Game.now()
			(row["label"] as Label).text = "%s %d • %s" % [Defs.BUILDINGS[tp]["name"], int(q["level"]), Defs.fmt_time(remain)]
			(row["bar"] as ProgressBar).value = 100.0 * (1.0 - remain / maxf(float(q["end"]) - float(q["start"]), 0.01))
		else:
			(row["label"] as Label).text = "البنّاء %d: متاح" % (i + 1)
			(row["bar"] as ProgressBar).value = 0
	# المهمة
	var tk := Game.current_task()
	if tk.is_empty():
		task_title.text = "أنهيت كل مهام الفصل الأول"
		task_prog.text = "مهام جديدة في المرحلة القادمة"
		task_btn.visible = false
	else:
		var pr := Game.task_progress(tk)
		task_title.text = tk["text"]
		var rw: Array[String] = []
		for k in tk["reward"]:
			rw.append("%s %s" % [Defs.fmt(tk["reward"][k]), Defs.RES_NAMES[k]])
		task_prog.text = "%s / %s   •   المكافأة: %s" % [Defs.fmt(minf(pr.x, pr.y)), Defs.fmt(pr.y), "، ".join(rw)] if tk["type"] != "temp" else "المكافأة: " + "، ".join(rw)
		task_btn.visible = true
		var done := Game.task_done(tk)
		task_btn.text = "استلام" if done else "اذهب"
		task_btn.modulate = Color(1, 1, 1) if done else Color(0.75, 0.8, 0.9)
	# العاصفة
	var soon := Game.storm_soon()
	if Game.storm_active():
		storm_label.visible = true
		storm_label.text = "عاصفة ثلجية • -22° • تنتهي خلال %s" % Defs.fmt_time(Game.storm_end - Game.now())
	elif soon > 0:
		storm_label.visible = true
		storm_label.text = "تحذير: عاصفة ثلجية خلال %s — جهّز الفحم" % Defs.fmt_time(soon)
	else:
		storm_label.visible = false
	# إعادة بناء المواقع عند تغيّر المستويات أو الطابور
	var sig := str(Game.plots) + str(Game.queue.size()) + str(Game.furnace_level())
	if sig != _last_sig:
		_last_sig = sig
		_refresh_all()
	_update_panel()
	_sync_citizens()


func _task_action() -> void:
	var tk := Game.current_task()
	if tk.is_empty():
		return
	if Game.task_done(tk):
		Game.claim_task()
		return
	# الذهاب إلى المبنى المناسب
	var tp: String = tk.get("b", "")
	if tk["type"] == "collect":
		tp = {"food": "hunter", "wood": "sawmill", "coal": "coal_mine", "iron": "iron_mine"}[tk["r"]]
	elif tk["type"] == "pop":
		tp = "shelter"
	elif tk["type"] == "temp":
		tp = "furnace"
	elif tk["type"] == "march":
		_go_map()
		return
	var target := ""
	for id in Defs.PLOTS:
		if Defs.PLOTS[id]["type"] != tp:
			continue
		if tk["type"] == "count" and Game.level(id) == 0 and Game.furnace_level() >= int(Defs.PLOTS[id]["unlock"]):
			target = id
			break
		if target == "" or Game.level(id) > Game.level(target):
			target = id
	if target != "":
		_select(target)


# ---------------------------------------------------------------- النوافذ
func _modal(title: String, body: String, buttons: Array, icon_name: String = "") -> Control:
	_close_panel()
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.45)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	dim.mouse_filter = Control.MOUSE_FILTER_STOP
	modal_layer.add_child(dim)
	var p := UI.panel(Color(0.06, 0.11, 0.19, 0.97), 22)
	p.custom_minimum_size = Vector2(560, 0)
	dim.add_child(p)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 12)
	p.add_child(v)
	var h := HBoxContainer.new()
	h.alignment = BoxContainer.ALIGNMENT_END
	v.add_child(h)
	h.add_child(UI.label(title, 26, UI.GOLD))
	if icon_name != "":
		h.add_child(UI.icon_rect(icon_name, 44))
	if body != "":
		var b := UI.label(body, 19)
		b.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		b.custom_minimum_size = Vector2(520, 0)
		v.add_child(b)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	v.add_child(row)
	for bt in buttons:
		var cb: Callable = bt[1]
		var btn := UI.button(bt[0], func():
			dim.queue_free()
			cb.call(), bt[2] if bt.size() > 2 else "dark", 56)
		btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(btn)
	p.set_anchors_and_offsets_preset(Control.PRESET_CENTER, Control.PRESET_MODE_MINSIZE)
	p.grow_horizontal = Control.GROW_DIRECTION_BOTH
	p.grow_vertical = Control.GROW_DIRECTION_BOTH
	return v


func _show_daily() -> void:
	var rw := Game.daily_reward()
	var parts: Array[String] = []
	for k in rw:
		parts.append("• %s: %s" % [Defs.RES_NAMES[k], Defs.fmt(rw[k])])
	_modal("المكافأة اليومية", "هدية اليوم لمدينتك:\n" + "\n".join(parts), [["استلام", func(): Game.claim_daily(), "gold"]], "gift")


func _show_tasks() -> void:
	var lines: Array[String] = []
	for i in Defs.TASKS.size():
		var tk: Dictionary = Defs.TASKS[i]
		var mark := "✓" if i < Game.task_index else ("◀" if i == Game.task_index else "•")
		lines.append("%s  %s" % [mark, tk["text"]])
		if i > Game.task_index + 4:
			lines.append("…")
			break
	var title := "مهام الفصل الأول (%d / %d)" % [mini(Game.task_index, Defs.TASKS.size()), Defs.TASKS.size()]
	var btns: Array = [["إغلاق", func(): pass, "dark"]]
	if Game.daily_ready:
		btns.append(["المكافأة اليومية", _show_daily, "gold"])
	_modal(title, "\n".join(lines), btns, "task")


func _show_settings() -> void:
	_modal("الإعدادات", "جودة الرسوم الحالية: %s\nالحفظ تلقائي كل 15 ثانية وعند الخروج من اللعبة." % ("عالية" if Game.quality_high else "منخفضة (أسرع على الهواتف الضعيفة)"),
		[["إغلاق", func(): pass, "dark"],
		["تبديل الجودة", func():
			Game.quality_high = not Game.quality_high
			_apply_quality()
			Game.save_game(), "blue"],
		["بدء لعبة جديدة", _confirm_reset, "red"]], "gear")


func _confirm_reset() -> void:
	_modal("تأكيد", "سيتم حذف تقدمك بالكامل وبدء مدينة جديدة. هل أنت متأكد؟",
		[["تراجع", func(): pass, "dark"], ["نعم، احذف", func():
			Game.reset_game()
			get_tree().reload_current_scene(), "red"]])


func _toast(t: String) -> void:
	if toast_box == null:
		return
	var l := UI.label(t, 19, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER)
	l.add_theme_stylebox_override("normal", UI.style(Color(0.04, 0.08, 0.14, 0.88), 18))
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	toast_box.add_child(l)
	while toast_box.get_child_count() > 3:
		toast_box.get_child(0).free()
	var tw := create_tween()
	tw.tween_interval(2.8)
	tw.tween_property(l, "modulate:a", 0.0, 0.5)
	tw.tween_callback(l.queue_free)


func _go_map() -> void:
	Game.save_game()
	get_tree().change_scene_to_file("res://world_map.tscn")


# ================================================================ كل إطار
func _process(delta: float) -> void:
	for id in plot_nodes:
		_update_plot_dynamic(id)
	_update_citizens(delta)
	# الفرن والجو
	var on: bool = Game.furnace_mode > 0 and Game.res["coal"] > 0
	var target := 0.0 if not on else (2.2 if Game.furnace_mode == 1 else 4.0)
	fire_light.light_energy = lerpf(fire_light.light_energy, target * (0.9 + 0.1 * sin(Time.get_ticks_msec() / 90.0)), delta * 4.0)
	smoke.emitting = on
	var tier := _tier("furnace", Game.furnace_level())
	smoke.position = Defs.CITY_CENTER + Vector3(0, 9.2 + tier * 2.6, 0)
	var storm := Game.storm_active()
	var cold := float(Game.cold_level) / 2.0
	var mat := frost_overlay.material as ShaderMaterial
	var cur := float(mat.get_shader_parameter("amount") if mat.get_shader_parameter("amount") != null else 0.0)
	mat.set_shader_parameter("amount", lerpf(cur, clampf(cold * 0.8 + (0.35 if storm else 0.0), 0.0, 1.0), delta * 1.5))
	env.fog_density = lerpf(env.fog_density, 0.016 if storm else 0.0, delta * 0.8)
	env.fog_enabled = env.fog_density > 0.0005
	snow.speed_scale = 2.2 if storm else 1.0
	sun.light_energy = lerpf(sun.light_energy, 0.55 if storm else 0.95, delta)
	var d: float = rig.dist
	snow.emission_box_extents = Vector3(d * 0.8, 1, d * 0.8)
	snow.position = Vector3(0, clampf(d * 0.5, 12.0, 40.0), 0)
	if sel_ring.visible:
		var k := 1.0 + sin(Time.get_ticks_msec() / 180.0) * 0.04
		var r := (7.5 if sel == "furnace" else 2.6) * k
		sel_ring.scale = Vector3(r, 1, r)
