extends RefCounted
## Stage 34 — قواعد المدن الحربية: حامية قابلة للتكرار، دفاعات متدرجة، ومكافآت احتلال.
const Defs := preload("res://scripts/defs.gd")

static func garrison(level: int, seed_key: int = 0) -> Dictionary:
	var lv := clampi(level, 1, 30)
	var out := {}
	var base := 18 + lv * 14
	for tp in ["shield", "spear", "bow"]:
		var tier := clampi(1 + int((lv - 1) / 5), 1, 4)
		var bias := 1.0 if tp == "shield" else (0.85 if tp == "spear" else 0.75)
		var n := maxi(int(round(base * bias)), 1)
		out["%s_%d" % [tp, tier]] = n
	return out

static func total_units(units: Dictionary) -> int:
	var total := 0
	for key in units:
		total += int(units[key])
	return total

static func mods(level: int) -> Dictionary:
	var lv := clampi(level, 1, 30)
	var bonus := minf(0.02 * float(lv - 1), 0.55)
	var zeros := {"shield": bonus, "spear": bonus, "bow": bonus}
	return {"atk": zeros.duplicate(true), "def": zeros.duplicate(true), "hp": zeros.duplicate(true),
		"damage": {}, "skill": "", "all": 0.0, "hp_all": bonus * 0.5, "taken": 1.0}

static func reward(level: int) -> Dictionary:
	var lv := clampi(level, 1, 30)
	return {"food": 700 * lv, "wood": 500 * lv, "coal": 180 * lv, "gems": maxi(int(lv / 4), 1)}

static func city_id(target: Dictionary) -> String:
	return "%d:%d" % [int(target.get("x", 0)), int(target.get("y", 0))]
