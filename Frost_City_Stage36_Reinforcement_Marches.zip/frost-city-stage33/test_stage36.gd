extends Node
## Stage 36: tests for city-to-city reinforcement marches.
var checks := 0
var failures := 0
func check(ok: bool, label: String) -> void:
	checks += 1
	if not ok: failures += 1
	print(("PASS: " if ok else "FAIL: ") + label)
func _ready() -> void:
	Game.save_path_override = "user://frost_save_test_stage36.json"
	Game.new_game()
	Game.set_process(false)
	Game.city_wars = {
		"10:10": {"team":"me", "name":"المدينة الأولى", "x":10, "y":10},
		"20:20": {"team":"me", "name":"المدينة الثانية", "x":20, "y":20},
		"30:30": {"team":"enemy", "name":"مدينة عدو", "x":30, "y":30}
	}
	Game.city_garrisons = {"10:10": {"shield_1": 100, "bow_1": 40}, "20:20": {"spear_1": 10}}
	var ok := Game.send_city_reinforcement("10:10", "20:20", {"shield_1": 25, "bow_1": 5})
	check(ok, "owned city can send reinforcement to another owned city")
	check(int(Game.city_garrisons["10:10"].get("shield_1", 0)) == 75, "departing units are deducted from source garrison")
	check(Game.city_reinforcement_marches.size() == 1, "march is persisted as a timed record")
	check(int(Game.city_reinforcement_marches[0]["units"]["shield_1"]) == 25, "march carries exact troop composition")
	check(not Game.send_city_reinforcement("10:10", "30:30", {"shield_1": 1}), "reinforcement cannot be sent to an enemy city")
	check(not Game.send_city_reinforcement("10:10", "20:20", {"shield_1": 999}), "cannot dispatch more units than the source garrison owns")
	check(not Game.send_city_reinforcement("10:10", "10:10", {"shield_1": 1}), "same-city reinforcement is rejected")
	print("STAGE36: %d checks, %d failures" % [checks, failures])
	get_tree().quit(1 if failures > 0 else 0)
