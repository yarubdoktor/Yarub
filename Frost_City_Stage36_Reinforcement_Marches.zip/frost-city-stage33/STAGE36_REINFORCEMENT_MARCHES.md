# Frost City — Stage 36: Reinforcement Marches

Extends Stage 35 in place. Save version: 10 (older saves remain supported).

## Implemented
- Send a selected troop composition from one player-owned captured city garrison to another player-owned city.
- Source units are deducted immediately; the march record contains source, destination, composition, send time and ETA.
- Travel time scales with distance (minimum 30 seconds) and marches persist across saves.
- Arrival deposits the exact surviving composition into the destination garrison and creates a battle-inbox report.
- If destination ownership changes before arrival, troops return to the source garrison when it is still player-owned; they are never handed to an enemy or silently duplicated.
- Basic API validation for ownership, same-city routes, empty composition and troop availability.

## Test
Run `godot --headless --path . res://test_stage36.tscn`.

## Scope note
This is local, single-player reinforcement simulation. It is not real PvP or alliance networking; those require a server-authoritative backend. The map panel still needs a dedicated reinforcement dispatch UI in a later integration pass.
