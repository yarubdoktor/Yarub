extends Node
## Stage 34 — اختبارات قواعد المدن الحربية. شغّل: godot --headless --path . res://test_stage34.tscn
const CityWar := preload("res://scripts/game/city_war.gd")
const Combat := preload("res://scripts/combat.gd")
const WarRules := preload("res://scripts/game/war_rules.gd")
var checks := 0
var failures := 0
func check(ok: bool, label: String) -> void:
	checks += 1
	if not ok: failures += 1
	print(("PASS: " if ok else "FAIL: ") + label)
func _ready() -> void:
	var low := CityWar.garrison(1)
	var high := CityWar.garrison(10)
	var total_low := 0
	var total_high := 0
	for k in low:
		total_low += int(low[k])
	for k in high:
		total_high += int(high[k])
	check(low.size() == 3, "city garrison contains shield, spear and bow rows")
	check(total_high > total_low, "higher-level cities have larger garrisons")
	check(CityWar.mods(10)["atk"]["shield"] > CityWar.mods(1)["atk"]["shield"], "city level scales defender technology")
	check(CityWar.reward(5)["food"] > CityWar.reward(1)["food"], "higher-level cities offer larger rewards")
	check(CityWar.city_id({"x": 10, "y": 20}) == "10:20", "city ownership key is stable from map coordinates")
	var a := {"shield_2": 250, "spear_2": 250, "bow_2": 250}
	var result := Combat.fight(a, {}, high, CityWar.mods(10), false, 42, WarRules.ATTACK_OPTS)
	check(result.has("att_win") and result.has("att_loss") and result.has("def_loss"), "city battle returns victory and casualty results")
	check(result["rounds"] > 0, "city battle resolves through combat rounds")
	print("STAGE34: %d checks, %d failures" % [checks, failures])
	get_tree().quit(1 if failures > 0 else 0)
