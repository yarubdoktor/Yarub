# Frost City — Stage 35: City Defense & Battle Reports

Extends Stage 34 in place.

## Added
- Persistent battle report inbox (latest 50, unread flag, read-all API).
- Report fields: target, timestamp, battle rounds/log, attackers committed/survived/lost, defenders lost/remaining, victory/retreat, reward and capture status. Final death count is reconciled when the army returns.
- Persistent garrisons for captured cities. Surviving enemy defenders remain recorded after capture; no extra troops are created.
- `Game.set_city_garrison(city_id, requested)` moves available player troops into a captured city's garrison with ownership and availability checks. Replacing a garrison returns its old units before moving the new composition.
- `Game.withdraw_city_garrison(city_id)` returns stationed troops to the player army.
- Captured-city map panel shows stationed garrison size and unread report count.
- Save version 9 migrates older saves with empty reports/garrisons.

## Test
`godot --headless --path . res://test_stage35.tscn`

## Important scope note
This stage supplies the persistent garrison and report foundations. Real-time player-vs-player defence, server-authoritative alliances, reinforcement marches and counterattacks require a multiplayer backend and are not simulated as if they were already online.
