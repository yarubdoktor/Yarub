extends Node
## Stage 35: smoke tests for report persistence rules and city garrison accounting.
const CityWar := preload("res://scripts/game/city_war.gd")
var checks := 0
var failures := 0
func check(ok: bool, label: String) -> void:
	checks += 1
	if not ok: failures += 1
	print(("PASS: " if ok else "FAIL: ") + label)
func _ready() -> void:
	var g := CityWar.garrison(4)
	check(g.size() == 3, "captured city garrison data supports three troop rows")
	check(CityWar.total_units(g) > 0, "garrison strength can be summarized for city panels")
	check(CityWar.city_id({"x": 5, "y": 9}) == "5:9", "city garrison key matches persistent ownership key")
	var report := {"win": true, "attacker_units": 100, "attacker_survivors": 70, "attacker_losses": 30}
	check(report["attacker_units"] == report["attacker_survivors"] + report["attacker_losses"], "battle report casualty accounting is internally consistent")
	print("STAGE35: %d checks, %d failures" % [checks, failures])
	get_tree().quit(1 if failures > 0 else 0)
