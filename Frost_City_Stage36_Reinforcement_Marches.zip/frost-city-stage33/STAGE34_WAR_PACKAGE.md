# Frost City — Stage 34: City Warfare Package

This package extends the existing Stage 33 project. It does not replace the existing combat engine, formations, hero/research modifiers, infirmary casualty handling, or venture march scheduler.

## Implemented
- Enemy cities open the existing army/formation dispatch window instead of the generic resource-march action.
- City defenders are generated as three troop rows (shield, spear, bow), with garrison size and combat modifiers scaling with city level.
- City attacks use the existing `Combat.fight` engine and the same travel/arrival/return timing as military campaigns.
- Successful captures grant level-scaled resources and are persisted by map coordinates in `city_wars`.
- Save format version increased to 8; older saves continue loading with an empty city-ownership dictionary.
- Added a headless Stage 34 rules/combat test scene.

## Test
From a Godot 4.7 project directory:

```sh
godot --headless --path . res://test_stage34.tscn
```

## Scope / next iteration
This first package establishes the city-attack loop. Captured-city visuals/territorial ownership refresh, NPC counterattacks, city garrison management, reinforcement between allied cities, alliance wars, and a dedicated battle-report inbox remain follow-up work. The map's generated NPC city mesh team is not yet re-instanced after capture; the selected-city panel and saved ownership state do recognize the capture.
