extends Node3D
## مشهد المدينة: البناء والتطوير، والفرن، والسكان، والجمع، والمهام

const Defs := preload("res://scripts/defs.gd")
const UI := preload("res://scripts/ui_kit.gd")
const StrategyCamera := preload("res://scripts/strategy_camera.gd")
const HomeHud := preload("res://scripts/ui/home_hud.gd")
const JobTimers := preload("res://scripts/ui/job_timers.gd")

var rig: Node3D
var env: Environment
var sky_mat: ProceduralSkyMaterial
var sun: DirectionalLight3D
var fire_light: OmniLight3D
var snow: CPUParticles3D
var smoke: CPUParticles3D
var font: Font
var scenes := {}
var plot_nodes := {}
var citizens: Array = []
var citizen_meshes: Array = []

# الواجهة
var ui: Control
var blockers: Array[Control] = []
var res_chips := {}
var gem_label: Label
var temp_label: Label
var temp_chip: PanelContainer
var pop_label: Label
var sick_label: Label
var builder_rows: Array = []
var job_rows: Array = []        # صفوف التدريب والبحث في الطابور الجانبي (Stage 16)
var timer_layer: Control = null # طبقة مؤقتات فوق المباني
var timer_widgets := {}          # id الموقع ← لوحة المؤقت
var storm_label: Label
var frost_overlay: ColorRect
var task_title: Label
var task_prog: Label
var task_btn: Button
var toast_box: VBoxContainer
var modal_layer: Control
var dev_btn: Button = null
var avatar_btn: Button = null
var avatar_id := ""
var march_head: Label
var march_box: VBoxContainer
var march_rows: Array = []
var hud_collapsed := false

# لوحة المبنى
var sel := ""
var bp: PanelContainer
var bp_title: Label
var bp_desc: Label
var bp_stats: Label
var bp_store_row: HBoxContainer
var bp_store: Label
var bp_cost_row: HBoxContainer
var bp_cost_chips := {}
var bp_time: Label
var bp_reasons: Label
var bp_progress: ProgressBar
var bp_main: Button
var bp_instant: Button
var bp_speed: Button
var bp_cancel: Button
var bp_mode_row: HBoxContainer
var bp_mode_btns: Array = []
var bp_open: Button
var sel_ring: MeshInstance3D

# المرحلة الثانية
var aurora_label: Label
var trust_label: Label
var power_label: Label
var side_btns := {}
var raid_label: Label
var soldier_meshes := {}
var soldier_nodes: Array = []
var _soldier_sig := ""
var crystal_scene: Node3D
var crystal_nodes: Array = []
var wolf_scene: Node3D
var raid_anim: Array = []
var raid_anim_t := -1.0
var raid_anim_win := false
var win_refresh: Callable
var win_tick: Array = []
var win_layer: Control
var army_tier := 1
var train_tp := "shield"
var army_n := 20
var hero_sel := "siraj"
var tech_branch := 0


func _ready() -> void:
	font = load(UI.FONT_PATH)
	_setup_env()
	var ground: Node3D = _inst("res://assets/city/ground.glb")
	add_child(ground)
	for id in Defs.PLOTS:
		_make_plot(id)
	_setup_fx()
	_setup_camera()
	_setup_ui()
	_setup_citizens()
	Game.changed.connect(_on_changed)
	Game.toast.connect(_toast)
	Game.building_done.connect(_on_building_done)
	Game.raid_happened.connect(_on_raid)
	Game.crystals_changed.connect(_sync_crystals)
	Game.decision_ready.connect(_on_changed)
	_setup_stage2_world()
	_on_changed()
	_apply_quality()
	call_deferred("_welcome")


func _welcome() -> void:
	if not Game.migration_note.is_empty():
		var mn: Dictionary = Game.migration_note
		Game.migration_note = {}
		var ml: Array[String] = ["تم تحديث نظام الجيش والمدينة:"]
		if mn.has("barracks_granted"):
			ml.append("• المعسكر صار مكان تجمع القوات، والتدريب انتقل إلى ثلاث ثكنات (دروع، رماح، رماة). منحناك كل ثكنة بمستوى معسكرك السابق (%d)." % int(mn["barracks_granted"]))
		if mn.has("shelters_removed"):
			ml.append("• المآوي صارت 4 فقط وسعتها أكبر. ألغينا %d مأوى زائدًا وأعدنا لك تكلفتها كاملة:" % int(mn["shelters_removed"]))
			var rp: Array[String] = []
			for r in mn.get("refund", {}):
				rp.append("%s %s" % [Defs.fmt(float(mn["refund"][r])), Defs.RES_NAMES[r]])
			ml.append("   " + "، ".join(rp))
		_modal("تحديث المدينة", "\n".join(ml), [["حسنًا", func(): pass, "gold"]], "army")
		return
	var rep: Dictionary = Game.offline_report
	if not rep.is_empty():
		var lines: Array[String] = ["غبت %s، وخلال غيابك:" % Defs.fmt_time(rep["elapsed"])]
		for r in rep["gained"]:
			if rep["gained"][r] >= 1:
				lines.append("• تجمّع %s %s في المباني" % [Defs.fmt(rep["gained"][r]), Defs.RES_NAMES[r]])
		if rep["built"] > 0:
			lines.append("• اكتمل %d من أعمال البناء" % rep["built"])
		if rep["pop"] > 0:
			lines.append("• وصل %d ناجين جدد" % rep["pop"])
		Game.offline_report = {}
		_modal("مرحبًا بعودتك أيها القائد", "\n".join(lines), [["جمع الكل", _collect_all, "gold"]], "gift")
	elif Game.daily_ready:
		_show_daily()
	elif Game.stats.get("built", 0) == 0 and Game.task_index == 0:
		_modal("مدينة الصقيع", "العالم تجمّد، ونجا معك قلة من الناس.\nأبقِ الفرن مشتعلًا، وابنِ المآوي، واجمع الموارد قبل العاصفة القادمة.\n\nاضغط على أي موقع بناء للبدء.",
				[["لنبدأ", func(): pass, "gold"]], "fire")
	elif Game.raid_unseen:
		_show_raid_report()


# ================================================================ البيئة
func _setup_env() -> void:
	env = Environment.new()
	sky_mat = ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color("7fa9cd")
	sky_mat.sky_horizon_color = Color("e9e3d3")
	sky_mat.ground_horizon_color = Color("e9e3d3")
	sky_mat.ground_bottom_color = Color("b6c3d0")
	var sky := Sky.new()
	sky.sky_material = sky_mat
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = 0.42
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.tonemap_white = 1.6
	env.fog_enabled = true
	env.fog_light_color = Color("dfe8f0")
	env.fog_density = 0.0032
	env.fog_sky_affect = 0.12
	env.glow_enabled = true
	env.glow_intensity = 0.5
	env.glow_hdr_threshold = 1.4
	env.adjustment_enabled = true
	env.adjustment_saturation = 1.06
	env.adjustment_contrast = 1.03
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)
	sun = DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-50, -30, 0)
	sun.light_energy = 0.95
	sun.light_color = Color("ffe9cd")
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 140.0
	add_child(sun)


func _apply_quality() -> void:
	sun.shadow_enabled = Game.quality_high
	env.glow_enabled = Game.quality_high
	snow.amount = 700 if Game.quality_high else 250
	smoke.amount = 60 if Game.quality_high else 25


func _fix(n: Node) -> void:
	if n is MeshInstance3D and n.mesh:
		for s in n.mesh.get_surface_count():
			var mat := n.mesh.surface_get_material(s) as BaseMaterial3D
			if mat:
				mat.vertex_color_use_as_albedo = true
				if mat.resource_name == "Snow" or mat.resource_name == "Matte":
					mat.metallic_specular = 0.25
				if mat.resource_name == "Glow":
					mat.emission_enabled = true
					mat.emission = Color(0.35, 0.95, 1.0)
					mat.emission_energy_multiplier = 2.5
	for c in n.get_children():
		_fix(c)


func _inst(path: String) -> Node3D:
	if not scenes.has(path):
		scenes[path] = load(path)
	var n: Node3D = scenes[path].instantiate()
	_fix(n)
	return n


func _setup_fx() -> void:
	fire_light = OmniLight3D.new()
	fire_light.position = Defs.CITY_CENTER + Vector3(0, 7, 0)
	fire_light.light_color = Color("ff9a4a")
	fire_light.omni_range = 34.0
	fire_light.omni_attenuation = 1.2
	add_child(fire_light)

	smoke = CPUParticles3D.new()
	smoke.amount = 60
	smoke.lifetime = 5.0
	smoke.preprocess = 4.0
	smoke.direction = Vector3(0.25, 1, 0.1)
	smoke.spread = 14.0
	smoke.gravity = Vector3(0.6, 0.6, 0)
	smoke.initial_velocity_min = 1.6
	smoke.initial_velocity_max = 2.6
	smoke.scale_amount_min = 0.8
	smoke.scale_amount_max = 1.6
	var curve := Curve.new()
	curve.add_point(Vector2(0, 0.4))
	curve.add_point(Vector2(1, 2.2))
	smoke.scale_amount_curve = curve
	var grad := Gradient.new()
	grad.set_color(0, Color(0.35, 0.36, 0.4, 0.75))
	grad.set_color(1, Color(0.8, 0.82, 0.86, 0.0))
	smoke.color_ramp = grad
	var sm := SphereMesh.new()
	sm.radius = 0.6
	sm.height = 1.2
	sm.radial_segments = 8
	sm.rings = 4
	var smat := StandardMaterial3D.new()
	smat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	smat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	smat.vertex_color_use_as_albedo = true
	sm.material = smat
	smoke.mesh = sm
	add_child(smoke)

	sel_ring = MeshInstance3D.new()
	var torus := TorusMesh.new()
	torus.inner_radius = 0.92
	torus.outer_radius = 1.0
	torus.rings = 48
	sel_ring.mesh = torus
	var rm := StandardMaterial3D.new()
	rm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	rm.albedo_color = UI.GOLD
	sel_ring.material_override = rm
	sel_ring.visible = false
	add_child(sel_ring)


func _setup_camera() -> void:
	rig = StrategyCamera.new()
	rig.map_size = 120.0
	rig.edge_margin = 24.0
	rig.min_dist = 12.0
	rig.max_dist = 85.0
	rig.near_pitch_deg = 40.0
	rig.far_pitch_deg = 60.0
	rig.ground_y = 0.0
	add_child(rig)
	rig.ui_hit_test = _over_ui
	rig.tapped.connect(_on_tap)
	rig.set_view(Defs.CITY_CENTER + Vector3(0, 0, 6), 52.0)

	snow = CPUParticles3D.new()
	snow.amount = 700
	snow.lifetime = 5.0
	snow.preprocess = 5.0
	snow.local_coords = true
	snow.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	snow.emission_box_extents = Vector3(45, 1, 45)
	snow.position = Vector3(0, 26, 0)
	snow.direction = Vector3(0.3, -1, 0.1)
	snow.spread = 12.0
	snow.gravity = Vector3(0, -2.0, 0)
	snow.initial_velocity_min = 3.0
	snow.initial_velocity_max = 6.0
	var q := SphereMesh.new()
	q.radius = 0.06
	q.height = 0.12
	q.radial_segments = 6
	q.rings = 3
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.albedo_color = Color(1, 1, 1, 0.9)
	q.material = m
	snow.mesh = q
	rig.add_child(snow)


# ================================================================ مواقع البناء
func _tier(id: String, lv: int) -> int:
	if lv < 5:
		return 0
	return 1 if lv < 15 else 2


func _make_plot(id: String) -> void:
	var root := Node3D.new()
	root.position = Defs.plot_pos(id)
	var dir := Defs.CITY_CENTER - root.position
	if dir.length() > 0.1:
		root.rotation.y = atan2(dir.x, dir.z)
	add_child(root)
	var tp: String = Defs.PLOTS[id]["type"]
	var top := 9.0 if tp == "furnace" else 3.6
	var badge := _label3d("", Vector3(0, top, 0), 30, Color.WHITE)
	root.add_child(badge)
	var timer := _label3d("", Vector3(0, top + 1.6, 0), 28, Color("7fd3ff"))
	root.add_child(timer)
	var bubble := Sprite3D.new()
	bubble.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	bubble.fixed_size = true
	bubble.pixel_size = 0.0006
	bubble.no_depth_test = true
	bubble.position = Vector3(0, top + 1.2, 0)
	bubble.visible = false
	if Defs.BUILDINGS[tp].has("prod"):
		bubble.texture = UI.icon(Defs.BUILDINGS[tp]["prod"])
	root.add_child(bubble)
	var flag_mat: StandardMaterial3D = null
	if tp.begins_with("bk_"):
		flag_mat = _add_banner(root, tp)
	plot_nodes[id] = {"root": root, "model": null, "key": "", "badge": badge, "timer": timer,
			"bubble": bubble, "scaffold": null, "top": top, "flag_mat": flag_mat}
	_refresh_plot(id)


func _add_banner(root: Node3D, tp: String) -> StandardMaterial3D:
	## راية ملونة تميّز كل ثكنة (دروع: أزرق • رماح: أخضر • رماة: برتقالي) — بلا نماذج جديدة
	var col := {"bk_shield": Color("5aa7ff"), "bk_spear": Color("7fdc7a"), "bk_bow": Color("ff9a4a")}[tp] as Color
	var mat := StandardMaterial3D.new()
	mat.albedo_color = col
	mat.emission_enabled = true
	mat.emission = col
	mat.emission_energy_multiplier = 0.6
	var pole := MeshInstance3D.new()
	var pm := CylinderMesh.new()
	pm.top_radius = 0.07
	pm.bottom_radius = 0.07
	pm.height = 4.2
	pole.mesh = pm
	pole.position = Vector3(2.6, 2.1, 2.2)
	root.add_child(pole)
	var flag := MeshInstance3D.new()
	var fm := BoxMesh.new()
	fm.size = Vector3(1.3, 0.8, 0.06)
	flag.mesh = fm
	flag.material_override = mat
	flag.position = Vector3(2.6 + 0.7, 3.7, 2.2)
	root.add_child(flag)
	return mat


func _label3d(text: String, pos: Vector3, size: int, color: Color) -> Label3D:
	var l := Label3D.new()
	l.text = text
	l.font = font
	l.font_size = size
	l.outline_size = 14
	l.modulate = color
	l.outline_modulate = Color(0.04, 0.08, 0.14, 0.95)
	l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	l.fixed_size = true
	l.pixel_size = 0.0009
	l.no_depth_test = true
	l.position = pos
	return l


func _refresh_plot(id: String) -> void:
	var pn: Dictionary = plot_nodes[id]
	var tp: String = Defs.PLOTS[id]["type"]
	var lv := Game.level(id)
	var q := Game.queue_entry(id)
	var locked := Game.furnace_level() < int(Defs.PLOTS[id]["unlock"])
	var key := ""
	if lv > 0:
		var model_tp: String = "barracks" if tp.begins_with("bk_") else tp
		key = "res://assets/city/%s_t%d.glb" % [model_tp, _tier(id, lv)]
	elif q.is_empty():
		key = "res://assets/city/plot.glb"
	if key != pn["key"]:
		if pn["model"]:
			pn["model"].queue_free()
		pn["model"] = null
		if key != "":
			pn["model"] = _inst(key)
			pn["root"].add_child(pn["model"])
		pn["key"] = key
	var building: bool = not q.is_empty()
	if building and pn["scaffold"] == null:
		pn["scaffold"] = _inst("res://assets/city/scaffold.glb")
		if tp == "furnace":
			pn["scaffold"].scale = Vector3(2.4, 2.4, 2.4)
		pn["root"].add_child(pn["scaffold"])
	elif not building and pn["scaffold"] != null:
		pn["scaffold"].queue_free()
		pn["scaffold"] = null
	var badge: Label3D = pn["badge"]
	if lv > 0:
		var named: bool = tp == "furnace" or tp == "barracks" or tp.begins_with("bk_")
		badge.text = "%s  %d" % [Defs.BUILDINGS[tp]["name"], lv] if named else "Lv.%d" % lv
		badge.modulate = UI.GOLD if tp == "furnace" else Color.WHITE
		badge.font_size = 34 if tp == "furnace" else 26
	elif locked:
		badge.text = "مقفل • الفرن %d" % Defs.PLOTS[id]["unlock"]
		badge.modulate = Color(0.75, 0.78, 0.82)
		badge.font_size = 22
	elif not building:
		badge.text = "+ " + str(Defs.BUILDINGS[tp]["name"])
		badge.modulate = Color("9fe0ff")
		badge.font_size = 24
	else:
		badge.text = ""
	if pn["model"] and lv == 0:
		pn["model"].visible = true
		(pn["model"] as Node3D).scale = Vector3.ONE * (0.8 if locked else 1.0)


func _update_plot_dynamic(id: String) -> void:
	var pn: Dictionary = plot_nodes[id]
	var q := Game.queue_entry(id)
	# المؤقت صار لوحة فوق المبنى (job_timers.gd) فنُفرغ النص القديم ثلاثي الأبعاد
	(pn["timer"] as Label3D).text = ""
	var bubble: Sprite3D = pn["bubble"]
	if bubble.texture:
		var s := float(Game.stored.get(id, 0.0))
		var cap := Game.storage_cap(id)
		bubble.visible = s >= 1.0 and s >= cap * 0.04 and q.is_empty()
		if bubble.visible:
			var t := Time.get_ticks_msec() / 1000.0
			bubble.position.y = pn["top"] + 1.4 + sin(t * 3.0 + id.hash() % 7) * 0.25
			bubble.modulate = Color(1, 0.85, 0.6) if s >= cap * 0.98 else Color.WHITE


# ================================================================ السكان
func _setup_citizens() -> void:
	citizen_meshes = [_inst("res://assets/city/citizen_a.glb"), _inst("res://assets/city/citizen_b.glb")]


func _sync_citizens() -> void:
	var want := mini(Game.healthy(), 36)
	while citizens.size() < want:
		var n: Node3D = (citizen_meshes[citizens.size() % 2] as Node3D).duplicate()
		n.scale = Vector3.ONE * 1.4
		add_child(n)
		var p := _random_spot()
		n.position = p
		citizens.append({"node": n, "to": _random_spot(), "wait": randf() * 2.0, "speed": randf_range(1.6, 2.4)})
	while citizens.size() > want:
		var c: Dictionary = citizens.pop_back()
		(c["node"] as Node).queue_free()


func _random_spot() -> Vector3:
	var built: Array = []
	for id in Defs.PLOTS:
		if Game.level(id) > 0 and id != "furnace":
			built.append(id)
	if built.is_empty() or randf() < 0.35:
		var a := randf() * TAU
		return Defs.CITY_CENTER + Vector3(cos(a), 0, sin(a)) * randf_range(8.0, 11.0)
	var id: String = built[randi() % built.size()]
	var p := Defs.plot_pos(id)
	var toward := (Defs.CITY_CENTER - p).normalized()
	return p + toward * 2.6 + Vector3(randf_range(-1, 1), 0, randf_range(-1, 1))


func _update_citizens(delta: float) -> void:
	for c in citizens:
		var n: Node3D = c["node"]
		if c["wait"] > 0:
			c["wait"] -= delta
			continue
		var to: Vector3 = c["to"]
		var d := to - n.position
		d.y = 0
		if d.length() < 0.3:
			c["to"] = _random_spot()
			c["wait"] = randf_range(0.5, 3.0)
			continue
		var step := d.normalized() * float(c["speed"]) * delta
		# الابتعاد عن الفرن
		var np := n.position + step
		var fc := np - Defs.CITY_CENTER
		fc.y = 0
		if fc.length() < 7.0:
			np = Defs.CITY_CENTER + fc.normalized() * 7.0
		n.position = np
		n.rotation.y = atan2(d.x, d.z)
		n.position.y = absf(sin(Time.get_ticks_msec() / 110.0 + float(c["speed"]) * 9.0)) * 0.08


# ================================================================ الواجهة
func _setup_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	ui = Control.new()
	ui.set_anchors_preset(Control.PRESET_FULL_RECT)
	ui.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.theme = UI.theme()
	layer.add_child(ui)

	frost_overlay = ColorRect.new()
	frost_overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
	frost_overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var sh := Shader.new()
	sh.code = """shader_type canvas_item;
uniform float amount = 0.0;
void fragment() {
	vec2 uv = UV - 0.5;
	float d = length(uv * vec2(1.0, 0.8)) * 1.55;
	float n = fract(sin(dot(floor(UV * 90.0), vec2(12.9898, 78.233))) * 43758.5453);
	float v = smoothstep(0.5, 1.05, d + n * 0.08) * amount;
	COLOR = vec4(0.82, 0.92, 1.0, v);
}"""
	var smat := ShaderMaterial.new()
	smat.shader = sh
	smat.set_shader_parameter("amount", 0.0)
	frost_overlay.material = smat
	ui.add_child(frost_overlay)

	# مؤقتات فوق المباني (تحت الواجهة الرئيسية في الترتيب)
	JobTimers.build(self, ui)
	# الواجهة الرئيسية بنمط ألعاب الاستراتيجية (scripts/ui/home_hud.gd)
	HomeHud.build(self)

	storm_label = UI.label("", 20, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER)
	storm_label.add_theme_stylebox_override("normal", UI.style(Color(0.55, 0.15, 0.15, 0.85), 16))
	ui.add_child(storm_label)
	storm_label.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP, Control.PRESET_MODE_MINSIZE, 150)
	storm_label.grow_horizontal = Control.GROW_DIRECTION_BOTH
	storm_label.visible = false

	_build_building_panel()

	toast_box = VBoxContainer.new()
	toast_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	toast_box.add_theme_constant_override("separation", 6)
	ui.add_child(toast_box)
	toast_box.anchor_left = 0.5
	toast_box.anchor_right = 0.5
	toast_box.anchor_top = 1.0
	toast_box.anchor_bottom = 1.0
	toast_box.offset_top = -270.0
	toast_box.offset_bottom = -270.0
	toast_box.grow_horizontal = Control.GROW_DIRECTION_BOTH

	modal_layer = Control.new()
	modal_layer.set_anchors_preset(Control.PRESET_FULL_RECT)
	modal_layer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.add_child(modal_layer)


func _icon_button(icon_name: String, text: String, cb: Callable) -> Button:
	var b := UI.button(text, cb, "dark", 64)
	b.icon = UI.icon(icon_name)
	b.expand_icon = true
	b.add_theme_constant_override("icon_max_width", 34)
	b.add_theme_font_size_override("font_size", 17)
	b.custom_minimum_size = Vector2(108, 64)
	return b


func _over_ui(p: Vector2) -> bool:
	if modal_layer.get_child_count() > 0:
		return true
	for c in blockers:
		if c.is_visible_in_tree() and c.get_global_rect().has_point(p):
			return true
	return false


func _chip_input(e: InputEvent, what: String) -> void:
	if not (e is InputEventMouseButton and e.pressed):
		return
	match what:
		"temp":
			var st: String = ["دافئة", "باردة — يمرض السكان ببطء", "متجمدة — يمرض السكان بسرعة والإنتاج نصفه"][Game.cold_level]
			_toast("الخارج %d° • الداخل %d° • المدينة %s" % [int(Game.outside_temp), int(Game.inside_temp), st])
		"pop":
			_toast("السكان %d من %d • الأصحاء %d • المرضى %d • يأكل كل ساكن 6 طعام في الساعة" % [Game.pop, Game.pop_capacity(), Game.healthy(), int(Game.sick)])
		"gems":
			_toast("الجواهر تُستخدم لتسريع البناء. تحصل عليها من المهام والمكافأة اليومية")
		"aurora":
			_toast("بلورات الشفق: تظهر في المدينة أثناء العواصف، المسها لجمعها. تستدعي بها الأبطال وتطوّر أبحاثًا خاصة")
		"trust":
			_toast("ثقة الناس %d%% • تغيّر الإنتاج بين −10%% و+10%% • تتأثر بقراراتك والبرد والجوع والغارات" % int(Game.trust))
		"power":
			_toast("قوة المدينة: الجنود والمباني والأبطال والأبحاث مجتمعة")
		_:
			var n := Game.net_rate(what)
			_toast("%s: %s • الصافي %s%s في الساعة" % [Defs.RES_NAMES[what], Defs.fmt(Game.res[what]), "+" if n >= 0 else "", Defs.fmt(n)])


func _builder_input(e: InputEvent, idx: int) -> void:
	if not (e is InputEventMouseButton and e.pressed):
		return
	if idx < Game.queue.size():
		var id: String = Game.queue[idx]["plot"]
		_select(id)
	elif idx >= Game.builder_count():
		_toast("البنّاء %d يُفتح عند الفرن المستوى %d" % [idx + 1, Game.next_builder_unlock()])
	else:
		_toast("البنّاء متاح — اضغط على مبنى لتطويره")


# ---------------------------------------------------------------- لوحة المبنى
func _build_building_panel() -> void:
	bp = UI.panel(Color(0.05, 0.1, 0.17, 0.94), 20)
	bp.custom_minimum_size = Vector2(690, 0)
	ui.add_child(bp)
	blockers.append(bp)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 6)
	bp.add_child(v)
	var head := HBoxContainer.new()
	v.add_child(head)
	var close := UI.button("إغلاق", _close_panel, "dark", 44)
	close.custom_minimum_size = Vector2(90, 44)
	head.add_child(close)
	bp_title = UI.label("", 26, UI.GOLD)
	bp_title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(bp_title)
	bp_desc = UI.label("", 16, UI.TEXT_DIM)
	bp_desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	v.add_child(bp_desc)
	bp_stats = UI.label("", 18)
	bp_stats.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	v.add_child(bp_stats)
	bp_store_row = HBoxContainer.new()
	v.add_child(bp_store_row)
	bp_store_row.add_child(UI.button("جمع", func(): _collect(sel), "green", 44))
	bp_store = UI.label("", 18, Color.WHITE)
	bp_store.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bp_store_row.add_child(bp_store)
	bp_mode_row = HBoxContainer.new()
	bp_mode_row.add_theme_constant_override("separation", 6)
	v.add_child(bp_mode_row)
	for m in [[2, "مضاعف"], [1, "عادي"], [0, "إطفاء"]]:
		var mode: int = m[0]
		var b := UI.button(m[1], func(): Game.set_furnace_mode(mode), "dark", 44)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.toggle_mode = true
		bp_mode_row.add_child(b)
		bp_mode_btns.append([mode, b])
	bp_progress = UI.progress_bar(Color("4fb4ff"))
	v.add_child(bp_progress)
	bp_cost_row = HBoxContainer.new()
	bp_cost_row.add_theme_constant_override("separation", 6)
	bp_cost_row.alignment = BoxContainer.ALIGNMENT_END
	v.add_child(bp_cost_row)
	var tc := UI.chip("time", 24, 17)
	bp_time = tc[1]
	bp_cost_row.add_child(tc[0])
	for r in ["iron", "coal", "wood"]:
		var c := UI.chip(r, 24, 17)
		bp_cost_row.add_child(c[0])
		bp_cost_chips[r] = c
	bp_reasons = UI.label("", 16, UI.RED)
	bp_reasons.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	v.add_child(bp_reasons)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	v.add_child(row)
	bp_cancel = UI.button("إلغاء", func(): Game.cancel(sel); _refresh_all(), "red", 54)
	bp_speed = UI.button("", func(): Game.speedup(sel), "blue", 54)
	bp_instant = UI.button("", func(): _do_upgrade(true), "blue", 54)
	bp_main = UI.button("", func(): _do_upgrade(false), "gold", 54)
	bp_open = UI.button("", _open_from_panel, "green", 54)
	for b in [bp_open, bp_cancel, bp_speed, bp_instant, bp_main]:
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(b)
	bp.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM, Control.PRESET_MODE_MINSIZE, 12)
	bp.grow_horizontal = Control.GROW_DIRECTION_BOTH
	bp.grow_vertical = Control.GROW_DIRECTION_BEGIN
	bp.offset_top -= 170.0   # فوق شريط المهمة وشريط التنقل
	bp.offset_bottom -= 170.0
	bp.visible = false


func _select(id: String) -> void:
	sel = id
	bp.visible = true
	var p := Defs.plot_pos(id)
	sel_ring.visible = true
	sel_ring.position = p + Vector3(0, 0.12, 0)
	var r := 7.5 if id == "furnace" else 2.6
	sel_ring.scale = Vector3(r, 1, r)
	_update_panel()
	# تحريك الكاميرا ليظهر المبنى فوق اللوحة
	rig.fly_to(p + Vector3(0, 0, 6), clampf(rig.dist, 26.0, 45.0), 0.5)


func _close_panel() -> void:
	sel = ""
	bp.visible = false
	sel_ring.visible = false


func _update_panel() -> void:
	if sel == "" or not bp.visible:
		return
	var id := sel
	var tp: String = Defs.PLOTS[id]["type"]
	var b: Dictionary = Defs.BUILDINGS[tp]
	var lv := Game.level(id)
	var q := Game.queue_entry(id)
	var chk := Game.check_upgrade(id)
	var nxt: int = chk["next"]
	bp_title.text = "%s — المستوى %d" % [b["name"], lv] if lv > 0 else "بناء: %s" % b["name"]
	bp_desc.text = b["desc"]
	var st: Array[String] = []
	match tp:
		"furnace":
			st.append("الحرارة: +%d° ← +%d°   •   الحرارة الآن داخل المدينة %d°" % [int(Defs.furnace_heat(lv)), int(Defs.furnace_heat(nxt)), int(Game.inside_temp)])
			st.append("استهلاك الفحم: %s في الساعة   •   المخزون %s" % [Defs.fmt(Game.coal_use()), Defs.fmt(Game.res["coal"])])
			if Game.res["coal"] > 0 and Game.coal_use() > 0:
				st.append("يكفي الفحم لمدة %s" % Defs.fmt_time(Game.res["coal"] / Game.coal_use() * 3600.0))
		"shelter":
			st.append("يؤوي: %d ← %d ساكن   •   السكان %d / %d" % [Defs.shelter_capacity(lv), Defs.shelter_capacity(nxt), Game.pop, Game.pop_capacity()])
		"storehouse":
			st.append("مدة تخزين مباني الإنتاج: %s ← %s ساعة" % [str(2.0 + 0.5 * lv), str(2.0 + 0.5 * nxt)])
		"barracks":
			st.append("سعة الجيش: %d ← %d جندي   •   الجيش الآن: %d" % [Defs.camp_capacity(lv), Defs.camp_capacity(nxt), Game.army_count()])
			st.append("الجنود: %d   •   الجرحى: %d" % [Game.troop_total(), Game.wounded_total()])
		"bk_shield", "bk_spear", "bk_bow":
			var ttp := ""
			for k in Defs.BARRACKS_TYPE:
				if Defs.BARRACKS_TYPE[k] == tp:
					ttp = k
			st.append("حجم الدفعة: %d ← %d جندي   •   سرعة التدريب: ×%.2f ← ×%.2f" % [Defs.train_batch(lv), Defs.train_batch(nxt), Defs.barracks_speed(lv), Defs.barracks_speed(nxt)])
			st.append("أعلى رتبة: %s   •   يدرّب: %s" % [Defs.TIER_NAMES[maxi(Game.max_tier_of(ttp), 1)] if lv > 0 else "—", Defs.TROOPS[ttp]["plural"]])
		"hero_hall":
			st.append("الحد الأعلى لمستوى الأبطال: %d ← %d   •   الأبطال: %d / 6" % [lv * 5, mini(nxt * 5, 50), Game.heroes_owned()])
		"lab":
			st.append("مستوى المختبر يفتح أبحاثًا أعمق ومستويات أعلى")
			if not Game.research.is_empty():
				st.append("قيد البحث: %s • متبقٍ %s" % [Defs.TECHS[Game.research["id"]]["name"], Defs.fmt_time(float(Game.research["end"]) - Game.now())])
		"infirmary":
			st.append("العلاج: %.1f ← %.1f مريض في الدقيقة   •   المرضى %d" % [0.6 * lv, 0.6 * nxt, int(Game.sick)])
			st.append("الجرحى: %d / %d" % [Game.wounded_total(), Game.wounded_cap()])
			st.append("العمال: %d / %d" % [int(Game.workers.get(id, 0)), Defs.workers_needed(tp, lv)])
		_:
			if b.has("prod"):
				var r: String = b["prod"]
				st.append("الإنتاج: %s ← %s %s في الساعة" % [Defs.fmt(Defs.prod_rate(tp, lv)), Defs.fmt(Defs.prod_rate(tp, nxt)), Defs.RES_NAMES[r]])
				if lv > 0:
					st.append("العمال: %d / %d   •   الإنتاج الفعلي %s في الساعة" % [int(Game.workers.get(id, 0)), Defs.workers_needed(tp, lv), Defs.fmt(Game.current_rate(id))])
	bp_stats.text = "\n".join(st)
	var has_store := b.has("prod") and lv > 0
	bp_store_row.visible = has_store
	if has_store:
		bp_store.text = "جاهز للجمع: %s / %s" % [Defs.fmt(float(Game.stored.get(id, 0.0))), Defs.fmt(Game.storage_cap(id))]
	bp_mode_row.visible = tp == "furnace"
	for mb in bp_mode_btns:
		(mb[1] as Button).set_pressed_no_signal(Game.furnace_mode == mb[0])
		(mb[1] as Button).modulate = Color(1.25, 1.1, 0.7) if Game.furnace_mode == mb[0] else Color.WHITE
	var building := not q.is_empty()
	var opens := {"barracks": "فتح المعسكر", "bk_shield": "تدريب الدروع", "bk_spear": "تدريب الرماح", "bk_bow": "تدريب الرماة", "hero_hall": "الأبطال", "lab": "الأبحاث"}
	bp_open.visible = opens.has(tp) and lv > 0
	if bp_open.visible:
		bp_open.text = opens[tp]
	bp_progress.visible = building
	bp_cost_row.visible = not building and nxt <= int(b["max"])
	bp_speed.visible = building
	bp_cancel.visible = building
	bp_main.visible = not building
	bp_instant.visible = not building
	if building:
		var total := float(q["end"]) - float(q["start"])
		var remain := float(q["end"]) - Game.now()
		bp_progress.value = 100.0 * (1.0 - remain / maxf(total, 0.01))
		var g := Game.gems_for_time(remain)
		bp_speed.text = "تسريع مجاني" if g == 0 else "تسريع • %d جوهرة" % g
		bp_speed.disabled = not Game.dev_mode and Game.gems < g
		bp_reasons.text = "قيد البناء إلى المستوى %d • متبقٍ %s" % [int(q["level"]), Defs.fmt_time(remain)]
		bp_reasons.add_theme_color_override("font_color", Color("7fd3ff"))
		return
	bp_reasons.add_theme_color_override("font_color", UI.RED)
	var cost: Dictionary = chk["cost"]
	for r in bp_cost_chips:
		var c: Array = bp_cost_chips[r]
		(c[0] as Control).visible = cost.has(r)
		if cost.has(r):
			(c[1] as Label).text = Defs.fmt(cost[r])
			(c[1] as Label).add_theme_color_override("font_color", UI.RED if Game.res[r] < cost[r] else Color.WHITE)
	bp_time.text = Defs.fmt_time(chk["time"])
	var reasons: Array = chk["reasons"].duplicate()
	if not chk["missing"].is_empty():
		var miss: Array[String] = []
		for r in chk["missing"]:
			miss.append("%s %s" % [Defs.fmt(chk["missing"][r]), Defs.RES_NAMES[r]])
		reasons.append("ينقصك: " + "، ".join(miss))
	if not chk["builders_free"]:
		reasons.append("كل البنائين مشغولون (يمكنك البناء الفوري)")
	bp_reasons.text = "\n".join(reasons)
	bp_main.text = "تطوير" if lv > 0 else "بناء"
	bp_main.disabled = not chk["ok"]
	var gi := Game.gems_for_time(chk["time"])
	bp_instant.text = "فوري • %d جوهرة" % gi if gi > 0 else "فوري • مجاني"
	bp_instant.disabled = not chk["reasons"].is_empty() or not chk["missing"].is_empty() or (not Game.dev_mode and Game.gems < gi)


func _do_upgrade(instant: bool) -> void:
	if Game.start_upgrade(sel, instant):
		_refresh_plot(sel)
		if not instant:
			_toast("بدأ البناء")
	_update_panel()


func _collect(id: String) -> void:
	var tp: String = Defs.PLOTS[id]["type"]
	var v := Game.collect(id)
	if v > 0:
		Sound.play("collect")
		_float_text("+" + Defs.fmt(v), Defs.plot_pos(id) + Vector3(0, plot_nodes[id]["top"] + 1.0, 0), Defs.BUILDINGS[tp]["prod"])
	_update_panel()


func _collect_all() -> void:
	var got := {}
	for id in Defs.PLOTS:
		var tp: String = Defs.PLOTS[id]["type"]
		if not Defs.BUILDINGS[tp].has("prod"):
			continue
		var v := Game.collect(id)
		if v > 0:
			got[Defs.BUILDINGS[tp]["prod"]] = float(got.get(Defs.BUILDINGS[tp]["prod"], 0.0)) + v
			_float_text("+" + Defs.fmt(v), Defs.plot_pos(id) + Vector3(0, plot_nodes[id]["top"] + 1.0, 0), Defs.BUILDINGS[tp]["prod"])
	if got.is_empty():
		_toast("لا توجد موارد جاهزة للجمع الآن")
	else:
		var parts: Array[String] = []
		for r in got:
			parts.append("%s %s" % [Defs.fmt(got[r]), Defs.RES_NAMES[r]])
		_toast("تم جمع: " + "، ".join(parts))


func _float_text(t: String, pos: Vector3, r: String) -> void:
	var col := {"food": Color("ffd28a"), "wood": Color("e9b98a"), "coal": Color("d0d4dc"), "iron": Color("a9d8ff"), "aurora": Color("9ff3ff")}
	var l := _label3d(t, pos, 34, col.get(r, Color.WHITE))
	add_child(l)
	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property(l, "position:y", pos.y + 3.0, 1.1)
	tw.tween_property(l, "modulate:a", 0.0, 1.1).set_delay(0.3)
	tw.chain().tween_callback(l.queue_free)


# ---------------------------------------------------------------- النقر
func _on_tap(world: Vector3, sp: Vector2) -> void:
	# فقاعات الجمع أولًا (بالمسافة على الشاشة)
	var cam: Camera3D = rig.cam
	for i in crystal_nodes.size():
		var cn: Node3D = crystal_nodes[i]
		var cp := cn.global_position + Vector3(0, 0.6, 0)
		if not cam.is_position_behind(cp) and cam.unproject_position(cp).distance_to(sp) < 55.0:
			var v := Game.collect_crystal(i)
			if v > 0:
				_float_text("+%d" % v, cp + Vector3(0, 1.0, 0), "aurora")
			return
	for id in plot_nodes:
		var bub: Sprite3D = plot_nodes[id]["bubble"]
		if bub.visible and not cam.is_position_behind(bub.global_position):
			if cam.unproject_position(bub.global_position).distance_to(sp) < 46.0:
				_collect(id)
				return
	var best := ""
	var bd := 1e9
	for id in Defs.PLOTS:
		var p := Defs.plot_pos(id)
		var d := Vector2(world.x - p.x, world.z - p.z).length()
		var lim := 7.0 if id == "furnace" else 3.6
		if d < lim and d < bd:
			bd = d
			best = id
	if best == "":
		_close_panel()
		return
	if Game.level(best) > 0 and float(Game.stored.get(best, 0.0)) >= 1.0:
		_collect(best)
	_select(best)


# ---------------------------------------------------------------- الأحداث
func _on_building_done(id: String) -> void:
	if not plot_nodes.has(id):
		return
	_refresh_all()
	var p := Defs.plot_pos(id)
	var burst := CPUParticles3D.new()
	burst.one_shot = true
	burst.emitting = true
	burst.amount = 40
	burst.lifetime = 1.2
	burst.explosiveness = 0.9
	burst.direction = Vector3.UP
	burst.spread = 60.0
	burst.initial_velocity_min = 4.0
	burst.initial_velocity_max = 8.0
	burst.gravity = Vector3(0, -6, 0)
	var m := BoxMesh.new()
	m.size = Vector3(0.18, 0.18, 0.18)
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.albedo_color = UI.GOLD
	m.material = mat
	burst.mesh = m
	burst.position = p + Vector3(0, 2, 0)
	add_child(burst)
	get_tree().create_timer(2.0).timeout.connect(burst.queue_free)


func _refresh_all() -> void:
	for id in plot_nodes:
		_refresh_plot(id)
	_update_panel()


var _last_sig := ""


func _on_changed() -> void:
	for r in res_chips:
		(res_chips[r] as Label).text = Defs.fmt(Game.res[r])
		(res_chips[r] as Label).add_theme_color_override("font_color", UI.RED if Game.net_rate(r) < 0 and Game.res[r] < 200 else Color.WHITE)
	gem_label.text = Defs.fmt(Game.gems)
	aurora_label.text = Defs.fmt(Game.aurora)
	trust_label.text = "%d%%" % int(Game.trust)
	trust_label.add_theme_color_override("font_color", UI.GREEN if Game.trust >= 50 else (Color("ffd36b") if Game.trust >= 25 else UI.RED))
	power_label.text = Defs.fmt(Game.power())
	_update_side()
	HomeHud.refresh(self)
	temp_label.text = "%d°" % int(round(Game.inside_temp))
	var tcol: Color = [UI.GREEN, Color("ffd36b"), UI.RED][Game.cold_level]
	temp_label.add_theme_color_override("font_color", tcol)
	pop_label.text = "%d/%d" % [Game.pop, Game.pop_capacity()]
	sick_label.text = str(int(Game.sick))
	var open_builders := maxi(Game.builder_count(), Game.queue.size())   # المطور قد يتجاوز العدد
	var lock_at := Game.next_builder_unlock()
	for i in builder_rows.size():
		var row: Dictionary = builder_rows[i]
		var pnl: Control = row["panel"]
		# صف لكل بنّاء مفتوح + صف واحد مقفل يوضح متى يُفتح البنّاء التالي
		pnl.visible = i < open_builders or (i == open_builders and lock_at > 0)
		if i < Game.queue.size():
			var q: Dictionary = Game.queue[i]
			var tp: String = Defs.PLOTS[q["plot"]]["type"]
			var remain := float(q["end"]) - Game.now()
			(row["label"] as Label).text = "%s %d • %s" % [Defs.BUILDINGS[tp]["name"], int(q["level"]), Defs.fmt_time(remain)]
			(row["bar"] as ProgressBar).value = 100.0 * (1.0 - remain / maxf(float(q["end"]) - float(q["start"]), 0.01))
		elif i < open_builders:
			(row["label"] as Label).text = "البنّاء %d: متاح" % (i + 1)
			(row["bar"] as ProgressBar).value = 0
		else:
			(row["label"] as Label).text = "البنّاء %d: يفتح بالفرن %d" % [i + 1, lock_at]
			(row["bar"] as ProgressBar).value = 0
	# المهمة
	var tt := Game.tracked_task()
	if tt.is_empty():
		task_title.text = "أنهيت كل المهام الحالية"
		task_prog.text = "مهام جديدة في المرحلة القادمة"
		task_btn.visible = false
	else:
		var tk: Dictionary = tt["tk"]
		var pr := Game.task_progress(tk)
		task_title.text = ("الفصل الثاني • " if tt["ch"] == 2 else "") + str(tk["text"])
		var rws := Defs.reward_text(tk["reward"])
		var one: bool = tk["type"] in ["temp", "defender", "governor"]
		task_prog.text = "%s / %s   •   المكافأة: %s" % [Defs.fmt(minf(pr.x, pr.y)), Defs.fmt(pr.y), rws] if not one else "المكافأة: " + rws
		task_btn.visible = true
		var done := Game.task_done(tk)
		task_btn.text = "استلام" if done else "اذهب"
		task_btn.modulate = Color(1, 1, 1) if done else Color(0.75, 0.8, 0.9)
	# العاصفة
	var soon := Game.storm_soon()
	if Game.storm_active():
		storm_label.visible = true
		storm_label.text = "عاصفة ثلجية • -22° • تنتهي خلال %s" % Defs.fmt_time(Game.storm_end - Game.now())
	elif soon > 0:
		storm_label.visible = true
		storm_label.text = "تحذير: عاصفة ثلجية خلال %s — جهّز الفحم" % Defs.fmt_time(soon)
	elif Game.raid_soon() > 0:
		storm_label.visible = true
		storm_label.text = "غارة ذئاب خلال %s — جهّز جنودك وعيّن قائد الدفاع" % Defs.fmt_time(Game.raid_soon())
	else:
		storm_label.visible = false
	# إعادة بناء المواقع عند تغيّر المستويات أو الطابور
	var sig := str(Game.plots) + str(Game.queue.size()) + str(Game.furnace_level())
	if sig != _last_sig:
		_last_sig = sig
		_refresh_all()
	_update_panel()
	_sync_citizens()
	_sync_soldiers()
	for f in win_tick:
		(f as Callable).call()


func _task_action() -> void:
	var tt := Game.tracked_task()
	if tt.is_empty():
		return
	var tk: Dictionary = tt["tk"]
	if Game.task_done(tk):
		if tt["ch"] == 1:
			Game.claim_task()
		else:
			Game.claim_task2()
		Sound.play("collect")
		return
	match tk["type"]:
		"train", "raid_win", "power":
			_show_army()
			return
		"hero", "hero_lv", "defender", "governor":
			_show_heroes()
			return
		"research":
			_show_research()
			return
		"decision":
			_show_decision()
			return
		"aurora":
			_toast("تظهر بلورات الشفق في المدينة أثناء العواصف الثلجية، المسها لجمعها")
			return
	# الذهاب إلى المبنى المناسب
	var tp: String = tk.get("b", "")
	if tk["type"] == "collect":
		tp = {"food": "hunter", "wood": "sawmill", "coal": "coal_mine", "iron": "iron_mine"}[tk["r"]]
	elif tk["type"] == "pop":
		tp = "shelter"
	elif tk["type"] == "temp":
		tp = "furnace"
	elif tk["type"] == "march":
		_go_map()
		return
	var target := ""
	for id in Defs.PLOTS:
		if Defs.PLOTS[id]["type"] != tp:
			continue
		if tk["type"] == "count" and Game.level(id) == 0 and Game.furnace_level() >= int(Defs.PLOTS[id]["unlock"]):
			target = id
			break
		if target == "" or Game.level(id) > Game.level(target):
			target = id
	if target != "":
		_select(target)


# ---------------------------------------------------------------- النوافذ
func _modal(title: String, body: String, buttons: Array, icon_name: String = "") -> Control:
	_close_panel()
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.45)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	dim.mouse_filter = Control.MOUSE_FILTER_STOP
	modal_layer.add_child(dim)
	var p := UI.panel(Color(0.06, 0.11, 0.19, 0.97), 22)
	p.custom_minimum_size = Vector2(620, 0)
	dim.add_child(p)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 12)
	p.add_child(v)
	var h := HBoxContainer.new()
	h.alignment = BoxContainer.ALIGNMENT_END
	v.add_child(h)
	h.add_child(UI.label(title, 26, UI.GOLD))
	if icon_name != "":
		h.add_child(UI.icon_rect(icon_name, 44))
	if body != "":
		var b := UI.label(body, 19)
		b.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		b.custom_minimum_size = Vector2(580, 0)
		v.add_child(b)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	v.add_child(row)
	for bt in buttons:
		var cb: Callable = bt[1]
		var btn := UI.button(bt[0], func():
			dim.queue_free()
			cb.call(), bt[2] if bt.size() > 2 else "dark", 56)
		btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(btn)
	p.set_anchors_and_offsets_preset(Control.PRESET_CENTER, Control.PRESET_MODE_MINSIZE)
	p.grow_horizontal = Control.GROW_DIRECTION_BOTH
	p.grow_vertical = Control.GROW_DIRECTION_BOTH
	return v


func _show_daily() -> void:
	var rw := Game.daily_reward()
	var parts: Array[String] = []
	for k in rw:
		parts.append("• %s: %s" % [Defs.RES_NAMES[k], Defs.fmt(rw[k])])
	_modal("المكافأة اليومية", "هدية اليوم لمدينتك:\n" + "\n".join(parts), [["استلام", func(): Game.claim_daily(), "gold"]], "gift")


func _show_tasks() -> void:
	var lines: Array[String] = []
	for i in Defs.TASKS.size():
		var tk: Dictionary = Defs.TASKS[i]
		var mark := "✓" if i < Game.task_index else ("◀" if i == Game.task_index else "•")
		lines.append("%s  %s" % [mark, tk["text"]])
		if i > Game.task_index + 3:
			lines.append("…")
			break
	if Game.chapter2_open():
		lines.append("")
		lines.append("الفصل الثاني (%d / %d):" % [mini(Game.task2_index, Defs.TASKS2.size()), Defs.TASKS2.size()])
		for i in range(Game.task2_index, mini(Game.task2_index + 4, Defs.TASKS2.size())):
			lines.append("%s  %s" % ["◀" if i == Game.task2_index else "•", Defs.TASKS2[i]["text"]])
	var title := "المهام • الفصل الأول (%d / %d)" % [mini(Game.task_index, Defs.TASKS.size()), Defs.TASKS.size()]
	var btns: Array = [["إغلاق", func(): pass, "dark"]]
	if Game.daily_ready:
		btns.append(["المكافأة اليومية", _show_daily, "gold"])
	_modal(title, "\n".join(lines), btns, "task")


const WinAudioStats := preload("res://scripts/ui/windows/audio_stats_windows.gd")

func _show_settings() -> void:
	WinAudioStats.show_settings(self)


func _audio_window() -> void:
	WinAudioStats.audio_window(self)


func _vol_slider(title: String, which: String) -> VBoxContainer:
	return WinAudioStats.vol_slider(self, title, which)


func _vol_text(v: float) -> String:
	return WinAudioStats.vol_text(v)


func _stats_window() -> void:
	WinAudioStats.stats_window(self)


func _stats_rows(s: Dictionary) -> Array:
	return WinAudioStats.stats_rows(s)


func _cold_name(c: int) -> String:
	return WinAudioStats.cold_name(c)


const WinDev := preload("res://scripts/ui/windows/dev_windows.gd")

func _dev_window() -> void:
	WinDev.dev_window(self)


func _dev_panel() -> void:
	WinDev.dev_panel(self)


func _confirm_reset() -> void:
	WinDev.confirm_reset(self)


func _toast(t: String) -> void:
	if toast_box == null:
		return
	var l := UI.label(t, 19, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER)
	l.add_theme_stylebox_override("normal", UI.style(Color(0.04, 0.08, 0.14, 0.88), 18))
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	toast_box.add_child(l)
	while toast_box.get_child_count() > 3:
		toast_box.get_child(0).free()
	var tw := create_tween()
	tw.tween_interval(2.8)
	tw.tween_property(l, "modulate:a", 0.0, 0.5)
	tw.tween_callback(l.queue_free)


func _go_map() -> void:
	Game.save_game()
	get_tree().change_scene_to_file("res://world_map.tscn")


# ================================================================ كل إطار
func _process(delta: float) -> void:
	if dev_btn != null:
		dev_btn.visible = Game.dev_mode
	# الصقل البصري: لوحات المواقع تظهر فقط عند الاقتراب — تقليل التكدس فوق الواجهة
	var badges_near: bool = rig.dist < 42.0
	for id in plot_nodes:
		var pn: Dictionary = plot_nodes[id]
		var badge: Label3D = pn["badge"]
		var important: bool = Defs.PLOTS[id]["type"] == "furnace" or id == sel
		badge.visible = (badges_near or important) and not (id == sel and bp.visible)
	for id in plot_nodes:
		_update_plot_dynamic(id)
	JobTimers.update(self)
	_update_citizens(delta)
	# الفرن والجو
	var on: bool = Game.furnace_mode > 0 and Game.res["coal"] > 0
	var target := 0.0 if not on else (2.2 if Game.furnace_mode == 1 else 4.0)
	fire_light.light_energy = lerpf(fire_light.light_energy, target * (0.9 + 0.1 * sin(Time.get_ticks_msec() / 90.0)), delta * 4.0)
	smoke.emitting = on
	var tier := _tier("furnace", Game.furnace_level())
	smoke.position = Defs.CITY_CENTER + Vector3(0, 9.2 + tier * 2.6, 0)
	var storm := Game.storm_active()
	var cold := float(Game.cold_level) / 2.0
	var mat := frost_overlay.material as ShaderMaterial
	var cur := float(mat.get_shader_parameter("amount") if mat.get_shader_parameter("amount") != null else 0.0)
	mat.set_shader_parameter("amount", lerpf(cur, clampf(cold * 0.8 + (0.35 if storm else 0.0), 0.0, 1.0), delta * 1.5))
	env.fog_density = lerpf(env.fog_density, 0.016 if storm else 0.0, delta * 0.8)
	env.fog_enabled = env.fog_density > 0.0005
	snow.speed_scale = 2.2 if storm else 1.0
	sun.light_energy = lerpf(sun.light_energy, 0.55 if storm else 0.95, delta)
	var d: float = rig.dist
	snow.emission_box_extents = Vector3(d * 0.8, 1, d * 0.8)
	snow.position = Vector3(0, clampf(d * 0.5, 12.0, 40.0), 0)
	_process_stage2(delta)
	if sel_ring.visible:
		var k := 1.0 + sin(Time.get_ticks_msec() / 180.0) * 0.04
		var r := (7.5 if sel == "furnace" else 2.6) * k
		sel_ring.scale = Vector3(r, 1, r)


# ================================================================ المرحلة الثانية: العالم ثلاثي الأبعاد
func _setup_stage2_world() -> void:
	for k in Defs.TROOP_ORDER:
		soldier_meshes[k] = _inst("res://assets/city/soldier_%s.glb" % k)
	crystal_scene = _inst("res://assets/city/crystal.glb")
	wolf_scene = _inst("res://assets/city/wolf.glb")
	_sync_crystals()


func _sync_soldiers() -> void:
	var lv := Game.level("ba1")
	var counts := {}
	for tp in Defs.TROOP_ORDER:
		var n := 0
		for t in range(1, 5):
			n += int(Game.troops["%s_%d" % [tp, t]])
		counts[tp] = clampi(int(ceil(n / 15.0)), 0, 6)
	var sig := str(counts) + str(lv > 0)
	if sig == _soldier_sig:
		return
	_soldier_sig = sig
	for n in soldier_nodes:
		(n["node"] as Node).queue_free()
	soldier_nodes.clear()
	if lv <= 0 or not plot_nodes.has("ba1"):
		return
	var root: Node3D = plot_nodes["ba1"]["root"]
	var row := 0
	for tp in Defs.TROOP_ORDER:
		var c: int = counts[tp]
		for i in c:
			var n: Node3D = (soldier_meshes[tp] as Node3D).duplicate()
			n.scale = Vector3.ONE * 1.5
			n.position = Vector3((i - (c - 1) / 2.0) * 0.85, 0, 3.6 + row * 1.0)
			root.add_child(n)
			soldier_nodes.append({"node": n, "ph": randf() * TAU})
		row += 1


func _sync_crystals() -> void:
	for n in crystal_nodes:
		(n as Node).queue_free()
	crystal_nodes.clear()
	if crystal_scene == null:
		return
	for c in Game.crystals:
		var n: Node3D = crystal_scene.duplicate()
		n.position = Vector3(float(c["x"]), 0, float(c["z"]))
		n.scale = Vector3.ONE * 1.6
		add_child(n)
		crystal_nodes.append(n)


func _process_stage2(delta: float) -> void:
	var t := Time.get_ticks_msec() / 1000.0
	for i in crystal_nodes.size():
		var n: Node3D = crystal_nodes[i]
		n.rotation.y += delta * 0.8
		n.position.y = 0.15 + sin(t * 2.2 + i) * 0.15
	for s in soldier_nodes:
		var n: Node3D = s["node"]
		n.position.y = absf(sin(t * 4.0 + float(s["ph"]))) * 0.06
	if raid_anim_t >= 0.0:
		_update_raid_anim(delta)


# ---------------------------------------------------------------- الغارة
func _on_raid(rep: Dictionary) -> void:
	if not is_inside_tree():
		return
	for a in raid_anim:
		(a["node"] as Node).queue_free()
	raid_anim.clear()
	raid_anim_win = rep["win"]
	var gate := Vector3(60, 0, 104)
	var nw := clampi(int(rep["wolves"]) / 3, 4, 16)
	for i in nw:
		var n: Node3D = wolf_scene.duplicate()
		n.scale = Vector3.ONE * 1.3
		var from := Vector3(60 + randf_range(-8, 8), 0, 122 + randf_range(0, 10))
		var to := gate + Vector3(randf_range(-4, 4), 0, randf_range(1.5, 4))
		n.position = from
		add_child(n)
		raid_anim.append({"node": n, "from": from, "to": to, "wolf": true})
	var ns := clampi(Game.troop_total() / 10, 0, 12)
	for i in ns:
		var tp: String = Defs.TROOP_ORDER[i % 3]
		var n: Node3D = (soldier_meshes[tp] as Node3D).duplicate()
		n.scale = Vector3.ONE * 1.6
		var from := Defs.plot_pos("ba1") + Vector3(randf_range(-3, 3), 0, randf_range(-3, 3))
		var to := gate + Vector3(randf_range(-4, 4), 0, randf_range(-3.5, -1))
		n.position = from
		add_child(n)
		raid_anim.append({"node": n, "from": from, "to": to, "wolf": false})
	raid_anim_t = 0.0
	_close_panel()
	rig.fly_to(gate + Vector3(0, 0, -2), 38.0, 1.0)


func _update_raid_anim(delta: float) -> void:
	raid_anim_t += delta
	var t := raid_anim_t
	for a in raid_anim:
		var n: Node3D = a["node"]
		var from: Vector3 = a["from"]
		var to: Vector3 = a["to"]
		var p := n.position
		if t < 3.0:
			p = from.lerp(to, smoothstep(0.0, 3.0, t))
		elif t < 4.6:
			p = to + Vector3(sin(t * 20.0 + from.x) * 0.25, 0, cos(t * 17.0 + from.z) * 0.25)
		else:
			var k := clampf((t - 4.6) / 1.8, 0.0, 1.0)
			if a["wolf"]:
				var dest := to + (Vector3(0, 0, 26) if raid_anim_win else Vector3(randf_range(-2, 2), 0, -16))
				p = to.lerp(dest, k)
			else:
				p = to.lerp(to + (Vector3(0, 0, 2) if raid_anim_win else Vector3(0, 0, -6)), k)
		var d := p - n.position
		if d.length() > 0.01:
			n.rotation.y = atan2(d.x, d.z)
		n.position = Vector3(p.x, absf(sin(t * 12.0 + from.x)) * 0.12, p.z)
	if t > 6.6:
		for a in raid_anim:
			(a["node"] as Node).queue_free()
		raid_anim.clear()
		raid_anim_t = -1.0
		_show_raid_report()


func _show_raid_report() -> void:
	var r: Dictionary = Game.last_raid
	if r.is_empty():
		return
	Game.raid_unseen = false
	var lines: Array[String] = []
	lines.append("هاجم %d ذئبًا البوابة الجنوبية%s." % [int(r["wolves"]), " وسط العاصفة" if r.get("storm", false) else ""])
	if str(r.get("hero", "")) != "":
		lines.append("قاد الدفاع: %s" % Defs.HEROES[r["hero"]]["name"])
	lines.append("قُتل من الذئاب: %d • جرحى جنودنا: %d • قتلانا: %d" % [int(r["killed"]), int(r["wounded"]), int(r["dead"])])
	for l in r.get("log", []):
		lines.append("• " + str(l))
	if r["win"]:
		lines.append("الغنائم: " + Defs.reward_text(r["reward"]))
	else:
		var lp: Array[String] = []
		for k in r["loss"]:
			lp.append("%s %s" % [Defs.fmt(r["loss"][k]), Defs.RES_NAMES[k]])
		if not lp.is_empty():
			lines.append("نهبت الذئاب: " + "، ".join(lp))
		lines.append("نصيحة: درّب مزيدًا من الرمّاحين فهم الأقوى ضد الوحوش، وعيّن قائدًا للدفاع.")
	_modal("صمدت المدينة" if r["win"] else "اخترقت الذئاب الدفاع", "\n".join(lines),
			[["إغلاق", func(): pass, "dark"], ["الجيش", _show_army, "gold"]], "wolf")


# ---------------------------------------------------------------- الأزرار الجانبية
func _update_side() -> void:
	if side_btns.is_empty():
		return
	var t := Time.get_ticks_msec() / 1000.0
	var dec: Button = side_btns["decision"]
	if Game.pending_decision >= 0:
		dec.modulate = Color(1.0, 0.9 + 0.1 * sin(t * 5.0), 0.6)
		dec.text = "قرار جديد"
	else:
		dec.modulate = Color.WHITE
		dec.text = "دفتر القائد"
	var army: Button = side_btns["army"]
	var tr_end := Game.train_next_end()
	army.text = "الجيش\n%s" % Defs.fmt_time(tr_end - Game.now()) if tr_end > 0.0 else "الجيش"
	var rs: Button = side_btns["research"]
	rs.text = "الأبحاث\n%s" % Defs.fmt_time(float(Game.research["end"]) - Game.now()) if not Game.research.is_empty() else "الأبحاث"
	if Game.raid_next > 0.0:
		raid_label.visible = true
		raid_label.text = "الغارة القادمة\n%s" % Defs.fmt_time(Game.raid_next - Game.now())
		raid_label.add_theme_color_override("font_color", UI.RED if Game.raid_soon() > 0 else Color.WHITE)
	else:
		raid_label.visible = false


func _open_from_panel() -> void:
	var tp: String = Defs.PLOTS[sel]["type"]
	match tp:
		"barracks":
			_show_army()
		"bk_shield":
			_show_training("shield")
		"bk_spear":
			_show_training("spear")
		"bk_bow":
			_show_training("bow")
		"hero_hall":
			_show_heroes()
		"lab":
			_show_research()


# ================================================================ النوافذ الكبيرة
var win_dim: Control
var win_scroll: ScrollContainer


var _portraits := {}
const WinProg := preload("res://scripts/ui/windows/progression_windows.gd")

func _window(title: String, icon_name: String, builder: Callable) -> void:
	WinProg.window(self, title, icon_name, builder)


func _close_window() -> void:
	WinProg.close_window(self)


func _refresh_window() -> void:
	WinProg.refresh_window(self)


func _card(bg: Color = Color(0.08, 0.13, 0.22, 0.95)) -> PanelContainer:
	return WinProg.card(bg)


func _cost_chips(cost: Dictionary, have_aurora: bool = true) -> HBoxContainer:
	return WinProg.cost_chips(cost, have_aurora)


func _hrow(sep: int = 8) -> HBoxContainer:
	return WinProg.hrow(sep)


func _wrap(text: String, size: int = 17, color: Color = Color.WHITE) -> Label:
	return WinProg.wrap_lbl(text, size, color)


func _show_army() -> void:
	WinProg.show_army(self)


func _build_army(body: VBoxContainer) -> void:
	WinProg.build_army(self, body)


func _show_training(tp: String) -> void:
	WinProg.show_training(self, tp)


func _portrait(id: String) -> Texture2D:
	return WinProg.portrait(self, id)


func _show_heroes() -> void:
	WinProg.show_heroes(self)


func _build_heroes(body: VBoxContainer) -> void:
	WinProg.build_heroes(self, body)


func _show_research() -> void:
	WinProg.show_research(self)


func _build_research(body: VBoxContainer) -> void:
	WinProg.build_research(self, body)


func _show_decision() -> void:
	WinProg.show_decision(self)


func _decide(which: String) -> void:
	WinProg.decide(self, which)


